import 'package:flutter/material.dart';

class AppColors {
  // Primary
  static const Color primary = Color(0xFFDC3545);
  static const Color primaryLight = Color(0xFFFFEBEE);
  static const Color primaryDark = Color(0xFFB71C1C);

  // Neutral
  static const Color white = Colors.white;
  static const Color black = Colors.black;
  static const Color greyDark =  Color(0xFF212121);
  static const Color greyLight =  Color(0xFFFFF5F5);

  // Light Theme
  static const Color lightBg = Colors.white;
  static const Color lightCardBg = Color(0xFFEEEEEE);

  static const Color lightTextPrimary = Colors.black87;
  static const Color lightTextSecondary = Colors.black54;

  static const Color lightBorder = Color(0xFFE9ECEF);

  // Dark Theme
  static const Color darkBg = Color(0xFF121212);
  static const Color darkCardBg = Color(0xFF1E1E1E);

  static const Color darkTextPrimary = Colors.white;
  static const Color darkTextSecondary = Colors.white70;

  static const Color darkBorder = Color(0xFF2D2D2D);

  // Utility methods
  static Color getTextPrimaryColor(BuildContext context) {
    return Theme.of(context).brightness == Brightness.dark
        ? darkTextPrimary
        : lightTextPrimary;
  }

  static Color getTextSecondaryColor(BuildContext context) {
    return Theme.of(context).brightness == Brightness.dark
        ? darkTextSecondary
        : lightTextSecondary;
  }

  static Color getBackgroundColor(BuildContext context) {
    return Theme.of(context).brightness == Brightness.dark ? darkBg : lightBg;
  }

  static Color getCardColor(BuildContext context) {
    return Theme.of(context).brightness == Brightness.dark
        ? darkCardBg
        : lightCardBg;
  }

  static bool isDarkMode(BuildContext context) {
    return Theme.of(context).brightness == Brightness.dark;
  }

  static Color getBorderColor(BuildContext context) {
    return Theme.of(context).brightness == Brightness.dark
        ? darkBorder
        : lightBorder;
  }

  static Color getGreyColor(BuildContext context) {
    return Theme.of(context).brightness == Brightness.dark
        ? greyDark
        : greyLight;
  }
}
