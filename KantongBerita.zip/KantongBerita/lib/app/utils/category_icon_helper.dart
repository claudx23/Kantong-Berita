import 'package:flutter/material.dart';

class CategoryIconHelper {
  // Normalize nama kategori jadi bentuk slug
  // "Gaya Hidup" → "gaya-hidup"
  // "Berita Utama" → "berita-utama"
  static String _toSlug(String categoryName) {
    return categoryName
        .trim()
        .toLowerCase()
        .replaceAll(RegExp(r'\s+'), '-');
  }

  static IconData getIcon(String categoryName) {
    final slug = _toSlug(categoryName);

    switch (slug) {
      case 'berita-utama':
        return Icons.newspaper_rounded;
      case 'bisnis':
        return Icons.business_center_rounded;
      case 'ekonomi':
        return Icons.attach_money_rounded;
      case 'gaya-hidup':
        return Icons.spa_rounded;
      case 'hukum':
        return Icons.gavel_rounded;
      case 'industri':
        return Icons.factory_rounded;
      case 'infrastruktur':
        return Icons.construction_rounded;
      case 'kesehatan':
        return Icons.local_hospital_rounded;
      case 'nasional':
        return Icons.flag_rounded;
      case 'olahraga':
        return Icons.sports_soccer_rounded;
      case 'headline':
        return Icons.how_to_vote_rounded;
      case 'seleb':
        return Icons.star_rounded;
      case 'teknologi':
        return Icons.computer_rounded;
      case 'viral':
        return Icons.trending_up_rounded;
      case 'wisata':
        return Icons.flight_rounded;
      default:
        // Kategori lokal (kota/daerah) atau kategori tak dikenal
        return Icons.location_on_rounded;
    }
  }
}