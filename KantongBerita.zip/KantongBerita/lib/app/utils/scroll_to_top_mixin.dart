import 'package:flutter/material.dart';
import 'package:get/get.dart';

mixin ScrollToTopMixin on GetxController {
  final ScrollController scrollController = ScrollController();
  final showBackToTop = false.obs;

  // Threshold scroll untuk tampilkan button (default 300px)
  double get scrollThreshold => 300;

  void setupScrollToTop() {
    scrollController.addListener(() {
      if (scrollController.offset >= scrollThreshold) {
        showBackToTop.value = true;
      } else {
        showBackToTop.value = false;
      }
    });
  }

  void scrollToTop() {
    scrollController.animateTo(
      0,
      duration: const Duration(milliseconds: 500),
      curve: Curves.easeOutCubic,
    );
  }

  @override
  void onClose() {
    scrollController.dispose();
    super.onClose();
  }
}