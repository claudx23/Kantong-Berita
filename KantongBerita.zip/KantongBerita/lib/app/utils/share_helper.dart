import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:kantongberita/app/utils/app_colors.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:share_plus/share_plus.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class ShareHelper {
  // ==================== SHARE VIA WHATSAPP ====================

  static Future<void> shareToWhatsApp({
    required String title,
    required String link,
  }) async {
    final text = Uri.encodeComponent('$title\n\n$link');
    final url = Uri.parse('whatsapp://send?text=$text');

    if (await canLaunchUrl(url)) {
      await launchUrl(url);
    } else {
      // Jika WhatsApp tidak terinstall, buka web WhatsApp
      final webUrl = Uri.parse('https://web.whatsapp.com/send?text=$text');
      await launchUrl(webUrl, mode: LaunchMode.externalApplication);
    }
  }

  // ==================== SHARE VIA TELEGRAM ====================

  static Future<void> shareToTelegram({
    required String title,
    required String link,
  }) async {
    final encodedLink = Uri.encodeComponent(link);
    final encodedTitle = Uri.encodeComponent(title);
    final url = Uri.parse('tg://msg_url?url=$encodedLink&text=$encodedTitle');

    if (await canLaunchUrl(url)) {
      await launchUrl(url);
    } else {
      // Jika Telegram tidak terinstall, buka web Telegram
      final webUrl = Uri.parse(
        'https://t.me/share/url?url=$encodedLink&text=$encodedTitle',
      );
      await launchUrl(webUrl, mode: LaunchMode.externalApplication);
    }
  }

  // ==================== SHARE VIA FACEBOOK ====================

  static Future<void> shareToFacebook({required String link}) async {
    final encodedLink = Uri.encodeComponent(link);
    final url = Uri.parse('fb://share?link=$encodedLink');

    if (await canLaunchUrl(url)) {
      await launchUrl(url);
    } else {
      // Jika Facebook tidak terinstall, buka browser
      final webUrl = Uri.parse(
        'https://www.facebook.com/sharer/sharer.php?u=$encodedLink',
      );
      await launchUrl(webUrl, mode: LaunchMode.externalApplication);
    }
  }

  // ==================== COPY LINK ====================

  static Future<void> copyLink(String link) async {
    await Clipboard.setData(ClipboardData(text: link));
    Get.snackbar(
      'Berhasil',
      'Link berhasil disalin',
      snackPosition: SnackPosition.TOP,
      backgroundColor: Colors.green,
      colorText: Colors.white,
      duration: const Duration(seconds: 2),
      icon: const Icon(Icons.check_circle, color: Colors.white),
    );
  }

  // ==================== SHARE UMUM ====================

  static Future<void> shareGeneral({
    required String title,
    required String link,
  }) async {
    await Share.share('$title\n\n$link', subject: title);
  }

  // ==================== SHOW SHARE BOTTOM SHEET ====================

  static void showShareBottomSheet({
    required String title,
    required String link,
  }) {
    Get.bottomSheet(
      _ShareBottomSheet(title: title, link: link),
      backgroundColor: AppColors.getBackgroundColor(Get.context!),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      isScrollControlled: true,
    );
  }
}

// ==================== SHARE BOTTOM SHEET WIDGET ====================

class _ShareBottomSheet extends StatelessWidget {
  final String title;
  final String link;

  const _ShareBottomSheet({required this.title, required this.link});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Container(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 20),
        decoration: BoxDecoration(
          color: AppColors.getBackgroundColor(Get.context!),
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            _buildHandle(),
            const SizedBox(height: 12),
            _buildTitle(),
            const SizedBox(height: 6),
            _buildSubtitle(),
            const SizedBox(height: 20),

            _buildShareGrid(),

            const SizedBox(height: 16),
            _buildDivider(),

            const SizedBox(height: 12),
            _buildActions(),

            const SizedBox(height: 10),
            _buildLinkPreview(),
          ],
        ),
      ),
    );
  }

  // ==================== SHARE OPTION ITEM ====================

  Widget _buildHandle() {
    return Container(
      width: 40,
      height: 5,
      decoration: BoxDecoration(
        color: AppColors.getCardColor(Get.context!),
        borderRadius: BorderRadius.circular(100),
      ),
    );
  }

  // ==================== LINK PREVIEW ====================

  Widget _buildTitle() {
    return const Text(
      'Bagikan',
      style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
    );
  }

  Widget _buildSubtitle() {
    return Text(
      title,
      maxLines: 2,
      textAlign: TextAlign.center,
      overflow: TextOverflow.ellipsis,
      style: TextStyle(
        fontSize: 13,
        color: AppColors.getTextSecondaryColor(Get.context!),
      ),
    );
  }

  Widget _buildShareGrid() {
    return GridView(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      padding: EdgeInsets.zero,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 4,
        mainAxisSpacing: 16,
        crossAxisSpacing: 8,
        childAspectRatio: 0.9,
      ),
      children: [
        _shareItem(
          icon: FontAwesomeIcons.whatsapp,
          label: "WhatsApp",
          color: const Color(0xFF25D366),
          onTap: () {
            Get.back();
            ShareHelper.shareToWhatsApp(title: title, link: link);
          },
        ),
        _shareItem(
          icon: FontAwesomeIcons.telegram,
          label: "Telegram",
          color: const Color(0xFF0088CC),
          onTap: () {
            Get.back();
            ShareHelper.shareToTelegram(title: title, link: link);
          },
        ),
        _shareItem(
          icon: FontAwesomeIcons.facebookF,
          label: "Facebook",
          color: const Color(0xFF1877F2),
          onTap: () {
            Get.back();
            ShareHelper.shareToFacebook(link: link);
          },
        ),
        _shareItem(
          icon: FontAwesomeIcons.copy,
          label: "Copy",
          color: Colors.grey,
          onTap: () {
            Get.back();
            ShareHelper.copyLink(link);
          },
        ),
      ],
    );
  }

  Widget _shareItem({
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 52,
            height: 52,
            decoration: BoxDecoration(
              color: color.withValues(alpha: 0.12),
              shape: BoxShape.circle,
            ),
            alignment: Alignment.center,
            child: FaIcon(icon, color: color, size: 24),
          ),
          const SizedBox(height: 6),
          Text(
            label,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w500),
          ),
        ],
      ),
    );
  }

  Widget _buildActions() {
    return Column(
      children: [
        ListTile(
          leading: const Icon(Icons.share),
          title: const Text("More options"),
          onTap: () {
            Get.back();
            ShareHelper.shareGeneral(title: title, link: link);
          },
        ),
        ListTile(
          leading: const Icon(Icons.link),
          title: const Text("Copy link"),
          onTap: () {
            Get.back();
            ShareHelper.copyLink(link);
          },
        ),
      ],
    );
  }

  Widget _buildDivider() {
    return Divider(color: AppColors.getGreyColor(Get.context!));
  }

  Widget _buildLinkPreview() {
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: AppColors.getCardColor(Get.context!),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          const Icon(Icons.link, size: 16),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              link,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                fontSize: 12,
                color: AppColors.getTextSecondaryColor(Get.context!),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
