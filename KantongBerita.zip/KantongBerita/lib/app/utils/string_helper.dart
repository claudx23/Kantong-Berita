import 'package:html_unescape/html_unescape.dart';

class StringHelper {
  static final _unescape = HtmlUnescape();

  // Decode HTML entities
  // "Tergantung Bupati pak" → "Tergantung Bupati pak"
  static String decodeHtml(String text) {
    return _unescape.convert(text);
  }

  // Strip HTML tags sekaligus decode entities
  static String stripHtml(String htmlString) {
    final stripped = htmlString.replaceAll(
      RegExp(r'<[^>]*>', multiLine: true, caseSensitive: true),
      '',
    );
    return _unescape.convert(stripped).trim();
  }

  // Time ago dalam Bahasa Indonesia
  static String timeAgo(String dateString) {
    try {
      final DateTime postDate = DateTime.parse(dateString);
      final Duration difference = DateTime.now().difference(postDate);

      if (difference.inDays > 30) {
        final months = (difference.inDays / 30).floor();
        return '$months Bulan Yang Lalu';
      } else if (difference.inDays > 7) {
        final weeks = (difference.inDays / 7).floor();
        return '$weeks Minggu Yang Lalu';
      } else if (difference.inDays > 0) {
        return '${difference.inDays} Hari Yang Lalu';
      } else if (difference.inHours > 0) {
        return '${difference.inHours} Jam Yang Lalu';
      } else if (difference.inMinutes > 0) {
        return '${difference.inMinutes} Menit Yang Lalu';
      } else {
        return 'Baru Saja';
      }
    } catch (e) {
      return '';
    }
  }

  // Format tanggal Indonesia
  static String formatDate(String dateString) {
    try {
      final DateTime date = DateTime.parse(dateString);
      final List<String> months = [
        'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
        'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
      ];
      return '${date.day} ${months[date.month - 1]} ${date.year}';
    } catch (e) {
      return dateString;
    }
  }
}