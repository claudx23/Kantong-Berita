import 'dart:async';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:internet_connection_checker_plus/internet_connection_checker_plus.dart';
import 'package:get/get.dart';
import 'app_refresh_service.dart';

class ConnectivityService extends GetxService {
  final _connectivity     = Connectivity();
  final _internetChecker  = InternetConnection();

  final isOnline  = true.obs;

  StreamSubscription? _connectivitySub;
  StreamSubscription? _internetSub;

  Future<ConnectivityService> init() async {
    // ✅ Cek status NYATA saat pertama kali (bukan hanya jenis koneksi)
    final hasInternet = await _internetChecker.hasInternetAccess;
    isOnline.value    = hasInternet;
    // print('📡 Initial internet status: ${hasInternet ? "ONLINE" : "OFFLINE"}');

    // ✅ Listen perubahan koneksi jaringan (WiFi/Mobile berubah)
    _connectivitySub = _connectivity.onConnectivityChanged.listen(
      (results) async {
        // Jika tidak ada jaringan sama sekali → langsung offline
        final hasNetwork = results.any((r) =>
            r == ConnectivityResult.wifi    ||
            r == ConnectivityResult.mobile  ||
            r == ConnectivityResult.ethernet);

        if (!hasNetwork) {
          _setOffline();
          return;
        }

        // Ada jaringan → cek internet sungguhan
        await _checkRealInternet();
      },
    );

    // ✅ Listen perubahan internet sungguhan
    _internetSub = _internetChecker.onStatusChange.listen((status) {
      final online = status == InternetStatus.connected;
      // print('📡 Internet status changed: ${online ? "ONLINE" : "OFFLINE"}');

      final wasOffline = !isOnline.value;
      isOnline.value   = online;

      // Auto-refresh saat kembali online
      if (online && wasOffline) {
        _triggerAutoRefresh();
      }
    });

    return this;
  }

  Future<void> _checkRealInternet() async {
    final hasInternet  = await _internetChecker.hasInternetAccess;
    final wasOffline   = !isOnline.value;
    isOnline.value     = hasInternet;

    // print('📡 Real internet check: ${hasInternet ? "ONLINE" : "OFFLINE"}');

    if (hasInternet && wasOffline) {
      _triggerAutoRefresh();
    }
  }

  void _setOffline() {
    if (isOnline.value) {
      isOnline.value = false;
      // print('📡 No network → OFFLINE');
    }
  }

  void _triggerAutoRefresh() {
    try {
      if (Get.isRegistered<AppRefreshService>()) {
        Get.find<AppRefreshService>().triggerNewPost();
      }
    } catch (e) {
      // print('Error trigger refresh: $e');
    }
  }

  @override
  void onClose() {
    _connectivitySub?.cancel();
    _internetSub?.cancel();
    super.onClose();
  }
}