import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

class CategoryReadCount {
  final int categoryId;
  final String categoryName;
  int count;

  CategoryReadCount({
    required this.categoryId,
    required this.categoryName,
    required this.count,
  });
}

class AutoPreferenceResult {
  final List<int> added;
  final List<int> replaced;
  final List<int> finalUmum;
  final List<int> finalLokal;

  AutoPreferenceResult({
    required this.added,
    required this.replaced,
    required this.finalUmum,
    required this.finalLokal,
  });
}

class ReadingTrackerService extends GetxService {
  final _storage = GetStorage();

  // Threshold baca per kategori sebelum auto-apply
  static const int _readThresholdPerCategory = 5;
  static const int _maxUmum = 5;
  static const int _maxLokal = 3;

  // Sesuaikan dengan ID kategori lokal di WordPress kamu
  static const List<int> lokalIds = [
    3448, // Aceh
    2025, // Bandung
    1745, // Batangtoru
    183, // Belawan
    3863, // Bogor
    3631, // Deli Serdang
    2579, // Gunungsitoli
    1403, // Jakarta
    3851, // Jayapura
    3869, // Keerom
    1810, // Labuhan Batu
    3877, // Lanny Jaya
    1259, // Madina
    2275, // Makassar
    869, // Medan
    3846, // Mimika
    2498, // Nias
    1332, // Padang Lawas
    1862, // Padang Sidempuan
    3860, // Paniai
    3839, // Papua Pegunungan
    3832, // Papua Tengah
    155, // Pilkada Sibolga
    3165, // Pilkada Tapteng
    3063, // Samosir
    37, // Sibolga
    3600, // Surakarta
    1794, // Tapanuli Selatan
    56, // Tapanuli Tengah
    66, // Tapanuli Utara
    2272, // Tebing Tinggi
    863, // Toba
    2973, // Yogyakarta
  ];

  // ==================== STORAGE KEYS (PER USER) ====================

  String _historyKey(String userId) => 'reading_history_$userId';
  String _readPostsKey(String userId) => 'read_posts_$userId';

  // ==================== TRACK ====================

  // Return kategori yang baru mencapai threshold (siap di-apply),
  // atau null jika belum ada yang baru mencapai threshold
  CategoryReadCount? trackRead({
    required int categoryId,
    required String categoryName,
    required int postId,
    required String userId,
  }) {
    if (categoryId <= 0 || userId.isEmpty) return null;

    // Cek duplikat artikel
    final readPosts = _getReadPosts(userId);
    if (readPosts.contains(postId)) {
      // print('📖 Skip duplicate: post $postId');
      return null;
    }

    // Tandai artikel sudah dibaca
    readPosts.add(postId);
    _storage.write(_readPostsKey(userId), readPosts);

    // Update count kategori
    final history = _getHistory(userId);
    final existing = history.firstWhereOrNull(
      (h) => h['category_id'] == categoryId,
    );

    int newCount;

    if (existing != null) {
      existing['count'] = (existing['count'] as int) + 1;
      newCount = existing['count'] as int;
    } else {
      history.add({
        'category_id': categoryId,
        'category_name': categoryName,
        'count': 1,
      });
      newCount = 1;
    }

    _saveHistory(userId, history);

    // ✅ Return kategori ini jika sudah mencapai threshold
    if (newCount >= _readThresholdPerCategory) {
      return CategoryReadCount(
        categoryId: categoryId,
        categoryName: categoryName,
        count: newCount,
      );
    }

    return null;
  }

  // ==================== AUTO-APPLY LOGIC ====================

  // Hitung apakah kategori tertentu sudah mencapai threshold
  // dan layak untuk di-apply ke preferensi
  AutoPreferenceResult? computePreferenceUpdate({
    required CategoryReadCount newCategory,
    required List<int> currentUmum,
    required List<int> currentLokal,
    required String userId,
  }) {
    final isLokal = lokalIds.contains(newCategory.categoryId);

    // Cek apakah sudah ada di preferensi
    final alreadyInUmum = currentUmum.contains(newCategory.categoryId);
    final alreadyInLokal = currentLokal.contains(newCategory.categoryId);

    if (alreadyInUmum || alreadyInLokal) {
      return null;
    }

    final List<int> finalUmum = List.from(currentUmum);
    final List<int> finalLokal = List.from(currentLokal);
    final List<int> added = [];
    final List<int> replaced = [];

    if (isLokal) {
      if (finalLokal.length < _maxLokal) {
        // ✅ Ada slot kosong → langsung tambah
        finalLokal.add(newCategory.categoryId);
        added.add(newCategory.categoryId);
      } else {
        // ❌ Slot penuh → ganti yang paling jarang dibaca
        final toRemove = _findLeastRead(finalLokal, userId);
        if (toRemove != null) {
          finalLokal.remove(toRemove);
          finalLokal.add(newCategory.categoryId);
          replaced.add(toRemove);
          added.add(newCategory.categoryId);
        }
      }
    } else {
      if (finalUmum.length < _maxUmum) {
        // ✅ Ada slot kosong → langsung tambah
        finalUmum.add(newCategory.categoryId);
        added.add(newCategory.categoryId);
      } else {
        // ❌ Slot penuh → ganti yang paling jarang dibaca
        final toRemove = _findLeastRead(finalUmum, userId);
        if (toRemove != null) {
          finalUmum.remove(toRemove);
          finalUmum.add(newCategory.categoryId);
          replaced.add(toRemove);
          added.add(newCategory.categoryId);
        }
      }
    }

    if (added.isEmpty) return null;

    return AutoPreferenceResult(
      added: added,
      replaced: replaced,
      finalUmum: finalUmum,
      finalLokal: finalLokal,
    );
  }

  // ==================== FIND LEAST READ ====================

  // Dari list preferensi saat ini, temukan ID yang paling jarang dibaca
  // (kandidat untuk diganti)
  int? _findLeastRead(List<int> currentPrefs, String userId) {
    if (currentPrefs.isEmpty) return null;

    final history = _getHistory(userId);
    int? leastId;
    int leastCount = 999999;

    for (final prefId in currentPrefs) {
      final entry = history.firstWhereOrNull((h) => h['category_id'] == prefId);
      // Jika tidak ada di history (tidak pernah dibaca) → ini yang paling
      // lemah, langsung pilih ini
      final count = entry != null ? (entry['count'] as int) : 0;
      if (count < leastCount) {
        leastCount = count;
        leastId = prefId;
      }
    }

    return leastId;
  }

  // ==================== SETELAH APPLY ====================

  // Kurangi count kategori yang sudah di-apply (bukan dihapus,
  // biar algoritma tetap belajar pola baca)
  void onPreferencesApplied({
    required List<int> addedCategoryIds,
    required String userId,
  }) {
    if (addedCategoryIds.isEmpty) return;

    final history = _getHistory(userId);

    for (final id in addedCategoryIds) {
      final entry = history.firstWhereOrNull((h) => h['category_id'] == id);

      if (entry != null) {
        final current = entry['count'] as int;
        // Kurangi separuh — tetap simpan sisa pola baca
        entry['count'] = (current / 2).floor();
      }
    }

    // Hapus entri count 0
    history.removeWhere((h) => (h['count'] as int) <= 0);
    _saveHistory(userId, history);
  }

  // ==================== STATS ====================

  List<CategoryReadCount> getTopCategories(String userId) {
    return _getHistory(userId)
        .map(
          (h) => CategoryReadCount(
            categoryId: h['category_id'] as int,
            categoryName: h['category_name'] as String,
            count: h['count'] as int,
          ),
        )
        .toList()
      ..sort((a, b) => b.count.compareTo(a.count));
  }

  // ==================== STORAGE HELPERS ====================

  List<Map<String, dynamic>> _getHistory(String userId) {
    final stored = _storage.read<List>(_historyKey(userId));
    if (stored == null) return [];
    return stored.map((e) => Map<String, dynamic>.from(e as Map)).toList();
  }

  void _saveHistory(String userId, List<Map<String, dynamic>> history) {
    _storage.write(_historyKey(userId), history);
  }

  List<int> _getReadPosts(String userId) {
    final stored = _storage.read<List>(_readPostsKey(userId));
    if (stored == null) return [];
    return stored.cast<int>();
  }

  void clearForUser(String userId) {
    _storage.remove(_historyKey(userId));
    _storage.remove(_readPostsKey(userId));
  }
}
