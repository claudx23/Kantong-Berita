import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import '../data/models/post_model.dart';

class PostCacheService extends GetxService {
  final _storage  = GetStorage();

  // Prefix key per post
  static const String _prefix   = 'post_cache_';

  // Maksimal post yang di-cache (hemat storage)
  static const int    _maxCache = 50;

  // Key untuk menyimpan daftar ID yang sudah di-cache (FIFO)
  static const String _indexKey = 'post_cache_index';
  
  // ==================== SAVE ====================

  void cachePost(PostModel post) {
    final key = _prefix + post.id.toString();

    // Simpan konten post
    _storage.write(key, post.toJson());

    // Update index (daftar ID ter-cache)
    _updateIndex(post.id);

    // print('💾 Post cached: ${post.id} - ${post.title}');
  }

  // ==================== GET ====================

  PostModel? getCachedPost(int postId) {
    final key  = _prefix + postId.toString();
    final data = _storage.read<Map>(key);

    if (data == null) return null;

    return PostModel.fromCache(
      Map<String, dynamic>.from(data),
    );
  }

  bool hasCachedPost(int postId) {
    return _storage.hasData(_prefix + postId.toString());
  }

  // ==================== CLEANUP ====================

  // Hapus cache post tertentu
  void removeCachedPost(int postId) {
    _storage.remove(_prefix + postId.toString());
    _removeFromIndex(postId);
  }

  // Hapus semua cache
  void clearAll() {
    final index = _getIndex();
    for (final id in index) {
      _storage.remove(_prefix + id.toString());
    }
    _storage.remove(_indexKey);
    // print('🗑️ All post cache cleared');
  }

  // ==================== INDEX (FIFO limit) ====================

  List<int> _getIndex() {
    final stored = _storage.read<List>(_indexKey);
    if (stored == null) return [];
    return stored.cast<int>();
  }

  void _updateIndex(int postId) {
    final index = _getIndex();

    // Hapus jika sudah ada (re-insert ke depan = fresh)
    index.remove(postId);
    index.insert(0, postId);

    // Jika melebihi batas, hapus yang paling lama (belakang)
    if (index.length > _maxCache) {
      final toRemove = index.sublist(_maxCache);
      for (final id in toRemove) {
        _storage.remove(_prefix + id.toString());
      }
      index.removeRange(_maxCache, index.length);
    }

    _storage.write(_indexKey, index);
  }

  void _removeFromIndex(int postId) {
    final index = _getIndex();
    index.remove(postId);
    _storage.write(_indexKey, index);
  }
}