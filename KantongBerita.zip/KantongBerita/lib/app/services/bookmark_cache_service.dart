import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import '../data/models/bookmark_model.dart';

class BookmarkCacheService extends GetxService {
  static const String _key = 'local_bookmarks';
  final GetStorage _storage = GetStorage();

  // ==================== SAVE ====================

  void saveBookmarks(List<BookmarkModel> bookmarks) {
    try {
      final data = bookmarks.map((b) => _toMap(b)).toList();
      _storage.write(_key, data);

     
      // final verify = _storage.read<List>(_key);
      // print(
      //   '💾 Saved ${data.length} bookmarks | Verified: ${verify?.length ?? 0}',
      // );
    } catch (e) {
      // print('❌ Error saving bookmarks: $e');
    }
  }

  void addBookmark(BookmarkModel bookmark) {
    try {
      final current = _getRawList();
      if (current.any((b) => b['id'] == bookmark.id)) return;

      current.insert(0, _toMap(bookmark));
      _storage.write(_key, current);
    } catch (e) {
      // print('❌ Error adding bookmark: $e');
    }
  }

  void removeBookmark(int postId) {
    try {
      final current = _getRawList();
      current.removeWhere((b) => b['id'] == postId);
      _storage.write(_key, current);
    } catch (e) {
      // print('❌ Error removing bookmark: $e');
    }
  }

  // ==================== GET ====================

  List<BookmarkModel> getLocalBookmarks() {
    try {
      final raw = _getRawList();
      final result = raw.map((b) => BookmarkModel.fromJson(b)).toList();
      return result;
    } catch (e) {
      // print('❌ Error reading bookmarks: $e');
      return [];
    }
  }

  bool isBookmarked(int postId) {
    return _getRawList().any((b) => b['id'] == postId);
  }

  // ==================== CLEAR ====================

  void clearAll() {
    _storage.remove(_key);
  }

  // ==================== PRIVATE ====================

  List<Map<String, dynamic>> _getRawList() {
    try {
      final stored = _storage.read<List>(_key);
      if (stored == null) return [];
      return stored.map((e) => Map<String, dynamic>.from(e as Map)).toList();
    } catch (e) {
      // print('❌ Error reading raw list: $e');
      return [];
    }
  }

  Map<String, dynamic> _toMap(BookmarkModel b) => {
    'id': b.id,
    'title': b.title,
    'excerpt': b.excerpt,
    'featured_image': b.featuredImage,
    'date': b.date,
    'category_name': b.categoryName,
    'link': b.link,
  };
}
