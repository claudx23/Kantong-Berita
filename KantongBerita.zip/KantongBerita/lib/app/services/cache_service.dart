import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

class CacheService extends GetxService {
  final _storage = GetStorage();

  // Cache expiry duration
  static const Duration _postsCacheDuration = Duration(minutes: 15);
  static const Duration _categoryCacheDuration = Duration(hours: 24);

  // ==================== SAVE ====================

  void savePosts(String key, List<dynamic> posts) {
    _storage.write(key, {
      'data': posts,
      'timestamp': DateTime.now().millisecondsSinceEpoch,
    });
  }

  void saveCategories(Map<String, int> categories) {
    _storage.write('categories', {
      'data': categories,
      'timestamp': DateTime.now().millisecondsSinceEpoch,
    });
  }

  // ==================== GET ====================

  List<dynamic>? getPosts(String key) {
    final cached = _storage.read(key);
    if (cached == null) return null;

    final age = _getAge(cached['timestamp'] as int);
    if (age > _postsCacheDuration.inMilliseconds) return null;

    return cached['data'] as List<dynamic>;
  }

  Map<String, int>? getCategories() {
    final cached = _storage.read('categories');
    if (cached == null) return null;

    final age = _getAge(cached['timestamp'] as int);
    if (age > _categoryCacheDuration.inMilliseconds) return null;

    return Map<String, int>.from(cached['data']);
  }

  // Get cache meskipun expired (untuk stale-while-revalidate)
  List<dynamic>? getStalePostsCache(String key) {
    final cached = _storage.read(key);
    if (cached == null) return null;
    return cached['data'] as List<dynamic>;
  }

  bool isCacheExpired(String key) {
    final cached = _storage.read(key);
    if (cached == null) return true;
    return _getAge(cached['timestamp'] as int) >
        _postsCacheDuration.inMilliseconds;
  }

  void savePreferences(List<int> categoryIds) {
    _storage.write('user_preferences', {
      'data': categoryIds,
      'timestamp': DateTime.now().millisecondsSinceEpoch,
    });
  }

  List<int>? getCachedPreferences() {
    final cached = _storage.read('user_preferences');
    if (cached == null) return null;
    return List<int>.from(cached['data'] ?? []);
  }

  void clearPreferences() {
    _storage.remove('user_preferences');
  }

  void savePersonalPosts(List<dynamic> posts) {
    _storage.write('personal_posts', {
      'data': posts,
      'timestamp': DateTime.now().millisecondsSinceEpoch,
    });
  }

  // ✅ Ambil personal posts (fresh)
  List<dynamic>? getPersonalPosts() {
    final cached = _storage.read('personal_posts');
    if (cached == null) return null;

    final age = _getAge(cached['timestamp'] as int);
    if (age > _postsCacheDuration.inMilliseconds) return null;

    return cached['data'] as List<dynamic>;
  }

  // ✅ Ambil personal posts meski expired (untuk offline)
  List<dynamic>? getStalePersonalPosts() {
    final cached = _storage.read('personal_posts');
    if (cached == null) return null;

    return cached['data'] as List<dynamic>;
  }

  // ==================== CLEAR ====================

  void clearPostsCache() {
    final keys = _storage.getKeys<Iterable<String>>();
    for (final key in keys) {
      if (key.startsWith('posts_')) {
        _storage.remove(key);
      }
    }
    _storage.remove('personal_posts');
  }

  void clearAll() {
    _storage.erase();
  }

  void clearUserSpecificData() {
    _storage.remove('personal_posts');
    _storage.remove('user_preferences');
  }

  int _getAge(int timestamp) =>
      DateTime.now().millisecondsSinceEpoch - timestamp;
}
