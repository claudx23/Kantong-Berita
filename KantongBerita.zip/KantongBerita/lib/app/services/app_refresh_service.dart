import 'package:get/get.dart';

class AppRefreshService extends GetxService {

  // ✅ Counter untuk trigger refresh
  // Setiap kali di-increment, HomeController akan refresh
  final newPostTrigger        = 0.obs; // Dari FCM
  final preferencesTrigger    = 0.obs; // Dari ubah preferensi

  // Trigger refresh berita baru
  void triggerNewPost() {
    newPostTrigger.value++;
    // print('🔔 AppRefreshService: new post trigger #${newPostTrigger.value}');
  }

  // Trigger refresh preferensi
  void triggerPreferencesChanged() {
    preferencesTrigger.value++;
    // print('⚙️ AppRefreshService: preferences trigger #${preferencesTrigger.value}');
  }
}