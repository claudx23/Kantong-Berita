import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_sign_in/google_sign_in.dart';

class SocialAuthResult {
  final String provider;
  final String email;
  final String name;
  final String socialId;
  final String? avatarUrl;

  SocialAuthResult({
    required this.provider,
    required this.email,
    required this.name,
    required this.socialId,
    this.avatarUrl,
  });
}

class SocialAuthService {
  // ✅ Ganti dengan Web Client ID dari Firebase Console
  static const String _googleWebClientId =
      '339525189148-uilaaj1r8u99lsi4p5q476n792083n9r.apps.googleusercontent.com';

  final GoogleSignIn _googleSignIn = GoogleSignIn(
    clientId: _googleWebClientId,
    scopes: ['email', 'profile'],
  );

  // ==================== GOOGLE ====================

  Future<SocialAuthResult?> signInWithGoogle() async {
    try {
      // Sign out dulu agar selalu muncul account picker
      await _googleSignIn.signOut();

      final GoogleSignInAccount? googleUser = await _googleSignIn.signIn();

      if (googleUser == null) {
        // print('Google Sign-In dibatalkan user');
        return null;
      }

      return SocialAuthResult(
        provider: 'google',
        email: googleUser.email,
        name: googleUser.displayName ?? '',
        socialId: googleUser.id,
        avatarUrl: googleUser.photoUrl,
      );
    } catch (e) {
      // print('Google Sign-In Error: $e');
      _showError('Gagal login dengan Google: $e');
      return null;
    }
  }

  // ==================== SIGN OUT ====================

  Future<void> signOutGoogle() async {
    try {
      await _googleSignIn.signOut();
    } catch (e) {
      // print('Error sign out Google: $e');
    }
  }

  // ==================== HELPER ====================

  void _showError(String message) {
    Get.snackbar(
      'Error',
      message,
      snackPosition: SnackPosition.TOP,
      backgroundColor: Colors.red,
      colorText: Colors.white,
      duration: const Duration(seconds: 4),
    );
  }
}
