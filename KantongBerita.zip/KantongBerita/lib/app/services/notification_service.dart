import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import '../data/providers/api_provider.dart';
import '../modules/notifications/controllers/notifications_controller.dart';
import '../routes/app_routes.dart';
import 'app_refresh_service.dart';

@pragma('vm:entry-point')
Future<void> firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  // print('📩 Background message: ${message.messageId}');
  // await NotificationService._showLocalNotification(message);
}

class NotificationService extends GetxService {
  static final FlutterLocalNotificationsPlugin _localNotifications =
      FlutterLocalNotificationsPlugin();

  static const AndroidNotificationChannel _channel = AndroidNotificationChannel(
    'kantong_berita_channel',
    'Kantong Berita Notifications',
    description: 'Notifikasi berita terbaru dari Kantong Berita',
    importance: Importance.high,
    playSound: true,
  );

  final FirebaseMessaging _messaging = FirebaseMessaging.instance;
  final _storage = GetStorage();

  // Storage keys
  static const String _subscribedTopicsKey = 'subscribed_topics';

  // Topic constants
  static const String topicBeritaUtama = 'berita_utama';
  static const String topicBreakingNews = 'breaking_news';

  // ==================== INIT ====================

  Future<NotificationService> init() async {
    await _initLocalNotifications();
    await _requestPermission();
    _setupMessageHandlers();

    // Guest otomatis subscribe ke berita_utama
    await _ensureGuestSubscription();

    return this;
  }

  // Guest subscribe ke berita_utama & breaking_news
  Future<void> _ensureGuestSubscription() async {
    final topics = _getStoredTopics().toSet();

    if (!topics.contains(topicBeritaUtama)) {
      await _safeSubscribe(topicBeritaUtama);
      topics.add(topicBeritaUtama);
    }

    if (!topics.contains(topicBreakingNews)) {
      await _safeSubscribe(topicBreakingNews);
      topics.add(topicBreakingNews);
    }

    _saveTopicsToStorage(topics.toList());
  }

  // ==================== DIFF-BASED SUBSCRIPTION ====================

  // Dipanggil saat preferensi berubah atau setelah login
  static Future<void> updateSubscriptions(List<int> categoryIds) async {
    final instance = Get.find<NotificationService>();
    await instance._updateSubscriptionsInternal(categoryIds);
  }

  Future<void> _updateSubscriptionsInternal(List<int> categoryIds) async {
    // Topics baru yang diinginkan
    final Set<String> desiredTopics = {
      topicBeritaUtama,
      topicBreakingNews,
      ...categoryIds.map((id) => 'cat_$id'),
    };

    // Topics yang sekarang tersimpan di device
    final Set<String> currentTopics = _getStoredTopics().toSet();

    // Hitung diff - hanya proses yang berubah
    final Set<String> toSubscribe = desiredTopics.difference(currentTopics);
    final Set<String> toUnsubscribe = currentTopics.difference(desiredTopics);

    // print('📊 Topic diff:');
    // print('   Subscribe: $toSubscribe');
    // print('   Unsubscribe: $toUnsubscribe');

    // Subscribe topics baru
    for (final topic in toSubscribe) {
      await _safeSubscribe(topic);
    }

    // Unsubscribe topics yang tidak dipakai
    for (final topic in toUnsubscribe) {
      await _safeUnsubscribe(topic);
    }

    // Simpan state terbaru ke storage
    _saveTopicsToStorage(desiredTopics.toList());

    // print('✅ Subscription updated. Total: ${desiredTopics.length} topics');
  }

  // Dipanggil saat logout - hapus semua subscription
  static Future<void> clearSubscriptions() async {
    final instance = Get.find<NotificationService>();
    await instance._clearSubscriptionsInternal();
  }

  Future<void> _clearSubscriptionsInternal() async {
    final currentTopics = _getStoredTopics();

    // print('🗑️ Clearing ${currentTopics.length} subscriptions...');

    await Future.wait(currentTopics.map((topic) => _safeUnsubscribe(topic)));
    // Clear storage
    _storage.remove(_subscribedTopicsKey);

    // Re-subscribe ke berita_utama untuk guest
    await _ensureGuestSubscription();

    // print('✅ Subscriptions cleared, re-subscribed as guest');
  }

  // ==================== SAFE SUBSCRIBE/UNSUBSCRIBE ====================
  // Graceful - jika gagal tidak error, preferensi tetap tersimpan

  Future<void> _safeSubscribe(String topic) async {
    try {
      await _messaging.subscribeToTopic(topic);
      // print('✅ Subscribed: $topic');
    } catch (e) {
      // Silent fail - jangan crash app
      // print('⚠️ Failed to subscribe to $topic: $e');
    }
  }

  Future<void> _safeUnsubscribe(String topic) async {
    try {
      await _messaging.unsubscribeFromTopic(topic);
      // print('✅ Unsubscribed: $topic');
    } catch (e) {
      // Silent fail
      // print('⚠️ Failed to unsubscribe from $topic: $e');
    }
  }

  // ==================== STORAGE HELPERS ====================

  List<String> _getStoredTopics() {
    final stored = _storage.read<List>(_subscribedTopicsKey);
    if (stored == null) return [];
    return stored.map((e) => e.toString()).toList();
  }

  void _saveTopicsToStorage(List<String> topics) {
    _storage.write(_subscribedTopicsKey, topics);
  }

  // ==================== LOCAL NOTIFICATIONS ====================

  Future<void> _initLocalNotifications() async {
    const AndroidInitializationSettings androidSettings =
        AndroidInitializationSettings('@mipmap/ic_launcher');

    const DarwinInitializationSettings iosSettings =
        DarwinInitializationSettings(
          requestAlertPermission: true,
          requestBadgePermission: true,
          requestSoundPermission: true,
        );

    const InitializationSettings initSettings = InitializationSettings(
      android: androidSettings,
      iOS: iosSettings,
    );

    await _localNotifications.initialize(
      initSettings,
      onDidReceiveNotificationResponse: _onNotificationTapped,
    );

    await _localNotifications
        .resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin
        >()
        ?.createNotificationChannel(_channel);
  }

  // ==================== PERMISSION ====================

  Future<void> _requestPermission() async {
    await _messaging.requestPermission(alert: true, badge: true, sound: true);
    // print('🔔 Permission: ${settings.authorizationStatus}');
  }

  // ==================== MESSAGE HANDLERS ====================

  void _setupMessageHandlers() {
    FirebaseMessaging.onMessage.listen((message) {
      // _showLocalNotification(message);
      _refreshUnreadCount();
      _triggerNewPostRefresh(message);
    });

    FirebaseMessaging.onMessageOpenedApp.listen((message) {
      _refreshUnreadCount();
      _triggerNewPostRefresh(message);

      Future.delayed(const Duration(milliseconds: 500), () {
        _handleNotificationTap(message.data);
      });
    });

    _checkInitialMessage();
  }

  void _triggerNewPostRefresh(RemoteMessage message) {
    // Hanya trigger untuk notif type 'post'
    final type = message.data['type'] ?? '';
    if (type != 'post') return;

    try {
      if (Get.isRegistered<AppRefreshService>()) {
        Get.find<AppRefreshService>().triggerNewPost();
      }
    } catch (e) {
      // print('Error triggering refresh: $e');
    }
  }

  void _refreshUnreadCount() {
    try {
      if (Get.isRegistered<NotificationsController>()) {
        Get.find<NotificationsController>().fetchUnreadCount();
      }
    } catch (e) {
      // print('Error refreshing unread count: $e');
    }
  }

  Future<void> _checkInitialMessage() async {
    final initial = await _messaging.getInitialMessage();

    if (initial != null) {

      await Future.delayed(const Duration(milliseconds: 1500));
      _handleNotificationTap(initial.data);
      _refreshUnreadCount();
    }
  }

  // static Future<void> _showLocalNotification(RemoteMessage message) async {
  //   final notification = message.notification;
  //   if (notification == null) return;

  //   final androidDetails = AndroidNotificationDetails(
  //     _channel.id,
  //     _channel.name,
  //     channelDescription: _channel.description,
  //     icon: '@mipmap/ic_launcher',
  //     importance: Importance.high,
  //     priority: Priority.high,
  //     styleInformation: notification.body != null
  //         ? BigTextStyleInformation(notification.body!)
  //         : null,
  //   );

  //   const iosDetails = DarwinNotificationDetails(
  //     presentAlert: true,
  //     presentBadge: true,
  //     presentSound: true,
  //   );

  //   await _localNotifications.show(
  //     notification.hashCode,
  //     notification.title,
  //     notification.body,
  //     NotificationDetails(android: androidDetails, iOS: iosDetails),
  //     payload: message.data['post_id']?.toString(),
  //   );
  // }

  // ==================== HANDLE TAP ====================

  void _onNotificationTapped(NotificationResponse response) {

    final postId = response.payload;
    if (postId != null && postId.isNotEmpty) {
      final id = int.tryParse(postId) ?? 0;
      if (id > 0) {
        _navigateToPost(id);
      }
    }
  }

  void _handleNotificationTap(Map<String, dynamic> data) {

    final postId = data['post_id'];

    if (postId != null && postId.toString().isNotEmpty) {
      final id = int.tryParse(postId.toString()) ?? 0;
      if (id > 0) {
        _navigateToPost(id);
      }
    }
  }

  Future<void> _navigateToPost(int postId) async {
    if (postId <= 0) return;

    try {

      final api = Get.find<ApiProvider>();
      final post = await api.fetchPostById(postId);

      // Pastikan navigate ke main dulu jika belum di sana
      if (Get.currentRoute != AppRoutes.main) {
        Get.offAllNamed(AppRoutes.main);
        await Future.delayed(const Duration(milliseconds: 300));
      }

      Get.toNamed(AppRoutes.postDetail, arguments: post);
    } catch (e) {
      // print('Error navigating to post $postId: $e');
    }
  }
}
