import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

class CommentModerationService extends GetxService {
  final _storage = GetStorage();

  static const _cooldownKey = 'comment_cooldown_until';
  static const _lastCommentKey = 'last_comment';
  static const _duplicateKey = 'duplicate_comment_count';
  static const _lastTimeKey = 'last_comment_time';

  static const cooldownHours = 24;
  static const rateLimitSeconds = 30;

  final List<String> bannedWords = [
    'slot',
    'casino',
    'judi',
    'gacor',
    'deposit',
    'bet',
    'qq',
    'admin slot',
    'bokep',
    'porno',
    'sex',
    'hack',
  ];

  bool isCooldownActive() {
    final until = _storage.read(_cooldownKey);

    if (until == null) return false;

    return DateTime.now().millisecondsSinceEpoch < until;
  }

  Duration remainingCooldown() {
    final until = _storage.read(_cooldownKey);

    if (until == null) return Duration.zero;

    return DateTime.fromMillisecondsSinceEpoch(until)
        .difference(DateTime.now());
  }

  bool containsBannedWord(String text) {
    final lower = text.toLowerCase();

    return bannedWords.any((word) => lower.contains(word));
  }

  bool containsSpamLink(String text) {
    final regex = RegExp(
      r'(http|https|www\.|bit\.ly|t\.me|wa\.me)',
      caseSensitive: false,
    );

    return regex.hasMatch(text);
  }

  bool containsRepeatedCharacters(String text) {
    final regex = RegExp(r'(.)\1{8,}');
    return regex.hasMatch(text);
  }

  bool isRateLimited() {
    final last = _storage.read(_lastTimeKey);

    if (last == null) return false;

    final diff = DateTime.now().difference(
      DateTime.fromMillisecondsSinceEpoch(last),
    );

    return diff.inSeconds < rateLimitSeconds;
  }

  int remainingRateLimit() {
    final last = _storage.read(_lastTimeKey);

    if (last == null) return 0;

    final diff = DateTime.now().difference(
      DateTime.fromMillisecondsSinceEpoch(last),
    );

    return (rateLimitSeconds - diff.inSeconds).clamp(0, rateLimitSeconds);
  }

  bool checkDuplicateSpam(String comment) {
    final lastComment = _storage.read(_lastCommentKey);

    int count = _storage.read(_duplicateKey) ?? 0;

    if (lastComment == comment) {
      count++;
    } else {
      count = 1;
    }

    _storage.write(_lastCommentKey, comment);
    _storage.write(_duplicateKey, count);

    if (count >= 3) {
      activateCooldown();
      return true;
    }

    return false;
  }

  void activateCooldown() {
    _storage.write(
      _cooldownKey,
      DateTime.now()
          .add(const Duration(hours: cooldownHours))
          .millisecondsSinceEpoch,
    );
  }

  void onCommentSuccess() {
    _storage.write(
      _lastTimeKey,
      DateTime.now().millisecondsSinceEpoch,
    );
  }
}