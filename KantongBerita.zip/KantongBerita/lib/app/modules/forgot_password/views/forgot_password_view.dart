import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pinput/pinput.dart';
import '../controllers/forgot_password_controller.dart';
import '../../../utils/app_colors.dart';

class ForgotPasswordView extends GetView<ForgotPasswordController> {
  const ForgotPasswordView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.getBackgroundColor(context),
      appBar: AppBar(
        backgroundColor: AppColors.getBackgroundColor(context),
        elevation: 0,
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back,
            color: AppColors.getTextPrimaryColor(context),
          ),
          onPressed: controller.goBack,
        ),
        title: Obx(
          () => Text(
            _getTitle(),
            style: TextStyle(
              color: AppColors.getTextPrimaryColor(context),
              fontWeight: FontWeight.bold,
              fontSize: 18,
            ),
          ),
        ),
      ),
      body: SafeArea(
        child: Obx(() {
          switch (controller.currentStep.value) {
            case ForgotPasswordStep.email:
              return _buildEmailStep();
            case ForgotPasswordStep.otp:
              return _buildOtpStep();
            case ForgotPasswordStep.newPassword:
              return _buildNewPasswordStep();
          }
        }),
      ),
    );
  }

  String _getTitle() {
    switch (controller.currentStep.value) {
      case ForgotPasswordStep.email:
        return 'Lupa Password';
      case ForgotPasswordStep.otp:
        return 'Verifikasi OTP';
      case ForgotPasswordStep.newPassword:
        return 'Password Baru';
    }
  }

  // ==================== STEP INDICATOR ====================

  Widget _buildStepIndicator() {
    return Obx(() {
      final step = controller.currentStep.value;
      return Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
        child: Row(
          children: [
            _buildStep(1, step.index >= 0, 'Email'),
            _buildStepLine(step.index >= 1),
            _buildStep(2, step.index >= 1, 'OTP'),
            _buildStepLine(step.index >= 2),
            _buildStep(3, step.index >= 2, 'Password'),
          ],
        ),
      );
    });
  }

  Widget _buildStep(int number, bool isActive, String label) {
    return Column(
      children: [
        Container(
          width: 32,
          height: 32,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: isActive
                ? const Color(0xFFD32F2F)
                : AppColors.getTextPrimaryColor(Get.context!),
          ),
          child: Center(
            child: Text(
              '$number',
              style: TextStyle(
                color: isActive
                    ? AppColors.getBackgroundColor(Get.context!)
                    : AppColors.getGreyColor(Get.context!),
                fontWeight: FontWeight.bold,
                fontSize: 14,
              ),
            ),
          ),
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: TextStyle(
            fontSize: 11,
            color: isActive
                ? const Color(0xFFD32F2F)
                : AppColors.getTextSecondaryColor(Get.context!),
            fontWeight: isActive ? FontWeight.bold : FontWeight.normal,
          ),
        ),
      ],
    );
  }

  Widget _buildStepLine(bool isActive) {
    return Expanded(
      child: Container(
        height: 2,
        margin: const EdgeInsets.only(bottom: 20),
        color: isActive
            ? const Color(0xFFD32F2F)
            : AppColors.getTextPrimaryColor(Get.context!),
      ),
    );
  }

  // ==================== STEP 1: EMAIL ====================

  Widget _buildEmailStep() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildStepIndicator(),

          const SizedBox(height: 16),

          // Icon
          Center(
            child: Container(
              width: 80,
              height: 80,
              decoration: BoxDecoration(
                color: const Color(0xFFD32F2F).withValues(alpha: 0.3),
                shape: BoxShape.circle,
              ),
              child: const Icon(
                Icons.lock_reset,
                size: 40,
                color: Color(0xFFD32F2F),
              ),
            ),
          ),

          const SizedBox(height: 24),

          Text(
            'Masukkan Email Anda',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: AppColors.getTextPrimaryColor(Get.context!),
            ),
          ),

          const SizedBox(height: 8),

          Text(
            'Kami akan mengirimkan kode OTP 6 digit ke email Anda untuk reset password.',
            style: TextStyle(
              fontSize: 14,
              color: AppColors.getTextPrimaryColor(Get.context!),
              height: 1.5,
            ),
          ),

          const SizedBox(height: 32),

          // Email field
          TextField(
            style: TextStyle(
              color: AppColors.getTextPrimaryColor(Get.context!),
            ),
            controller: controller.emailController,
            keyboardType: TextInputType.emailAddress,
            decoration: InputDecoration(
              hintText: 'Masukkan email Anda',
              prefixIcon: const Icon(Icons.email_outlined),
              filled: true,
              fillColor: AppColors.getCardColor(Get.context!),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(
                  color: AppColors.getBorderColor(Get.context!),
                ),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(
                  color: AppColors.getBorderColor(Get.context!),
                ),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: const BorderSide(color: Color(0xFFD32F2F)),
              ),
            ),
          ),

          const SizedBox(height: 24),

          // Submit button
          Obx(
            () => SizedBox(
              width: double.infinity,
              height: 50,
              child: ElevatedButton(
                onPressed: controller.isLoading.value
                    ? null
                    : controller.sendOtp,
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFD32F2F),
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  elevation: 0,
                ),
                child: controller.isLoading.value
                    ? const SizedBox(
                        width: 24,
                        height: 24,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          color: Colors.white,
                        ),
                      )
                    : const Text(
                        'Kirim Kode OTP',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ==================== STEP 2: OTP ====================

  Widget _buildOtpStep() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildStepIndicator(),

          const SizedBox(height: 16),

          // Icon
          Center(
            child: Container(
              width: 80,
              height: 80,
              decoration: BoxDecoration(
                color: const Color(0xFFD32F2F).withValues(alpha: 0.3),
                shape: BoxShape.circle,
              ),
              child: const Icon(
                Icons.mark_email_read_outlined,
                size: 40,
                color: Color(0xFFD32F2F),
              ),
            ),
          ),

          const SizedBox(height: 24),

          Text(
            'Masukkan Kode OTP',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: AppColors.getTextPrimaryColor(Get.context!),
            ),
          ),

          const SizedBox(height: 8),

          Obx(
            () => RichText(
              text: TextSpan(
                style: TextStyle(
                  fontSize: 14,
                  color: Colors.grey[600],
                  height: 1.5,
                ),
                children: [
                  const TextSpan(text: 'Kode OTP 6 digit telah dikirim ke '),
                  TextSpan(
                    text: controller.maskedEmail.value,
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      color: AppColors.getTextPrimaryColor(Get.context!),
                    ),
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 32),

          // OTP Input
          Obx(
            () => Pinput(
              length: 6,
              enabled: !controller.isLoading.value,
              keyboardType: TextInputType.number,

              defaultPinTheme: PinTheme(
                width: 52,
                height: 56,
                textStyle: const TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                ),
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.grey.shade300),
                  borderRadius: BorderRadius.circular(12),
                ),
              ),

              focusedPinTheme: PinTheme(
                width: 52,
                height: 56,
                textStyle: const TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                ),
                decoration: BoxDecoration(
                  border: Border.all(color: const Color(0xFFD32F2F), width: 2),
                  borderRadius: BorderRadius.circular(12),
                ),
              ),

              submittedPinTheme: PinTheme(
                width: 52,
                height: 56,
                textStyle: const TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                ),
                decoration: BoxDecoration(
                  color: const Color(0xFFD32F2F).withValues(alpha: 0.05),
                  border: Border.all(color: const Color(0xFFD32F2F)),
                  borderRadius: BorderRadius.circular(12),
                ),
              ),

              onChanged: (value) {
                controller.otpValue.value = value;
              },

              onCompleted: (value) {
                controller.otpValue.value = value;

                // Auto verify
                controller.verifyOtp();
              },
            ),
          ),

          const SizedBox(height: 24),

          // Verify button
          Obx(
            () => SizedBox(
              width: double.infinity,
              height: 50,
              child: ElevatedButton(
                onPressed: controller.isLoading.value
                    ? null
                    : controller.verifyOtp,
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFD32F2F),
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  elevation: 0,
                ),
                child: controller.isLoading.value
                    ? const SizedBox(
                        width: 24,
                        height: 24,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          color: Colors.white,
                        ),
                      )
                    : const Text(
                        'Verifikasi OTP',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
              ),
            ),
          ),

          const SizedBox(height: 20),

          // Resend OTP
          Center(
            child: Obx(
              () => controller.canResend.value
                  ? TextButton(
                      onPressed: controller.resendOtp,
                      child: const Text(
                        'Kirim ulang kode OTP',
                        style: TextStyle(
                          color: Color(0xFFD32F2F),
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    )
                  : RichText(
                      text: TextSpan(
                        style: TextStyle(fontSize: 14, color: Colors.grey[500]),
                        children: [
                          const TextSpan(text: 'Kirim ulang dalam '),
                          TextSpan(
                            text: '${controller.countdown.value}s',
                            style: const TextStyle(
                              color: Color(0xFFD32F2F),
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),
            ),
          ),
        ],
      ),
    );
  }

  // ==================== STEP 3: NEW PASSWORD ====================

  Widget _buildNewPasswordStep() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildStepIndicator(),

          const SizedBox(height: 16),

          // Icon
          Center(
            child: Container(
              width: 80,
              height: 80,
              decoration: BoxDecoration(
                color: Colors.green.withValues(alpha: 0.3),
                shape: BoxShape.circle,
              ),
              child: const Icon(
                Icons.lock_open_outlined,
                size: 40,
                color: Colors.green,
              ),
            ),
          ),

          const SizedBox(height: 24),

          Text(
            'Buat Password Baru',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: AppColors.getTextPrimaryColor(Get.context!),
            ),
          ),

          const SizedBox(height: 8),

          Text(
            'Password baru minimal 6 karakter.',
            style: TextStyle(fontSize: 14, color: Colors.grey[600]),
          ),

          const SizedBox(height: 32),

          // New password
          Obx(
            () => TextField(
              style: TextStyle(
                color: AppColors.getTextPrimaryColor(Get.context!),
              ),
              controller: controller.newPasswordController,
              obscureText: !controller.isPasswordVisible.value,
              decoration: InputDecoration(
                labelText: 'Password Baru',
                floatingLabelBehavior: FloatingLabelBehavior.never,
                prefixIcon: const Icon(Icons.lock_outline),
                suffixIcon: GestureDetector(
                  onTap: controller.togglePasswordVisibility,
                  child: Icon(
                    controller.isPasswordVisible.value
                        ? Icons.visibility
                        : Icons.visibility_off,
                    color: Colors.grey,
                  ),
                ),
                filled: true,
                fillColor: AppColors.getCardColor(Get.context!),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(
                    color: AppColors.getBorderColor(Get.context!),
                  ),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(
                    color: AppColors.getBorderColor(Get.context!),
                  ),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: const BorderSide(color: Color(0xFFD32F2F)),
                ),
              ),
            ),
          ),

          const SizedBox(height: 16),

          // Confirm password
          Obx(
            () => TextField(
              style: TextStyle(
                color: AppColors.getTextPrimaryColor(Get.context!),
              ),
              controller: controller.confirmPasswordController,
              obscureText: !controller.isConfirmVisible.value,
              decoration: InputDecoration(
                labelText: 'Konfirmasi Password',
                floatingLabelBehavior: FloatingLabelBehavior.never,
                prefixIcon: const Icon(Icons.lock_outline),
                suffixIcon: GestureDetector(
                  onTap: controller.toggleConfirmVisibility,
                  child: Icon(
                    controller.isConfirmVisible.value
                        ? Icons.visibility
                        : Icons.visibility_off,
                    color: Colors.grey,
                  ),
                ),
                filled: true,
                fillColor: AppColors.getCardColor(Get.context!),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(
                    color: AppColors.getBorderColor(Get.context!),
                  ),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(
                    color: AppColors.getBorderColor(Get.context!),
                  ),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: const BorderSide(color: Color(0xFFD32F2F)),
                ),
              ),
            ),
          ),

          const SizedBox(height: 24),

          // Reset button
          Obx(
            () => SizedBox(
              width: double.infinity,
              height: 50,
              child: ElevatedButton(
                onPressed: controller.isLoading.value
                    ? null
                    : controller.resetPassword,
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFD32F2F),
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  elevation: 0,
                ),
                child: controller.isLoading.value
                    ? const SizedBox(
                        width: 24,
                        height: 24,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          color: Colors.white,
                        ),
                      )
                    : const Text(
                        'Reset Password',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
