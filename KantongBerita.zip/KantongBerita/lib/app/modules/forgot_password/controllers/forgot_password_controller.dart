import 'dart:async';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:kantongberita/app/utils/app_colors.dart';
import '../../../data/providers/auth_provider.dart';
import '../../../data/models/user_model.dart';
import '../../../routes/app_routes.dart';

enum ForgotPasswordStep { email, otp, newPassword }

class ForgotPasswordController extends GetxController {
  final AuthProvider authProvider = Get.find<AuthProvider>();

  // ✅ Fix 1: Gunakan Timer yang bisa di-cancel
  Timer? _timer;

  // Step tracking
  final currentStep = ForgotPasswordStep.email.obs;

  // Form controllers
  final emailController = TextEditingController();
  final newPasswordController = TextEditingController();
  final confirmPasswordController = TextEditingController();

  // Observables
  final isLoading = false.obs;
  final maskedEmail = ''.obs;
  final resetToken = ''.obs;
  final isPasswordVisible = false.obs;
  final isConfirmVisible = false.obs;
  final otpValue = ''.obs; // ✅ Untuk pinput

  // OTP countdown
  final countdown = 0.obs;
  final canResend = false.obs;

  @override
  void onClose() {
    // ✅ Fix 1: Cancel timer saat halaman ditutup
    _timer?.cancel();
    emailController.dispose();
    newPasswordController.dispose();
    confirmPasswordController.dispose();
    super.onClose();
  }

  // ==================== STEP 1: SEND OTP ====================

  Future<void> sendOtp() async {
    final email = emailController.text.trim();

    if (email.isEmpty) {
      _showError('Email harus diisi');
      return;
    }

    if (!GetUtils.isEmail(email)) {
      _showError('Format email tidak valid');
      return;
    }

    try {
      isLoading.value = true;

      final response = await authProvider.sendOtp(email: email);

      if (response.statusCode == 200 && response.body['success'] == true) {
        maskedEmail.value = response.body['email'] ?? email;

        currentStep.value = ForgotPasswordStep.otp;
        otpValue.value = '';

        // ✅ Fix 1: Start timer yang proper
        _startCountdown();

        _showSuccess('Kode OTP dikirim ke ${maskedEmail.value}');
      } else {
        _showError(response.body['message'] ?? 'Gagal mengirim OTP');
      }
    } catch (e) {
      _showError('Terjadi kesalahan: $e');
    } finally {
      isLoading.value = false;
    }
  }

  // ==================== STEP 2: VERIFY OTP ====================

  Future<void> verifyOtp() async {
    final otp = otpValue.value.trim();

    if (otp.isEmpty || otp.length < 6) {
      _showError('Masukkan 6 digit kode OTP');
      return;
    }

    try {
      isLoading.value = true;

      final response = await authProvider.verifyOtp(
        email: emailController.text.trim(),
        otp: otp,
      );

      if (response.statusCode == 200 && response.body['success'] == true) {
        resetToken.value = response.body['reset_token'];
        currentStep.value = ForgotPasswordStep.newPassword;
        otpValue.value = '';

        // Stop timer saat OTP berhasil
        _timer?.cancel();
      } else {
        _showError(response.body['message'] ?? 'OTP tidak valid');
        // Reset pinput
        otpValue.value = '';
      }
    } catch (e) {
      _showError('Terjadi kesalahan: $e');
    } finally {
      isLoading.value = false;
    }
  }

  // ==================== STEP 3: RESET PASSWORD ====================

  Future<void> resetPassword() async {
    final newPassword = newPasswordController.text;
    final confirmPassword = confirmPasswordController.text;

    if (newPassword.isEmpty) {
      _showError('Password baru harus diisi');
      return;
    }

    if (newPassword.length < 6) {
      _showError('Password minimal 6 karakter');
      return;
    }

    if (newPassword != confirmPassword) {
      _showError('Konfirmasi password tidak cocok');
      return;
    }

    try {
      isLoading.value = true;

      final response = await authProvider.resetPassword(
        email: emailController.text.trim(),
        resetToken: resetToken.value,
        newPassword: newPassword,
        confirmPassword: confirmPassword,
      );

      if (response.statusCode == 200 && response.body['success'] == true) {
        // Auto login
        authProvider.saveToken(response.body['token']);
        final user = UserModel.fromJson(response.body['user']);
        authProvider.saveUser(user);

        isLoading.value = false;

        // ✅ Fix 3: Tampilkan dialog sukses sebelum pindah
        _showSuccessDialog();
      } else {
        _showError(response.body['message'] ?? 'Gagal reset password');
        isLoading.value = false;
      }
    } catch (e) {
      _showError('Terjadi kesalahan: $e');
      isLoading.value = false;
    }
  }

  // ==================== RESEND OTP ====================

  Future<void> resendOtp() async {
    try {
      isLoading.value = true;

      final response = await authProvider.sendOtp(
        email: emailController.text.trim(),
      );

      if (response.statusCode == 200 && response.body['success'] == true) {
        otpValue.value = '';
        _startCountdown();

        _showSuccess('Kode OTP baru telah dikirim');
      }
    } finally {
      isLoading.value = false;
    }
  }

  // ==================== COUNTDOWN ====================

  // ✅ Fix 1: Timer yang benar
  void _startCountdown() {
    _timer?.cancel(); // Cancel timer lama jika ada
    countdown.value = 60;
    canResend.value = false;

    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (countdown.value > 0) {
        countdown.value--;
      } else {
        canResend.value = true;
        timer.cancel();
      }
    });
  }

  // ==================== SUCCESS DIALOG ====================

  // ✅ Fix 3: Dialog sukses sebelum navigate
  void _showSuccessDialog() {
    Get.dialog(
      PopScope(
        canPop: false,
        child: Dialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
          child: Padding(
            padding: const EdgeInsets.all(28),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Checkmark Animation
                TweenAnimationBuilder<double>(
                  tween: Tween(begin: 0.0, end: 1.0),
                  duration: const Duration(milliseconds: 600),
                  curve: Curves.elasticOut,
                  builder: (context, value, child) {
                    return Transform.scale(scale: value, child: child);
                  },
                  child: Container(
                    width: 80,
                    height: 80,
                    decoration: const BoxDecoration(
                      color: Colors.green,
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(
                      Icons.check_rounded,
                      color: Colors.white,
                      size: 48,
                    ),
                  ),
                ),

                const SizedBox(height: 20),

                Text(
                  'Password Berhasil Direset!',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: AppColors.getTextPrimaryColor(Get.context!),
                  ),
                ),

                const SizedBox(height: 8),

                Text(
                  'Password Anda telah berhasil diperbarui. Tekan tombol di bawah untuk masuk ke aplikasi.',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 14,
                    color: AppColors.getTextSecondaryColor(Get.context!),
                    height: 1.5,
                  ),
                ),

                const SizedBox(height: 24),

                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () {
                      Get.back(); // tutup dialog
                      Get.offAllNamed(AppRoutes.main);
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFD32F2F),
                      foregroundColor: Colors.white,
                      elevation: 0,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    child: const Text(
                      'Masuk Sekarang',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
      barrierDismissible: false,
    );
  }

  // ==================== NAVIGATION ====================

  void goBack() {
    switch (currentStep.value) {
      case ForgotPasswordStep.email:
        Get.back();
        break;
      case ForgotPasswordStep.otp:
        _timer?.cancel();
        currentStep.value = ForgotPasswordStep.email;
        otpValue.value = '';
        break;
      case ForgotPasswordStep.newPassword:
        currentStep.value = ForgotPasswordStep.otp;
        newPasswordController.clear();
        confirmPasswordController.clear();
        break;
    }
  }

  // ==================== HELPERS ====================

  void togglePasswordVisibility() =>
      isPasswordVisible.value = !isPasswordVisible.value;

  void toggleConfirmVisibility() =>
      isConfirmVisible.value = !isConfirmVisible.value;

  void _showSuccess(String message) {
    Get.snackbar(
      'Berhasil',
      message,
      snackPosition: SnackPosition.TOP,
      backgroundColor: Colors.green,
      colorText: Colors.white,
      duration: const Duration(seconds: 3),
    );
  }

  void _showError(String message) {
    Get.snackbar(
      'Error',
      message,
      snackPosition: SnackPosition.TOP,
      backgroundColor: Colors.red,
      colorText: Colors.white,
      duration: const Duration(seconds: 3),
    );
  }
}
