import 'package:get/get.dart';
import 'package:kantongberita/app/modules/bookmark/controllers/bookmark_controller.dart';
import '../../category/controllers/category_controller.dart';
import '../../notifications/controllers/notifications_controller.dart';
import '../controllers/main_controller.dart';
import '../../home/controllers/home_controller.dart';
import '../../profile/controllers/profile_controller.dart';
import '../../../data/providers/api_provider.dart';
import '../../../data/providers/auth_provider.dart';

class MainBinding extends Bindings {
  @override
  void dependencies() {
    // Providers
    Get.lazyPut<ApiProvider>(() => ApiProvider(), fenix: true);
    Get.lazyPut<AuthProvider>(() => AuthProvider(), fenix: true);

    // Controllers
    Get.lazyPut<MainController>(() => MainController(), fenix: true);
    Get.lazyPut<HomeController>(() => HomeController(), fenix: true);
    Get.lazyPut<ProfileController>(() => ProfileController(), fenix: true);
    Get.lazyPut<BookmarkController>(() => BookmarkController(), fenix: true);
    Get.lazyPut<CategoryController>(() => CategoryController(), fenix: true);

    Get.lazyPut<NotificationsController>(
      () => NotificationsController(),
      fenix: true,
    );
  }
}
