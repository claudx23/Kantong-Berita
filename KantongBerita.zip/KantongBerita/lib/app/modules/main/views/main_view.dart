import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:kantongberita/app/widgets/offline_banner.dart';
import '../controllers/main_controller.dart';
import '../../home/views/home_view.dart';
import '../../bookmark/views/bookmark_view.dart';
import '../../category/views/category_view.dart';
import '../../profile/views/profile_view.dart';

class MainView extends GetView<MainController> {
  const MainView({super.key});

  @override
  Widget build(BuildContext context) {
    return OfflineBanner(
      child: Scaffold(
        body: Obx(
          () => IndexedStack(
            index: controller.currentIndex.value,
            children: const [
              HomeView(),
              BookmarkView(),
              CategoryView(),
              ProfileView(),
            ],
          ),
        ),

        bottomNavigationBar: Obx(
          () => Container(
            decoration: BoxDecoration(
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.1),
                  blurRadius: 10,
                  offset: const Offset(0, -5),
                ),
              ],
            ),
            child: BottomNavigationBar(
              currentIndex: controller.currentIndex.value,
              onTap: controller.changePage,
              type: BottomNavigationBarType.fixed,
              selectedItemColor: const Color(0xFFD32F2F),
              unselectedItemColor:
                  Theme.of(context).brightness == Brightness.dark
                  ? Colors.grey[600]
                  : Colors.grey,
              backgroundColor: Theme.of(context).appBarTheme.backgroundColor,
              showSelectedLabels: false,
              showUnselectedLabels: false,
              items: const [
                BottomNavigationBarItem(
                  icon: Icon(Icons.home_outlined),
                  activeIcon: Icon(Icons.home),
                  label: 'Home',
                ),
                BottomNavigationBarItem(
                  icon: Icon(Icons.bookmark_outline),
                  activeIcon: Icon(Icons.bookmark),
                  label: 'Bookmark',
                ),
                BottomNavigationBarItem(
                  icon: Icon(Icons.menu),
                  label: 'Kategori',
                ),
                BottomNavigationBarItem(
                  icon: Icon(Icons.account_circle_outlined),
                  activeIcon: Icon(Icons.account_circle),
                  label: 'Profile',
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
