import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../../utils/app_colors.dart';

class DisclaimerView extends StatelessWidget {
  const DisclaimerView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.getBackgroundColor(context),
      appBar: AppBar(
        backgroundColor: AppColors.getBackgroundColor(context),
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Get.back(),
        ),
        title: const Text('Disclaimer'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildSection(
                context,
                'Ketepatan Informasi: Kami berusaha sebaik mungkin untuk menyajikan informasi yang akurat dan terkini. Namun, kami tidak memberikan jaminan atas keakuratan, kelengkapan, atau keandalan informasi yang disajikan di Kantongberita.com. Pembaca harus menggunakan informasi tersebut dengan pertimbangan sendiri dan bertanggung jawab atas keputusan yang diambil berdasarkan informasi tersebut',
              ),
              const SizedBox(height: 20),
              _buildSection(
                context,
                'Tanggung Jawab Pembaca: Penggunaan dan interpretasi informasi yang disajikan di Kantongberita.com sepenuhnya menjadi tanggung jawab pembaca. Kami tidak bertanggung jawab atas segala kerugian atau kerusakan yang timbul akibat penggunaan informasi dari situs ini.',
              ),
              const SizedBox(height: 20),
              _buildSection(
                context,
                'Ketersediaan dan Kekontinuitasan: Kami berupaya untuk menjaga ketersediaan dan kekontinuitasan situs Kantongberita.com, namun tidak dapat menjamin bahwa situs ini akan bebas dari gangguan, kesalahan, atau kehilangan data. Kami tidak bertanggung jawab atas gangguan layanan yang diakibatkan oleh keadaan di luar kendali kami.',
              ),
              const SizedBox(height: 20),
              _buildSection(
                context,
                'Tautan Eksternal: Kantongberita.com mungkin menyertakan tautan ke situs web eksternal yang dimiliki dan dioperasikan oleh pihak ketiga. Kami tidak memiliki kontrol atas isi atau kebijakan privasi situs-situs tersebut, dan tidak bertanggung jawab atas konten atau praktik privasi dari situs-situs tersebut.',
              ),
              const SizedBox(height: 20),
              _buildSection(
                context,
                'Perubahan dan Pembaharuan: Kami berhak untuk mengubah atau memperbarui disclaimer ini kapan pun tanpa pemberitahuan sebelumnya. Penggunaan terus-menerus dari Kantongberita.com setelah perubahan tersebut dianggap sebagai penerimaan terhadap perubahan tersebut.',
              ),
              const SizedBox(height: 20),
              _buildSection(
                context,
                'Dengan mengakses dan menggunakan situs Kantongberita.com, Anda secara otomatis setuju untuk mematuhi disclaimer ini. Jika Anda tidak setuju dengan salah satu ketentuan dalam disclaimer ini, Anda disarankan untuk tidak menggunakan situs ini.',
              ),
              const SizedBox(height: 32),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSection(BuildContext context, String content) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          content,
          style: TextStyle(
            fontSize: 14,
            height: 1.6,
            color: AppColors.getTextPrimaryColor(context),
          ),
          textAlign: TextAlign.justify,
        ),
      ],
    );
  }
}
