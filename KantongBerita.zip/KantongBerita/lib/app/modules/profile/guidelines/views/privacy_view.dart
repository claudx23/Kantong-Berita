import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../../utils/app_colors.dart';

class PrivacyPolicyView extends StatelessWidget {
  const PrivacyPolicyView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.getBackgroundColor(context),
      appBar: AppBar(
        backgroundColor: AppColors.getBackgroundColor(context),
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Get.back(),
        ),
        title: const Text('Kebijakan Privasi'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Kebijakan privasi ini menjelaskan bagaimana Kantongberita.com mengumpulkan, menggunakan, dan melindungi informasi pribadi Anda saat Anda mengunjungi atau menggunakan situs web kami.',
              style: TextStyle(
                fontSize: 14,
                height: 1.6,
                color: AppColors.getTextPrimaryColor(context),
              ),
              textAlign: TextAlign.justify,
            ),

            const SizedBox(height: 24),

            _buildSection(
              context,
              'Informasi yang Kami Kumpulkan',
              'Ketika Anda mengunjungi Kantongberita.com, kami mungkin mengumpulkan informasi non-pribadi yang dikirimkan secara otomatis oleh browser Anda, seperti jenis browser, bahasa preferensi, dan alamat IP. Kami juga dapat menggunakan teknologi seperti cookies untuk mengumpulkan informasi tentang interaksi Anda dengan situs kami.\n\n'
                  'Kami juga dapat mengumpulkan informasi pribadi yang Anda berikan secara sukarela, misalnya saat Anda mengisi formulir kontak atau berlangganan newsletter kami. Informasi pribadi yang mungkin kami kumpulkan termasuk nama, alamat email, nomor telepon, dan informasi kontak lainnya.',
            ),

            _buildSection(
              context,
              'Bagaimana Kami Menggunakan Informasi Anda',
              'Kami menggunakan informasi yang kami kumpulkan untuk berbagai tujuan, termasuk:\n\n'
                  '• Menyediakan konten dan layanan yang Anda minta.\n'
                  '• Mengelola dan mengoperasikan situs web kami.\n'
                  '• Berkomunikasi dengan Anda, termasuk mengirimkan newsletter dan pemberitahuan terkait layanan.\n'
                  '• Menganalisis penggunaan situs web dan meningkatkan pengalaman pengguna.',
            ),

            _buildSection(
              context,
              'Bagaimana Kami Melindungi Informasi Anda',
              'Kami mengambil langkah-langkah keamanan yang sesuai untuk melindungi informasi pribadi Anda dari akses, penggunaan, atau pengungkapan yang tidak sah. Ini termasuk penggunaan enkripsi data dan kontrol akses yang tepat.\n\n'
                  'Kami tidak akan menjual, menyewakan, atau membagikan informasi pribadi Anda kepada pihak ketiga tanpa izin Anda, kecuali jika diwajibkan oleh hukum atau dalam situasi tertentu seperti akuisisi atau penggabungan perusahaan.',
            ),

            _buildSection(
              context,
              'Kebijakan Cookie',
              'Kantongberita.com dapat menggunakan cookies dan teknologi pelacakan serupa untuk mengumpulkan informasi tentang penggunaan situs web kami. Anda dapat mengatur browser Anda untuk menolak semua cookies atau untuk memberi tahu Anda ketika cookie dikirim. Namun, jika Anda menonaktifkan cookies, beberapa bagian dari situs web kami mungkin tidak berfungsi dengan baik.',
            ),

            _buildSection(
              context,
              'Perubahan pada Kebijakan Privasi',
              'Kami dapat memperbarui Kebijakan Privasi ini dari waktu ke waktu dengan memposting versi terbaru di situs web kami. Kami mendorong Anda untuk memeriksa halaman Kebijakan Privasi secara berkala untuk melihat pembaruan atau perubahan apa pun.',
            ),

            _buildSection(
              context,
              'Hubungi Kami',
              'Jika Anda memiliki pertanyaan tentang Kebijakan Privasi kami, silakan hubungi kami melalui email di:\n\n'
                  'kantongberitaku@gmail.com',
            ),

            const SizedBox(height: 20),

            Text(
              'Terima kasih atas kunjungan Anda ke Kantongberita.com. Dengan menggunakan situs web kami, Anda menyetujui pengumpulan dan penggunaan informasi Anda sesuai dengan Kebijakan Privasi ini.',
              style: TextStyle(
                fontSize: 14,
                height: 1.6,
                color: AppColors.getTextPrimaryColor(context),
              ),
              textAlign: TextAlign.justify,
            ),

            const SizedBox(height: 32),
          ],
        ),
      ),
    );
  }

  Widget _buildSection(
    BuildContext context,
    String title,
    String content,
  ) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: TextStyle(
              fontSize: 17,
              fontWeight: FontWeight.bold,
              color: AppColors.getTextPrimaryColor(context),
            ),
          ),
          const SizedBox(height: 8),
          Text(
            content,
            style: TextStyle(
              fontSize: 14,
              height: 1.6,
              color: AppColors.getTextPrimaryColor(context),
            ),
            textAlign: TextAlign.justify,
          ),
        ],
      ),
    );
  }
}