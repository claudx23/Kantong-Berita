import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../../utils/app_colors.dart';

class KontakKamiView extends StatelessWidget {
  const KontakKamiView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.getBackgroundColor(context),
      appBar: AppBar(
        backgroundColor: AppColors.getBackgroundColor(context),
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Get.back(),
        ),
        title: const Text('Tentang Kami'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildSection(context, 'Kantongberita.com dapat dihubungi di:'),
              const SizedBox(height: 20),
              _buildSection(
                context,
                'Alamat: Lorong Gereja Lingkungan 12 Kedai Bambu Kuning Bagan Deli, Belawan, Medan, Sumatera Utara.',
              ),
              const SizedBox(height: 20),
              _buildSection(context, 'Email: kantongberitaku@gmail.com'),
              const SizedBox(height: 20),
              _buildSection(context, 'Contact Person: 08116262551'),
              const SizedBox(height: 32),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSection(BuildContext context, String content) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          content,
          style: TextStyle(
            fontSize: 14,
            height: 1.6,
            color: AppColors.getTextPrimaryColor(context),
          ),
          textAlign: TextAlign.justify,
        ),
      ],
    );
  }
}
