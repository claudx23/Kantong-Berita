import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../../utils/app_colors.dart';

class KodeEtikView extends StatelessWidget {
  const KodeEtikView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.getBackgroundColor(context),
      appBar: AppBar(
        backgroundColor: AppColors.getBackgroundColor(context),
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Get.back(),
        ),
        title: const Text('Kode Etik'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildSection(
                context,
                'Kewajiban Integritas:',
                'Kami berkomitmen untuk menyajikan berita dan informasi yang akurat, jujur, dan tidak memihak.\nKami akan menjaga integritas dalam semua aspek pekerjaan jurnalistik kami, tanpa mempengaruhi atau terpengaruh oleh tekanan eksternal.',
              ),
              const SizedBox(height: 20),
              _buildSection(
                context,
                'Objektivitas:',
                'Kami akan menyajikan berita dan informasi tanpa bias atau tendensi politik, ideologis, agama, atau kepentingan pribadi. Kami akan mengutamakan kebenaran dan fakta dalam setiap liputan kami, serta memberikan sudut pandang yang seimbang dan obyektif.',
              ),
              const SizedBox(height: 20),
              _buildSection(
                context,
                'Menghormati Privasi dan Kebenaran:',
                'Kami akan menghormati privasi individu dan organisasi dalam setiap liputan kami, serta memastikan kebenaran informasi sebelum disiarkan.\nKami tidak akan menyebarkan informasi palsu atau tidak terverifikasi, dan akan melakukan verifikasi yang cermat sebelum mempublikasikan berita.',
              ),
              const SizedBox(height: 20),
              _buildSection(
                context,
                'Menghormati Kebenaran dan Keadilan:',
                'Kami akan menghindari penyalahgunaan kekuatan media untuk menyebarkan propaganda, fitnah, atau informasi yang dapat merugikan individu atau kelompok.\nKami akan memberikan kesempatan yang adil bagi semua pihak yang terlibat dalam sebuah berita untuk memberikan tanggapan atau klarifikasi.',
              ),
              const SizedBox(height: 20),
              _buildSection(
                context,
                'Transparansi:',
                'Kami akan menjaga transparansi dalam setiap proses pembuatan berita, termasuk sumber informasi, metode pengumpulan data, dan kepentingan yang terlibat.\nKami akan memberikan penjelasan yang jelas dan akurat mengenai kepemilikan, afiliasi, atau konflik kepentingan yang mungkin mempengaruhi liputan kami.',
              ),
              const SizedBox(height: 20),
              _buildSection(
                context,
                'Pertanggungjawaban:',
                'Kami akan bertanggung jawab atas setiap informasi atau berita yang kami publikasikan, serta siap menerima koreksi atau klarifikasi jika terjadi kesalahan.\nKami akan menanggapi setiap keluhan atau masukan dari pembaca dengan cepat dan profesional.',
              ),
              const SizedBox(height: 20),
              _buildSection(
                context,
                'Menghormati Hukum dan Etika Jurnalistik:',
                'Kami akan mengikuti semua hukum dan regulasi yang berlaku dalam praktik jurnalistik, serta mematuhi standar etika yang ditetapkan oleh organisasi jurnalistik yang relevan.\nKami akan menghindari konflik kepentingan dan mematuhi kode etik jurnalistik dalam setiap langkah pembuatan berita.',
              ),
              const SizedBox(height: 20),
              Text(
                'Kami di Kantongberita.com berkomitmen untuk menjalankan praktik jurnalistik yang etis, profesional, dan bertanggung jawab demi memberikan layanan informasi yang berkualitas kepada pembaca kami.',
                style: TextStyle(
                  fontSize: 14,
                  height: 1.6,
                  color: AppColors.getTextPrimaryColor(context),
                ),
                textAlign: TextAlign.justify,
              ),
              const SizedBox(height: 32),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSection(BuildContext context, String title, String content) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
            color: AppColors.getTextPrimaryColor(context),
          ),
        ),
        const SizedBox(height: 4),
        Text(
          content,
          style: TextStyle(
            fontSize: 14,
            height: 1.6,
            color: AppColors.getTextPrimaryColor(context),
          ),
          textAlign: TextAlign.justify,
        ),
      ],
    );
  }
}
