import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../../utils/app_colors.dart';

class PedomanMediaView extends StatelessWidget {
  const PedomanMediaView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.getBackgroundColor(context),
      appBar: AppBar(
        backgroundColor: AppColors.getBackgroundColor(context),
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Get.back(),
        ),
        title: const Text('Pedoman Media Siber'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildSection(
                context,
                '1. Tujuan dan Nilai-Nilai',
                'Kantongberita.com bertujuan untuk menyediakan informasi berkualitas kepada pembaca dengan mengutamakan kebenaran, keadilan, dan keterbukaan. Kami berkomitmen untuk mematuhi standar jurnalisme yang tinggi dan menjunjung tinggi etika dalam setiap konten yang kami publikasikan.',
              ),
              const SizedBox(height: 20),
              _buildSection(
                context,
                '2. Ketepatan dan Kecermatan',
                'Kami berusaha untuk menyajikan informasi yang akurat dan terpercaya. Sebelum mempublikasikan berita, kami melakukan verifikasi fakta secara menyeluruh dan memeriksa keabsahan sumber informasi. Kami menghindari menyebarkan informasi yang tidak terverifikasi atau bersifat spekulatif.',
              ),
              const SizedBox(height: 20),
              _buildSection(
                context,
                '3. Kebenaran dan Integritas',
                'Kantongberita.com menempatkan kebenaran sebagai prioritas utama dalam setiap pemberitaan. Kami menghargai integritas informasi dan menghindari penyebaran berita palsu atau tendensius. Jika kesalahan terjadi, kami akan segera melakukan koreksi dan klarifikasi.',
              ),
              const SizedBox(height: 20),
              _buildSection(
                context,
                '4. Kemandirian dan Kemerdekaan',
                'Kami berkomitmen untuk menjaga kemandirian redaksi dan tidak terpengaruh oleh kepentingan politik, ekonomi, atau pihak lainnya. Kami menjunjung tinggi kebebasan berekspresi dan berpendapat dalam kerangka hukum yang berlaku.',
              ),
              const SizedBox(height: 20),
              _buildSection(
                context,
                '5. Keterbukaan dan Akuntabilitas',
                'Kantongberita.com bersedia menerima kritik dan masukan dari pembaca serta masyarakat secara umum. Kami membuka diri untuk berdialog dan memberikan penjelasan terkait konten yang dipublikasikan. Kami juga siap bertanggung jawab atas setiap kesalahan atau kelalaian yang terjadi.',
              ),
              const SizedBox(height: 20),
              _buildSection(
                context,
                '6. Perlindungan Privasi dan Kebijakan Data',
                'Kami menghargai privasi pengguna dan berkomitmen untuk melindungi informasi pribadi mereka. Data pengguna akan diolah sesuai dengan kebijakan privasi yang berlaku dan tidak akan disalahgunakan untuk kepentingan pihak ketiga tanpa izin.',
              ),
              const SizedBox(height: 20),
              _buildSection(
                context,
                '7. Kesopanan dan Etika',
                'Kami menjaga kesopanan dalam setiap konten yang kami publikasikan dan menghindari konten yang bersifat pelecehan, diskriminatif, atau merugikan pihak lain. Kami juga menghormati hak cipta dan memberikan penghargaan kepada sumber informasi yang sah.',
              ),
              const SizedBox(height: 20),
              _buildSection(
                context,
                '8. Transparansi',
                'Kami berkomitmen untuk menjaga transparansi dalam setiap aspek operasional kami, termasuk sumber pendanaan, kepemilikan, dan hubungan dengan pihak lain. Kami akan menyediakan informasi yang jelas dan terbuka kepada pembaca mengenai proses kerja dan kebijakan redaksi kami.',
              ),
              const SizedBox(height: 20),
              _buildSection(
                context,
                '9. Pendidikan dan Pemberdayaan Masyarakat',
                'Kantongberita.com memiliki peran dalam mendidik dan memberdayakan masyarakat melalui informasi yang disajikan. Kami berusaha untuk menyediakan konten yang relevan, informatif, dan bermanfaat bagi pembaca agar dapat membuat keputusan yang cerdas dan bertanggung jawab.',
              ),
              const SizedBox(height: 20),
              _buildSection(
                context,
                '10. Keberagaman dan Kesetaraan',
                'Kami menghargai keberagaman pendapat, suara, dan perspektif dalam pemberitaan kami. Kami berkomitmen untuk menghindari diskriminasi berdasarkan ras, agama, gender, orientasi seksual, atau faktor lainnya.',
              ),
              const SizedBox(height: 32),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSection(BuildContext context, String title, String content) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
            color: AppColors.getTextPrimaryColor(context),
          ),
        ),
        const SizedBox(height: 4),
        Text(
          content,
          style: TextStyle(
            fontSize: 14,
            height: 1.6,
            color: AppColors.getTextPrimaryColor(context),
          ),
          textAlign: TextAlign.justify,
        ),
      ],
    );
  }
}
