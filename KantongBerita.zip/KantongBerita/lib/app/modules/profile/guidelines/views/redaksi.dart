import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../../utils/app_colors.dart';

class RedaksiView extends StatelessWidget {
  const RedaksiView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.getBackgroundColor(context),
      appBar: AppBar(
        backgroundColor: AppColors.getBackgroundColor(context),
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Get.back(),
        ),
        title: const Text('Redaksi'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildSection(context, 'PEMIMPIN REDAKSI', 'Toga Sianturi'),
              const SizedBox(height: 20),
              _buildSection(
                context,
                'WAKIL PEMIMPIN REDAKSI',
                'Juliater Simbolon',
              ),
              const SizedBox(height: 20),
              _buildSection(context, 'REDAKTUR', 'Dean S'),
              const SizedBox(height: 20),
              _buildSection(context, 'DIVISI IKLAN', 'Asdiani'),
              const SizedBox(height: 20),
              _buildSection(context, 'DIVISI KEUANGAN', 'Asdiani'),
              const SizedBox(height: 20),
              _buildSection(context, 'DIVISI TEKNOLOGI ', 'Samuel Sitorus'),
              const SizedBox(height: 20),
              Text(
                'WARTAWAN',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: AppColors.getTextPrimaryColor(context),
                ),
              ),
              const SizedBox(height: 10),
              Text(
                'Medan:',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: AppColors.getTextPrimaryColor(context),
                ),
              ),
              const SizedBox(height: 10),
              Text(
                '– Anton Sardion Pasaribu',
                style: TextStyle(
                  fontSize: 14,
                  color: AppColors.getTextPrimaryColor(context),
                ),
              ),
              const SizedBox(height: 10),
              Text(
                '– Juliater Simbolon',
                style: TextStyle(
                  fontSize: 14,
                  color: AppColors.getTextPrimaryColor(context),
                ),
              ),
              const SizedBox(height: 20),
              Text(
                'Sibolga-Tapteng:',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: AppColors.getTextPrimaryColor(context),
                ),
              ),
              const SizedBox(height: 10),
              Text(
                '– Arif Fauzi Pardede',
                style: TextStyle(
                  fontSize: 14,
                  color: AppColors.getTextPrimaryColor(context),
                ),
              ),
              const SizedBox(height: 10),
              Text(
                '– Dzulfadli Tambunan',
                style: TextStyle(
                  fontSize: 14,
                  color: AppColors.getTextPrimaryColor(context),
                ),
              ),
              const SizedBox(height: 10),
              Text(
                '– Samuel Sitorus',
                style: TextStyle(
                  fontSize: 14,
                  color: AppColors.getTextPrimaryColor(context),
                ),
              ),
              const SizedBox(height: 10),
              Text(
                '– Martin Delahoya Marbun',
                style: TextStyle(
                  fontSize: 14,
                  color: AppColors.getTextPrimaryColor(context),
                ),
              ),
              const SizedBox(height: 32),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSection(BuildContext context, String title, String content) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
            color: AppColors.getTextPrimaryColor(context),
          ),
        ),
        const SizedBox(height: 4),
        Text(
          content,
          style: TextStyle(
            fontSize: 14,
            height: 1.6,
            color: AppColors.getTextPrimaryColor(context),
          ),
          textAlign: TextAlign.justify,
        ),
      ],
    );
  }
}
