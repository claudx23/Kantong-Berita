import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../../utils/app_colors.dart';

class TentangKamiView extends StatelessWidget {
  const TentangKamiView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.getBackgroundColor(context),
      appBar: AppBar(
        backgroundColor: AppColors.getBackgroundColor(context),
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Get.back(),
        ),
        title: const Text('Tentang Kami'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text.rich(
                TextSpan(
                  style: TextStyle(
                    fontSize: 14,
                    height: 1.6,
                    color: AppColors.getTextPrimaryColor(context),
                  ),
                  children: const [
                    TextSpan(
                      text: 'Kantongberita.com',
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                    TextSpan(
                      text:
                          ' adalah portal berita daring yang menyajikan informasi dan artikel terkini dari kawasan Tapanuli, Sumatera Utara. Kami adalah salah satu situs berita terkemuka di Tapanuli yang mengutamakan kecepatan dan keakuratan dalam menyajikan informasi.',
                    ),
                  ],
                ),
                textAlign: TextAlign.justify,
              ),
              const SizedBox(height: 20),
              _buildSection(
                context,
                'Didirikan pada tahun 2020, Kantongberita.com berbasis di Kota Medan, Provinsi Sumatera Utara, dan kreatif menggabungkan teks, foto, video, dan suara dalam setiap berita dan informasi yang disajikan. Kami berkomitmen untuk menjalankan standar jurnalisme berkualitas dalam meliput peristiwa-peristiwa daerah dan nasional.',
              ),
              const SizedBox(height: 20),
              _buildSection(
                context,
                'Selain dapat diakses melalui komputer, platform kami juga tersedia melalui perangkat seluler, memungkinkan akses yang lebih mudah dan cepat untuk pembaca kami. Kantongberita.com bertujuan untuk menjadi bagian dari upaya meningkatkan literasi masyarakat melalui jurnalisme yang cerdas, tajam, berimbang, dan menghibur.',
              ),
              const SizedBox(height: 20),
              _buildSection(
                context,
                'Untuk menjaga operasional kami, Kantongberita.com mengandalkan pendapatan dari iklan. Kami mengundang partisipasi aktif dari pembaca kami dalam memberikan masukan, saran, dan kritik yang membangun, sehingga kami dapat terus berkembang dan menyajikan berita yang lebih baik di masa mendatang.',
              ),
              const SizedBox(height: 32),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSection(BuildContext context, String content) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          content,
          style: TextStyle(
            fontSize: 14,
            height: 1.6,
            color: AppColors.getTextPrimaryColor(context),
          ),
          textAlign: TextAlign.justify,
        ),
      ],
    );
  }
}
