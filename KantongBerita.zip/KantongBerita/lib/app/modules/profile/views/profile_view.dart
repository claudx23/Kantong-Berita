import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:kantongberita/app/modules/profile/controllers/notification_controller.dart';
import 'package:kantongberita/app/routes/app_routes.dart';
import '../controllers/profile_controller.dart';
import '../../../widgets/kb_appbar.dart';
import '../../../widgets/avatar_initial.dart';
import '../../../utils/app_colors.dart';

class ProfileView extends GetView<ProfileController> {
  const ProfileView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.getBackgroundColor(context),
      appBar: const KbAppBar(),
      body: SingleChildScrollView(
        child: Column(
          children: [
            const SizedBox(height: 24),

            // Title
            Text(
              'Profil',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: AppColors.getTextPrimaryColor(context),
              ),
            ),

            const SizedBox(height: 20),

            // Avatar
            _buildAvatar(),

            const SizedBox(height: 16),

            // Auth Section
            _buildAuthSection(),

            const SizedBox(height: 24),

            // Settings Section
            _buildSettingsSection(),

            const SizedBox(height: 16),

            // Info Section
            _buildInfoSection(),

            // Logout Button (jika sudah login)
            Obx(() {
              if (controller.currentUser.value != null) {
                return Padding(
                  padding: const EdgeInsets.all(16),
                  child: SizedBox(
                    width: double.infinity,
                    child: OutlinedButton(
                      onPressed: controller.logout,
                      style: OutlinedButton.styleFrom(
                        foregroundColor: const Color(0xFFD32F2F),
                        side: const BorderSide(color: Color(0xFFD32F2F)),
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                      ),
                      child: const Text(
                        'Keluar',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ),
                );
              }
              return const SizedBox.shrink();
            }),

            const SizedBox(height: 32),
          ],
        ),
      ),
    );
  }

  // ==================== AVATAR ====================

  Widget _buildAvatar() {
    return Obx(() {
      if (controller.currentUser.value != null) {
        final user = controller.currentUser.value!;

        return Column(
          children: [
            AvatarInitial(
              name: user.name.isNotEmpty ? user.name : user.username,
              radius: 50,
              fontSize: 28,
            ),

            const SizedBox(height: 12),

            // Nama
            Text(
              user.name,
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: AppColors.getTextPrimaryColor(Get.context!),
              ),
            ),

            const SizedBox(height: 4),

            // Email
            Text(
              user.email,
              style: TextStyle(fontSize: 14, color: Colors.grey[600]),
            ),
          ],
        );
      }

      // Guest - avatar abu-abu dengan icon
      return CircleAvatar(
        radius: 50,
        backgroundColor: Colors.grey[200],
        child: Icon(Icons.person, size: 50, color: Colors.grey[400]),
      );
    });
  }

  // ==================== AUTH SECTION ====================

  Widget _buildAuthSection() {
    return Obx(() {
      // Jika sudah login, tidak tampilkan tombol masuk
      if (controller.currentUser.value != null) return const SizedBox.shrink();

      return Column(
        children: [
          // Masuk Button
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 60),
            child: SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: controller.goToLogin,
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFD32F2F),
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
                child: const Text(
                  'Masuk',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                ),
              ),
            ),
          ),

          const SizedBox(height: 12),

          // Register Link
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                'Belum punya akun? ',
                style: TextStyle(fontSize: 13, color: Colors.grey[600]),
              ),
              GestureDetector(
                onTap: controller.goToRegister,
                child: const Text(
                  'Daftar',
                  style: TextStyle(
                    fontSize: 13,
                    color: Color(0xFFD32F2F),
                    decoration: TextDecoration.underline,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
        ],
      );
    });
  }

  // ==================== SETTINGS SECTION ====================
  Widget _buildSettingsSection() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      decoration: BoxDecoration(
        color: AppColors.getCardColor(Get.context!),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
            child: Text(
              'Pengaturan',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: AppColors.getTextPrimaryColor(Get.context!),
              ),
            ),
          ),

          // Informasi Personal
          ListTile(
            title: Text(
              'Informasi Personal',
              style: TextStyle(
                fontSize: 14,
                color: AppColors.getTextPrimaryColor(Get.context!),
              ),
            ),
            trailing: Icon(
              Icons.chevron_right,
              color: AppColors.getTextSecondaryColor(Get.context!),
              size: 20,
            ),
            onTap: () {
              if (controller.isLoggedIn) {
                Get.toNamed(AppRoutes.personalInfo);
              } else {
                controller.goToLogin();
              }
            },
          ),

          const Divider(height: 1, indent: 16),

          // Preferensi Kategori
          ListTile(
            title: Text(
              'Preferensi Kategori',
              style: TextStyle(
                fontSize: 14,
                color: AppColors.getTextPrimaryColor(Get.context!),
              ),
            ),
            trailing: Icon(
              Icons.chevron_right,
              color: AppColors.getTextSecondaryColor(Get.context!),
              size: 20,
            ),
            onTap: () {
              if (controller.isLoggedIn) {
                Get.toNamed(
                  AppRoutes.preference,
                  arguments: {'isEditing': true},
                );
              } else {
                controller.goToLogin();
              }
            },
          ),

          // ✅ Push Notification - hanya tampil jika sudah login
          Obx(() {
            if (controller.currentUser.value == null) {
              return const SizedBox.shrink(); // ❌ Sembunyikan jika belum login
            }

            return Column(
              children: [
                const Divider(height: 1, indent: 16),

                GetBuilder<NotificationController>(
                  init: NotificationController(),
                  builder: (notifCtrl) => Column(
                    children: [
                      // Toggle utama Push Notification
                      Obx(
                        () => ListTile(
                          title: Text(
                            'Push Notification',
                            style: TextStyle(
                              fontSize: 14,
                              color: AppColors.getTextPrimaryColor(
                                Get.context!,
                              ),
                            ),
                          ),
                          trailing: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              if (notifCtrl.isSaving.value)
                                const SizedBox(
                                  width: 16,
                                  height: 16,
                                  child: CircularProgressIndicator(
                                    strokeWidth: 2,
                                    color: Color(0xFFD32F2F),
                                  ),
                                ),
                              const SizedBox(width: 8),
                              Switch(
                                value: notifCtrl.isEnabled.value,
                                onChanged: notifCtrl.toggleEnabled,
                                activeThumbColor: const Color(0xFFD32F2F),
                              ),
                            ],
                          ),
                        ),
                      ),

                      // ✅ Hanya Update Kategori - Breaking News dihapus
                      Obx(
                        () => notifCtrl.isEnabled.value
                            ? Column(
                                children: [
                                  const Divider(height: 1, indent: 32),
                                  _buildSubToggle(
                                    title: 'Update Kategori',
                                    subtitle: 'Berita dari kategori favorit',
                                    value: notifCtrl.isCategoryUpdates.value,
                                    onChanged: notifCtrl.toggleCategoryUpdates,
                                  ),
                                ],
                              )
                            : const SizedBox.shrink(),
                      ),
                    ],
                  ),
                ),
              ],
            );
          }),
        ],
      ),
    );
  }

  Widget _buildSubToggle({
    required String title,
    required String subtitle,
    required bool value,
    required Function(bool) onChanged,
  }) {
    return Padding(
      padding: const EdgeInsets.only(left: 16),
      child: ListTile(
        title: Text(
          title,
          style: TextStyle(
            fontSize: 13,
            color: AppColors.getTextPrimaryColor(Get.context!),
          ),
        ),
        subtitle: Text(
          subtitle,
          style: TextStyle(
            fontSize: 11,
            color: AppColors.getTextSecondaryColor(Get.context!),
          ),
        ),
        trailing: Switch(
          value: value,
          onChanged: onChanged,
          activeThumbColor: const Color(0xFFD32F2F),
        ),
      ),
    );
  }

  // ==================== INFO SECTION ====================

  Widget _buildInfoSection() {
    final menuItems = [
      'Tentang Kami',
      'Redaksi',
      'Disclaimer',
      'Privacy Policy',
      'Kode Etik',
      'Pedoman Media Siber',
      'Kontak',
    ];

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      decoration: BoxDecoration(
        color: AppColors.getCardColor(Get.context!),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        children: menuItems.map((item) {
          final isLast = item == menuItems.last;
          return Column(
            children: [
              ListTile(
                title: Text(
                  item,
                  style: TextStyle(
                    fontSize: 14,
                    color: AppColors.getTextPrimaryColor(Get.context!),
                  ),
                ),
                trailing: const Icon(
                  Icons.chevron_right,
                  color: Colors.grey,
                  size: 20,
                ),
                onTap: () => controller.openMenu(item),
              ),
              if (!isLast) const Divider(height: 1, indent: 16),
            ],
          );
        }).toList(),
      ),
    );
  }
}
