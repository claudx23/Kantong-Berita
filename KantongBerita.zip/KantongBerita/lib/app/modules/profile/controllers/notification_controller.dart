import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../data/providers/auth_provider.dart';
import '../../../services/notification_service.dart';

class NotificationController extends GetxController {
  final AuthProvider authProvider = Get.find<AuthProvider>();

  final isEnabled = false.obs;
  final isCategoryUpdates = false.obs; // ✅ Hanya ini yang tersisa
  final isLoading = false.obs;
  final isSaving = false.obs;

  @override
  void onInit() {
    super.onInit();
    loadSettings();
  }

  // ==================== LOAD ====================

  Future<void> loadSettings() async {
    if (!authProvider.isLoggedIn()) return;

    try {
      isLoading.value = true;

      final response = await authProvider.getNotificationSettings();

      if (response.statusCode == 200 && response.body['success'] == true) {
        final settings = response.body['settings'];
        isEnabled.value = settings['enabled'] ?? false;
        isCategoryUpdates.value = settings['category_updates'] ?? false;
      }

      isLoading.value = false;
    } catch (e) {
      isLoading.value = false;
      // print('❌ Error load notification settings: $e');
    }
  }

  // ==================== TOGGLE UTAMA ====================

  Future<void> toggleEnabled(bool value) async {
    isEnabled.value = value;

    if (!value) {
      // Nonaktifkan → reset category updates
      isCategoryUpdates.value = false;

      // Kembali ke guest subscription (hanya berita_utama & breaking_news)
      await NotificationService.clearSubscriptions();
    } else {
      // Aktifkan → kedua toggle aktif otomatis
      isCategoryUpdates.value = true;

      // Subscribe balik sesuai preferensi
      await _resubscribeByPreferences();
    }

    await _saveToServer();
  }

  // ==================== TOGGLE CATEGORY UPDATES ====================

  Future<void> toggleCategoryUpdates(bool value) async {
    if (!isEnabled.value) {
      Get.snackbar(
        'Info',
        'Aktifkan notifikasi terlebih dahulu',
        snackPosition: SnackPosition.TOP,
        backgroundColor: Colors.orange,
        colorText: Colors.white,
      );
      return;
    }

    isCategoryUpdates.value = value;

    if (value) {
      await _resubscribeByPreferences();
    } else {
      // Nonaktifkan kategori → hanya pertahankan berita_utama & breaking_news
      await NotificationService.updateSubscriptions([]);
    }

    await _saveToServer();
  }

  // ==================== RESUBSCRIBE ====================

  Future<void> _resubscribeByPreferences() async {
    try {
      final response = await authProvider.getPreferences();

      if (response.statusCode == 200 && response.body['success'] == true) {
        final prefs = response.body['preferences'];

        final List<int> categoryIds = [
          ...List<int>.from(prefs['preferred_categories'] ?? []),
          ...List<int>.from(prefs['preferred_locations'] ?? []),
        ];

        await NotificationService.updateSubscriptions(
          isCategoryUpdates.value ? categoryIds : [],
        );

        // print('✅ Resubscribed based on preferences: $categoryIds');
      }
    } catch (e) {
      // print('⚠️ Resubscribe failed: $e');
    }
  }

  // ==================== SAVE TO SERVER ====================

  Future<void> _saveToServer() async {
    try {
      isSaving.value = true;

      await authProvider.updateNotificationSettings(
        enabled: isEnabled.value,
        breakingNews: true, // ✅ Selalu true, tidak bisa diubah user
        categoryUpdates: isCategoryUpdates.value,
      );

      isSaving.value = false;
    } catch (e) {
      isSaving.value = false;
      // print('⚠️ Save notification settings failed: $e');
    }
  }
}
