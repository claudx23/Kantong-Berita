import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:kantongberita/app/services/notification_service.dart';
import '../../../data/models/user_model.dart';
import '../../../data/providers/auth_provider.dart';
import '../../../routes/app_routes.dart';
import '../../../services/cache_service.dart';
import '../../../services/reading_tracker_service.dart';
import '../../bookmark/controllers/bookmark_controller.dart';
import '../../home/controllers/home_controller.dart';

class ProfileController extends GetxController {
  final AuthProvider authProvider = Get.find<AuthProvider>();

  final Rx<UserModel?> currentUser = Rx<UserModel?>(null);
  final isNotificationEnabled = false.obs;
  final isLoggingOut = false.obs;

  @override
  void onInit() {
    super.onInit();
    loadUser();
  }

  void loadUser() {
    if (authProvider.isLoggedIn()) {
      currentUser.value = authProvider.getUser();
    }
  }

  bool get isLoggedIn => authProvider.isLoggedIn();

  void goToLogin() {
    Get.toNamed(AppRoutes.login);
  }

  void goToRegister() {
    Get.toNamed(AppRoutes.register);
  }

  void toggleNotification(bool value) {
    isNotificationEnabled.value = value;
  }

  Future<void> logout() async {
    Get.dialog(
      Dialog(
        backgroundColor: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Icon
              Container(
                width: 64,
                height: 64,
                decoration: BoxDecoration(
                  color: const Color(0xFFD32F2F).withValues(alpha: 0.1),
                  shape: BoxShape.circle,
                ),
                child: const Icon(
                  Icons.logout_rounded,
                  color: Color(0xFFD32F2F),
                  size: 30,
                ),
              ),

              const SizedBox(height: 16),

              // Title
              const Text(
                'Keluar Akun?',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Colors.black87,
                ),
              ),

              const SizedBox(height: 8),

              // Subtitle
              Text(
                'Anda akan keluar dari akun ini.',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 13,
                  color: Colors.grey[500],
                  height: 1.5,
                ),
              ),

              const SizedBox(height: 24),

              // Buttons
              Row(
                children: [
                  // Batal
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => Get.back(),
                      style: OutlinedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        side: BorderSide(color: Colors.grey[300]!),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child: Text(
                        'Batal',
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                          color: Colors.grey[600],
                        ),
                      ),
                    ),
                  ),

                  const SizedBox(width: 12),

                  // Keluar
                  Expanded(
                    child: Obx(
                      () => ElevatedButton(
                        onPressed: isLoggingOut.value
                            ? null
                            : () async {
                                await _performLogout();
                              },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFFD32F2F),
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(vertical: 12),
                          elevation: 0,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                        child: isLoggingOut.value
                            ? const SizedBox(
                                width: 18,
                                height: 18,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  color: Colors.white,
                                ),
                              )
                            : const Text(
                                'Keluar',
                                style: TextStyle(
                                  fontSize: 14,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
      barrierDismissible: false,
    );
  }

  Future<void> _performLogout() async {
    try {
      isLoggingOut.value = true;

      final userId = authProvider.getUserId();

      if (Get.isRegistered<CacheService>()) {
        Get.find<CacheService>().clearUserSpecificData();
      }

      if (Get.isRegistered<BookmarkController>()) {
        Get.find<BookmarkController>().onUserLoggedOut();
      }

      if (Get.isRegistered<ReadingTrackerService>()) {
        Get.find<ReadingTrackerService>().clearForUser(userId);
      }

      await NotificationService.clearSubscriptions();

      authProvider.clearAuth();
      currentUser.value = null;

      _resetHomeState();

      Get.back(); // tutup dialog

      Get.snackbar(
        'Berhasil',
        'Anda telah keluar',
        snackPosition: SnackPosition.TOP,
        backgroundColor: Colors.green,
        colorText: Colors.white,
      );
    } catch (e) {
      // print(e);
    } finally {
      isLoggingOut.value = false;
    }
  }

  void _resetHomeState() {
    if (!Get.isRegistered<HomeController>()) return;

    final home = Get.find<HomeController>();

    // Reset ke state awal
    home.personalPosts.clear();
    home.activeTab.value = 0;
    home.hasMorePersonal.value = true;
    home.currentPagePersonal.value = 1;
    home.exhaustedCategories.clear();

  }

  void openMenu(String menu) {
    switch (menu) {
      case 'Pedoman Media Siber':
        Get.toNamed(AppRoutes.pedomanMediaSiber);
        break;
      case 'Informasi Personal':
        Get.toNamed(AppRoutes.informasiPersonal);
        break;
      case 'Kode Etik':
        Get.toNamed(AppRoutes.kodeEtik);
        break;
      case 'Disclaimer':
        Get.toNamed(AppRoutes.disclaimer);
        break;
      case 'Redaksi':
        Get.toNamed(AppRoutes.redaksi);
        break;
      case 'Privacy Policy':
        Get.toNamed(AppRoutes.privacyPolicy);
        break;
      case 'Tentang Kami':
        Get.toNamed(AppRoutes.tentangKami);
        break;
      case 'Kontak':
        Get.toNamed(AppRoutes.kontakKami);
        break;
      default:
        Get.snackbar(
          menu,
          'Halaman $menu akan segera hadir',
          snackPosition: SnackPosition.TOP,
        );
    }
  }
}
