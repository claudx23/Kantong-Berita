import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../data/models/notification_model.dart';
import '../../../data/providers/auth_provider.dart';
import '../../../data/providers/api_provider.dart';
import '../../../routes/app_routes.dart';
import '../../../utils/string_helper.dart';

class NotificationsController extends GetxController {
  final AuthProvider authProvider = Get.find<AuthProvider>();
  final ApiProvider apiProvider = Get.find<ApiProvider>();

  final notifications = <NotificationModel>[].obs;
  final isLoading = false.obs;
  final isLoadingMore = false.obs;
  final hasMore = true.obs;
  final currentPage = 1.obs;
  final unreadCount = 0.obs;

  @override
  void onInit() {
    super.onInit();
    loadNotifications();
  }

  // ==================== LOAD ====================

  Future<void> loadNotifications() async {
    if (!authProvider.isLoggedIn()) {
      isLoading.value = false;
      return;
    }

    try {
      isLoading.value = true;
      currentPage.value = 1;

      // ✅ Cukup satu endpoint saja
      final response = await authProvider.getNotifications(page: 1);

      if (response.statusCode == 200 && response.body['success'] == true) {
        final List<dynamic> data = response.body['notifications'];

        notifications.value = data
            .map((n) => NotificationModel.fromJson(n))
            .toList();

        unreadCount.value = response.body['unread_count'] ?? 0;
        hasMore.value =
            (response.body['current_page'] ?? 1) <
            (response.body['total_pages'] ?? 1);
      }

      isLoading.value = false;
    } catch (e) {
      isLoading.value = false;
      // print('Error loading notifications: $e');
    }
  }

  // ==================== LOAD MORE ====================

  Future<void> loadMore() async {
    if (!hasMore.value || isLoadingMore.value) return;

    try {
      isLoadingMore.value = true;
      currentPage.value++;

      final response = await authProvider.getNotifications(
        page: currentPage.value,
      );

      if (response.statusCode == 200 && response.body['success'] == true) {
        final List<dynamic> data = response.body['notifications'];
        notifications.addAll(
          data.map((n) => NotificationModel.fromJson(n)).toList(),
        );
        
        hasMore.value = currentPage.value < (response.body['total_pages'] ?? 1);
      }

      isLoadingMore.value = false;
    } catch (e) {
      isLoadingMore.value = false;
      currentPage.value--;
    }
  }

  @override
  Future<void> refresh() async => await loadNotifications();

  // ==================== MARK READ ====================

  Future<void> markAllRead() async {
    // Update UI dulu (instant)
    notifications.value = notifications.map((n) => n.copyWithRead()).toList();
    unreadCount.value = 0;

    // Update server
    try {
      await authProvider.markAllNotificationsRead();
    } catch (e) {
      // print('Error marking all read: $e');
    }
  }

  Future<void> markRead(NotificationModel notif) async {
    if (notif.isRead) return;

    // Update UI dulu
    final index = notifications.indexWhere((n) => n.id == notif.id);
    if (index != -1) {
      notifications[index] = notif.copyWithRead();
      if (unreadCount.value > 0) unreadCount.value--;
    }

    // Update server
    try {
      await authProvider.markNotificationRead(notif.id);
    } catch (e) {
      // print('Error marking read: $e');
    }
  }

  // ==================== OPEN NOTIFICATION ====================

  void openNotification(NotificationModel notif) {
    markRead(notif);

    if (notif.postId > 0) {
      _navigateToPost(notif.postId);
    }
  }

  Future<void> _navigateToPost(int postId) async {
    try {
      final post = await apiProvider.fetchPostById(postId);
      Get.toNamed(AppRoutes.postDetail, arguments: post);
    } catch (e) {
      Get.snackbar(
        'Error',
        'Gagal membuka berita',
        snackPosition: SnackPosition.TOP,
        backgroundColor: Colors.red,
        colorText: Colors.white,
      );
    }
  }

  // ==================== FETCH UNREAD COUNT ====================

  Future<void> fetchUnreadCount() async {
    if (!authProvider.isLoggedIn()) return;

    try {
      final response = await authProvider.getUnreadCount();
      if (response.statusCode == 200 && response.body['success'] == true) {
        unreadCount.value = response.body['unread_count'] ?? 0;
      }
    } catch (e) {
      // print('Error fetching unread count: $e');
    }
  }

  String getTimeAgo(String date) => StringHelper.timeAgo(date);
}
