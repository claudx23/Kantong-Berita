import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../utils/app_colors.dart';
import '../controllers/notifications_controller.dart';
import '../../../data/models/notification_model.dart';

class NotificationsView extends GetView<NotificationsController> {
  const NotificationsView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.getBackgroundColor(context),
      appBar: AppBar(
        backgroundColor: Theme.of(context).appBarTheme.backgroundColor,
        elevation: 0,
        leading: IconButton(
          icon:  Icon(Icons.arrow_back, color: AppColors.getTextPrimaryColor(context)),
          onPressed: () => Get.back(),
        ),
        title:  Text(
          'Notifikasi',
          style: TextStyle(
            color: AppColors.getTextPrimaryColor(context),
            fontWeight: FontWeight.bold,
            fontSize: 18,
          ),
        ),
        actions: [
          // Mark all read button
          Obx(() => controller.unreadCount.value > 0
              ? TextButton(
                  onPressed: controller.markAllRead,
                  child: const Text(
                    'Tandai semua',
                    style: TextStyle(
                      color: Color(0xFFD32F2F),
                      fontSize: 13,
                    ),
                  ),
                )
              : const SizedBox.shrink()),
        ],
      ),
      body: Obx(() {
        if (controller.isLoading.value) {
          return const Center(
            child: CircularProgressIndicator(
              color: Color(0xFFD32F2F),
            ),
          );
        }

        if (controller.notifications.isEmpty) {
          return _buildEmpty();
        }

        return RefreshIndicator(
          color: const Color(0xFFD32F2F),
          onRefresh: controller.refresh,
          child: ListView.builder(
            itemCount: controller.notifications.length +
                (controller.hasMore.value ? 1 : 0),
            itemBuilder: (context, index) {
              if (index == controller.notifications.length) {
                return _buildLoadMore();
              }
              return _buildNotificationCard(
                controller.notifications[index],
              );
            },
          ),
        );
      }),
    );
  }

  // ==================== NOTIFICATION CARD ====================

  Widget _buildNotificationCard(NotificationModel notif) {
    return GestureDetector(
      onTap: () => controller.openNotification(notif),
      child: Container(
        margin: const EdgeInsets.symmetric(
          horizontal: 12,
          vertical: 4,
        ),
        decoration: BoxDecoration(
          color: notif.isRead ? AppColors.getBackgroundColor(Get.context!) : AppColors.getGreyColor(Get.context!),
          borderRadius: BorderRadius.circular(12),
          border: notif.isRead
              ? null
              : Border.all(
                  color: const Color(0xFFD32F2F).withValues(alpha: 0.5),
                ),
        ),
        child: ListTile(
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 16,
            vertical: 8,
          ),
          leading: _buildNotifIcon(notif),
          title: Row(
            children: [
              Expanded(
                child: Text(
                  notif.title,
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: notif.isRead
                        ? FontWeight.normal
                        : FontWeight.bold,
                    color: AppColors.getTextPrimaryColor(Get.context!),
                  ),
                ),
              ),
              // Unread dot
              if (!notif.isRead)
                Container(
                  width: 8,
                  height: 8,
                  decoration: const BoxDecoration(
                    color: Color(0xFFD32F2F),
                    shape: BoxShape.circle,
                  ),
                ),
            ],
          ),
          subtitle: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 4),
              Text(
                notif.message,
                style: TextStyle(
                  fontSize: 13,
                  color: AppColors.getTextSecondaryColor(Get.context!),
                  height: 1.4,
                ),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
              const SizedBox(height: 6),
              Text(
                controller.getTimeAgo(notif.createdAt),
                style: TextStyle(
                  fontSize: 11,
                  color: AppColors.getTextSecondaryColor(Get.context!),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildNotifIcon(NotificationModel notif) {
    if (notif.type == 'comment_reply') {
      return Container(
        width: 44,
        height: 44,
        decoration: BoxDecoration(
          color: Colors.blue.withValues(alpha: 0.1),
          shape: BoxShape.circle,
        ),
        child: const Icon(
          Icons.reply_rounded,
          color: Colors.blue,
          size: 22,
        ),
      );
    }

    // Type 'post'
    return Container(
      width: 44,
      height: 44,
      decoration: BoxDecoration(
        color: const Color(0xFFD32F2F).withValues(alpha: 0.1),
        shape: BoxShape.circle,
      ),
      child: const Icon(
        Icons.newspaper_rounded,
        color: Color(0xFFD32F2F),
        size: 22,
      ),
    );
  }

  // ==================== LOAD MORE ====================

  Widget _buildLoadMore() {
    return Obx(() => Padding(
          padding: const EdgeInsets.all(16),
          child: Center(
            child: controller.isLoadingMore.value
                ? const CircularProgressIndicator(
                    color: Color(0xFFD32F2F),
                  )
                : TextButton(
                    onPressed: controller.loadMore,
                    child: const Text(
                      'Muat lebih banyak',
                      style: TextStyle(color: Color(0xFFD32F2F)),
                    ),
                  ),
          ),
        ));
  }

  // ==================== EMPTY STATE ====================

  Widget _buildEmpty() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.notifications_none_rounded,
            size: 80,
            color: AppColors.getTextSecondaryColor(Get.context!),
          ),
          const SizedBox(height: 16),
          Text(
            'Belum ada notifikasi',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w600,
              color: AppColors.getTextSecondaryColor(Get.context!),
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Notifikasi berita dan balasan\nkomentar akan muncul di sini',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 14,
              color: AppColors.getTextSecondaryColor(Get.context!),
            ),
          ),
        ],
      ),
    );
  }
}