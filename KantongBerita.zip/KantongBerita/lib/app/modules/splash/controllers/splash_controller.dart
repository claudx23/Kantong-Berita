import 'package:get/get.dart';
import 'package:kantongberita/app/data/models/post_model.dart';
import '../../../data/providers/api_provider.dart';
import '../../../data/providers/auth_provider.dart';
import '../../../routes/app_routes.dart';
import '../../../services/notification_service.dart';

class SplashController extends GetxController {
  final AuthProvider authProvider = Get.find<AuthProvider>();

  @override
  void onInit() {
    super.onInit();
    _init();
  }

  Future<void> _init() async {
    await Future.wait([
      _prefetchData(),
      Future.delayed(const Duration(seconds: 2)),
    ]);

    // ✅ Resubscribe jika sudah login
    if (authProvider.isLoggedIn()) {
      await _resubscribeTopics();
    }

    _navigate();
  }

  Future<void> _resubscribeTopics() async {
    try {
      final response = await authProvider.getPreferences();

      if (response.statusCode == 200 && response.body['success'] == true) {
        final prefs = response.body['preferences'];

        final List<int> categoryIds = [
          ...List<int>.from(prefs['preferred_categories'] ?? []),
          ...List<int>.from(prefs['preferred_locations'] ?? []),
        ];

        if (categoryIds.isNotEmpty) {
          await NotificationService.updateSubscriptions(categoryIds);
          // print('✅ Topics resubscribed on splash');
        }
      }
    } catch (e) {
      // print('⚠️ Resubscribe on splash failed: $e');
    }
  }

  // ✅ Prefetch data saat splash masih tampil
  Future<void> _prefetchData() async {
    try {
      final apiProvider = Get.find<ApiProvider>();

      final results = await Future.wait([
        apiProvider.fetchPosts(page: 1, perPage: 20),
        apiProvider.fetchCategories(),
      ]);

      apiProvider.prefetchedPosts = results[0] as List<PostModel>;
      apiProvider.prefetchedCategories = results[1] as Map<String, int>;

      // print('✅ Prefetch selesai');
    } catch (e) {
      // print('⚠️ Prefetch gagal: $e');
    }
  }

  Future<void> _navigate() async {
    if (authProvider.isLoggedIn() || authProvider.hasVisitedBefore()) {
      Get.offAllNamed(AppRoutes.main);
    } else {
      Get.offAllNamed(AppRoutes.start);
    }
  }
}
