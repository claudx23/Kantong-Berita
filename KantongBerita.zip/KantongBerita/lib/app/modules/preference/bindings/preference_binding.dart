import 'package:get/get.dart';
import '../../../data/providers/auth_provider.dart';
import '../controllers/preference_controller.dart';

class PreferenceBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<AuthProvider>(() => AuthProvider());
    Get.lazyPut<PreferenceController>(() => PreferenceController());
  }
}