import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/preference_controller.dart';
import '../../../utils/app_colors.dart';

class PreferenceView extends GetView<PreferenceController> {
  const PreferenceView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.getBackgroundColor(Get.context!),
      appBar: _buildAppBar(),
      body: Obx(() {
        if (controller.isLoading.value) {
          return const Center(
            child: CircularProgressIndicator(color: Color(0xFFD32F2F)),
          );
        }

        return Column(
          children: [
            // Tab Bar
            _buildTabBar(),

            // Content
            Expanded(
              child: Obx(
                () => controller.activeTab.value == 0
                    ? _buildUmumGrid()
                    : _buildLokalGrid(),
              ),
            ),

            // Bottom Button
            _buildBottomButton(),
          ],
        );
      }),
    );
  }

  // ==================== APP BAR ====================

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      elevation: 0,
      automaticallyImplyLeading: false,
      title: Obx(
        () => Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              controller.isEditing.value
                  ? 'Edit Preferensi'
                  : 'Pilih Topik Favorit',
              style: TextStyle(
                color: AppColors.getTextPrimaryColor(Get.context!),
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            Text(
              controller.isEditing.value
                  ? 'Perbarui kategori yang ingin kamu ikuti'
                  : 'Pilih kategori yang ingin kamu ikuti',
              style: TextStyle(
                color: AppColors.getTextSecondaryColor(Get.context!),
                fontSize: 12,
                fontWeight: FontWeight.normal,
              ),
            ),
          ],
        ),
      ),
      actions: [
        // Skip button (hanya first time)
        Obx(
          () => !controller.isEditing.value
              ? TextButton(
                  onPressed: controller.skip,
                  child: Text(
                    'Lewati',
                    style: TextStyle(
                      color: AppColors.getTextPrimaryColor(Get.context!),
                      fontSize: 14,
                    ),
                  ),
                )
              : IconButton(
                  icon: const Icon(Icons.close, color: Colors.grey),
                  onPressed: () => Get.back(),
                ),
        ),
      ],
    );
  }

  // ==================== TAB BAR ====================

  Widget _buildTabBar() {
    return Obx(
      () => Container(
        margin: const EdgeInsets.fromLTRB(16, 8, 16, 0),
        decoration: BoxDecoration(
          color: AppColors.getCardColor(Get.context!),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(
          children: [
            _buildTab(
              0,
              'Umum',
              controller.selectedUmum.length,
              PreferenceController.maxUmum,
            ),
            _buildTab(
              1,
              'Lokal',
              controller.selectedLokal.length,
              PreferenceController.maxLokal,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTab(int index, String label, int selectedCount, int maxCount) {
    final isActive = controller.activeTab.value == index;

    return Expanded(
      child: GestureDetector(
        onTap: () => controller.activeTab.value = index,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          margin: const EdgeInsets.all(4),
          padding: const EdgeInsets.symmetric(vertical: 10),
          decoration: BoxDecoration(
            color: isActive
                ? AppColors.primary.withValues(alpha: 0.08)
                : Colors.transparent,
            border: isActive
                ? Border.all(color: AppColors.primary, width: 2)
                : null,
            borderRadius: BorderRadius.circular(8),
            boxShadow: isActive
                ? [
                    BoxShadow(
                      color: Colors.black.withValues(alpha: 0.1),
                      blurRadius: 4,
                    ),
                  ]
                : null,
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                label,
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: isActive ? FontWeight.bold : FontWeight.normal,
                  color: isActive
                      ? AppColors.getTextPrimaryColor(Get.context!)
                      : AppColors.getTextSecondaryColor(Get.context!),
                ),
              ),
              if (selectedCount > 0) ...[
                const SizedBox(width: 6),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 6,
                    vertical: 2,
                  ),
                  decoration: BoxDecoration(
                    color: const Color(0xFFD32F2F),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Text(
                    '$selectedCount/$maxCount',
                    style: TextStyle(
                      color: AppColors.getTextPrimaryColor(Get.context!),
                      fontSize: 11,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  // ==================== UMUM GRID ====================

  Widget _buildUmumGrid() {
    return GridView.builder(
      padding: const EdgeInsets.all(16),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
        childAspectRatio: 1.0,
      ),
      itemCount: controller.umumCategories.length,
      itemBuilder: (context, index) {
        final category = controller.umumCategories[index];
        return Obx(
          () => _buildCategoryCard(
            name: category.name,
            icon: _getUmumIcon(category.slug),
            isSelected: controller.isUmumSelected(category.id),
            onTap: () => controller.toggleUmum(category.id),
          ),
        );
      },
    );
  }

  // ==================== LOKAL GRID ====================

  Widget _buildLokalGrid() {
    return GridView.builder(
      padding: const EdgeInsets.all(16),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
        childAspectRatio: 1.0,
      ),
      itemCount: controller.lokalCategories.length,
      itemBuilder: (context, index) {
        final category = controller.lokalCategories[index];
        return Obx(
          () => _buildCategoryCard(
            name: category.name,
            icon: Icons.location_city,
            isSelected: controller.isLokalSelected(category.id),
            onTap: () => controller.toggleLokal(category.id),
          ),
        );
      },
    );
  }

  // ==================== CATEGORY CARD ====================

  Widget _buildCategoryCard({
    required String name,
    required IconData icon,
    required bool isSelected,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        decoration: BoxDecoration(
          color: isSelected
              ? const Color(0xFFD32F2F).withValues(alpha: 0.1)
              : AppColors.getCardColor(Get.context!),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: isSelected
                ? AppColors.primary
                : AppColors.getBorderColor(Get.context!),
            width: 2,
          ),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Icon dengan checkmark jika selected
            Stack(
              alignment: Alignment.topRight,
              children: [
                Container(
                  width: 48,
                  height: 48,
                  decoration: BoxDecoration(
                    color: isSelected
                        ? const Color(0xFFD32F2F).withValues(alpha: 0.15)
                        : AppColors.getCardColor(Get.context!),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(
                    icon,
                    size: 26,
                    color: isSelected
                        ? AppColors.primary
                        : AppColors.getTextSecondaryColor(Get.context!),
                  ),
                ),
                if (isSelected)
                  Container(
                    width: 18,
                    height: 18,
                    decoration: const BoxDecoration(
                      color: Color(0xFFD32F2F),
                      shape: BoxShape.circle,
                    ),
                    child: Icon(
                      Icons.check,
                      size: 12,
                      color: AppColors.getTextPrimaryColor(Get.context!),
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 8),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 4),
              child: Text(
                name,
                textAlign: TextAlign.center,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  fontSize: 11,
                  fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                  color: isSelected
                      ? AppColors.primary
                      : AppColors.getTextSecondaryColor(Get.context!),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ==================== BOTTOM BUTTON ====================

  Widget _buildBottomButton() {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
      decoration: BoxDecoration(
        color: AppColors.getBackgroundColor(Get.context!),
        boxShadow: [
          BoxShadow(
            color: AppColors.getBorderColor(
              Get.context!,
            ).withValues(alpha: 0.5),
            blurRadius: 10,
            offset: const Offset(0, -5),
          ),
        ],
      ),
      child: Column(
        children: [
          // Info selected count
          Obx(
            () => controller.totalSelected > 0
                ? Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: Text(
                      '${controller.totalSelected} kategori dipilih',
                      style: const TextStyle(
                        color: Color(0xFFD32F2F),
                        fontSize: 13,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  )
                : Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: Text(
                      'Pilih minimal 1 kategori',
                      style: TextStyle(
                        color: AppColors.getTextSecondaryColor(Get.context!),
                        fontSize: 13,
                      ),
                    ),
                  ),
          ),

          // Save Button
          Obx(
            () => SizedBox(
              width: double.infinity,
              height: 50,
              child: ElevatedButton(
                onPressed: controller.isSaving.value
                    ? null
                    : controller.savePreferences,
                style: ElevatedButton.styleFrom(
                  backgroundColor: controller.totalSelected > 0
                      ? AppColors.primary
                      : AppColors.getCardColor(Get.context!),
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  elevation: 0,
                ),
                child: controller.isSaving.value
                    ? SizedBox(
                        width: 24,
                        height: 24,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          color: AppColors.getTextPrimaryColor(Get.context!),
                        ),
                      )
                    : Text(
                        controller.isEditing.value
                            ? 'Simpan Perubahan'
                            : 'Mulai Membaca',
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ==================== ICON MAPPING ====================

  IconData _getUmumIcon(String slug) {
    switch (slug) {
      case 'berita-utama':
        return Icons.newspaper;
      case 'bisnis':
        return Icons.business_center;
      case 'ekonomi':
        return Icons.attach_money;
      case 'gaya-hidup':
        return Icons.spa;
      case 'hukum':
        return Icons.gavel;
      case 'industri':
        return Icons.factory;
      case 'infrastruktur':
        return Icons.construction;
      case 'kesehatan':
        return Icons.local_hospital;
      case 'nasional':
        return Icons.flag;
      case 'olahraga':
        return Icons.sports_soccer;
      case 'headline':
        return Icons.how_to_vote;
      case 'seleb':
        return Icons.star;
      case 'teknologi':
        return Icons.computer;
      case 'viral':
        return Icons.trending_up;
      case 'wisata':
        return Icons.flight;
      default:
        return Icons.category;
    }
  }
}
