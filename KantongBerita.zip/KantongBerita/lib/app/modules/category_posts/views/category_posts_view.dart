import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:kantongberita/app/utils/app_colors.dart';
import '../../../data/models/post_model.dart';
import '../../../routes/app_routes.dart';
import '../../../widgets/post_skeleton.dart';
import '../controllers/category_posts_controller.dart';

class CategoryPostsView extends GetView<CategoryPostsController> {
  const CategoryPostsView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.getBackgroundColor(context),
      appBar: AppBar(
        backgroundColor: AppColors.getBackgroundColor(context),
        elevation: 0,
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back,
            color: AppColors.getTextPrimaryColor(context),
          ),
          onPressed: () => Get.back(),
        ),
        title: Text(
          controller.categoryName,
          style: TextStyle(
            color: AppColors.getTextPrimaryColor(context),
            fontWeight: FontWeight.bold,
            fontSize: 18,
          ),
        ),
      ),
      body: Obx(() {
        // ==================== LOADING ====================
        if (controller.isLoading.value && controller.posts.isEmpty) {
          return ListView.builder(
            itemCount: 6,
            itemBuilder: (context, index) => const PostSkeleton(),
          );
        }

        // ==================== ERROR ====================
        if (controller.errorMessage.value.isNotEmpty &&
            controller.posts.isEmpty) {
          return _buildErrorState();
        }

        // ==================== EMPTY ====================
        if (controller.posts.isEmpty) {
          return _buildEmptyState();
        }

        // ==================== SUCCESS ====================
        return RefreshIndicator(
          color: const Color(0xFFD32F2F),
          onRefresh: controller.refreshPosts,
          child: Column(
            children: [
              Expanded(
                child: ListView.builder(
                  controller: controller.scrollController,
                  itemCount: controller.posts.length,
                  itemBuilder: (context, index) {
                    return _buildPostCard(controller.posts[index]);
                  },
                ),
              ),

              // Load More
              _buildLoadMore(),
            ],
          ),
        );
      }),
    );
  }

  // ==================== ERROR STATE ====================

  Widget _buildErrorState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Icon
            Container(
              width: 80,
              height: 80,
              decoration: BoxDecoration(
                color: Colors.red[50],
                shape: BoxShape.circle,
              ),
              child: Icon(
                _getErrorIcon(controller.errorMessage.value),
                size: 40,
                color: Colors.red[300],
              ),
            ),

            const SizedBox(height: 20),

            // Pesan error
            Obx(
              () => Text(
                controller.errorMessage.value,
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 15,
                  color: Colors.grey[600],
                  height: 1.5,
                ),
              ),
            ),

            const SizedBox(height: 8),

            // Retry count info
            Obx(
              () => controller.retryCount.value > 0
                  ? Text(
                      'Percobaan ke-${controller.retryCount.value}',
                      style: TextStyle(fontSize: 12, color: Colors.grey[400]),
                    )
                  : const SizedBox.shrink(),
            ),

            const SizedBox(height: 28),

            // Retry button
            Obx(
              () => SizedBox(
                width: double.infinity,
                height: 48,
                child: ElevatedButton.icon(
                  onPressed: controller.isLoading.value
                      ? null
                      : controller.retry,
                  icon: controller.isLoading.value
                      ? const SizedBox(
                          width: 16,
                          height: 16,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: Colors.white,
                          ),
                        )
                      : const Icon(Icons.refresh, size: 18),
                  label: Text(
                    controller.isLoading.value ? 'Memuat...' : 'Coba Lagi',
                    style: const TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFD32F2F),
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    elevation: 0,
                  ),
                ),
              ),
            ),

            const SizedBox(height: 12),

            // Back button
            TextButton(
              onPressed: () => Get.back(),
              child: Text('Kembali', style: TextStyle(color: Colors.grey[500])),
            ),
          ],
        ),
      ),
    );
  }

  IconData _getErrorIcon(String error) {
    if (error.contains('internet') || error.contains('koneksi')) {
      return Icons.wifi_off_rounded;
    }
    if (error.contains('lambat') || error.contains('Timeout')) {
      return Icons.hourglass_disabled_rounded;
    }
    if (error.contains('Server')) {
      return Icons.cloud_off_rounded;
    }
    return Icons.error_outline_rounded;
  }

  // ==================== EMPTY STATE ====================

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.inbox,
            size: 64,
            color: AppColors.getGreyColor(Get.context!),
          ),
          const SizedBox(height: 12),
          Text(
            'Tidak ada berita',
            style: TextStyle(
              color: AppColors.getTextSecondaryColor(Get.context!),
            ),
          ),
        ],
      ),
    );
  }

  // ==================== LOAD MORE ====================

  Widget _buildLoadMore() {
    return Obx(() {
      if (controller.isLoadingMore.value) {
        return const Padding(
          padding: EdgeInsets.all(16),
          child: Center(
            child: CircularProgressIndicator(
              color: Color(0xFFD32F2F),
              strokeWidth: 2,
            ),
          ),
        );
      }

      if (controller.hasMore.value) {
        return Padding(
          padding: const EdgeInsets.all(16),
          child: SizedBox(
            width: double.infinity,
            child: OutlinedButton(
              onPressed: controller.loadMorePosts,
              style: OutlinedButton.styleFrom(
                foregroundColor: const Color(0xFFD32F2F),
                side: const BorderSide(color: Color(0xFFD32F2F)),
                padding: const EdgeInsets.symmetric(vertical: 12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
              child: const Text(
                'Selengkapnya',
                style: TextStyle(fontWeight: FontWeight.w600),
              ),
            ),
          ),
        );
      }

      return Padding(
        padding: const EdgeInsets.all(16),
        child: Center(
          child: Text(
            'Semua berita telah ditampilkan',
            style: TextStyle(
              color: AppColors.getTextSecondaryColor(Get.context!),
              fontSize: 13,
            ),
          ),
        ),
      );
    });
  }

  // ==================== POST CARD ====================

  Widget _buildPostCard(PostModel post) {
    return GestureDetector(
      onTap: () => Get.toNamed(AppRoutes.postDetail, arguments: post),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: CachedNetworkImage(
                imageUrl: post.featuredImage,
                width: 90,
                height: 90,
                fit: BoxFit.cover,
                placeholder: (context, url) =>
                    Container(color: Colors.grey[300]),
                errorWidget: (context, url, error) => Container(
                  color: Colors.grey[200],
                  child: const Icon(
                    Icons.image_not_supported,
                    color: Colors.grey,
                  ),
                ),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      if (post.categoryName.isNotEmpty)
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 6,
                            vertical: 2,
                          ),
                          decoration: BoxDecoration(
                            color: const Color(0xFFD32F2F),
                            borderRadius: BorderRadius.circular(3),
                          ),
                          child: Text(
                            post.categoryName,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 9,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      const SizedBox(width: 6),
                      Text(
                        controller.getTimeAgo(post.date),
                        style: TextStyle(
                          color: AppColors.getTextSecondaryColor(Get.context!),
                          fontSize: 11,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 6),
                  Text(
                    post.title,
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                      color: AppColors.getTextPrimaryColor(Get.context!),
                      height: 1.4,
                    ),
                    maxLines: 3,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
