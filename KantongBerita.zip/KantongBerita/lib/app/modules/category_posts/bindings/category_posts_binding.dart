import 'package:get/get.dart';
import '../../../data/providers/api_provider.dart';
import '../controllers/category_posts_controller.dart';

class CategoryPostsBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<ApiProvider>(() => ApiProvider());
    Get.lazyPut<CategoryPostsController>(() => CategoryPostsController());
  }
}