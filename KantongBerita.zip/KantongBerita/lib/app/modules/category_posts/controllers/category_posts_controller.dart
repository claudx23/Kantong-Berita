import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:kantongberita/app/utils/scroll_to_top_mixin.dart';
import '../../../data/models/post_model.dart';
import '../../../data/providers/api_provider.dart';
import '../../../utils/string_helper.dart';

class CategoryPostsController extends GetxController with ScrollToTopMixin {
  final ApiProvider apiProvider = Get.find<ApiProvider>();

  final posts          = <PostModel>[].obs;
  final isLoading      = false.obs;
  final isLoadingMore  = false.obs;
  final hasMore        = true.obs;
  final currentPage    = 1.obs;
  final errorMessage   = ''.obs;
  final retryCount     = 0.obs;

  late String categoryName;
  late int    categoryId;
  late String categorySlug;

  @override
  void onInit() {
    super.onInit();
    setupScrollToTop();
    final args = Get.arguments as Map<String, dynamic>;
    categoryName = args['categoryName'] ?? '';
    categoryId   = args['categoryId']   ?? 0;
    categorySlug = args['categorySlug'] ?? '';
    loadPosts();
  }

  // ==================== LOAD POSTS ====================

  Future<void> loadPosts() async {
    try {
      isLoading.value   = true;
      errorMessage.value = '';
      currentPage.value = 1;

      final List<PostModel> fetched = await apiProvider.fetchPostsByCategory(
        categoryId: categoryId,
        page: 1,
        perPage: 10,
      );

      posts.value   = fetched;
      hasMore.value = fetched.length >= 10;
      isLoading.value = false;
    } catch (e) {
      isLoading.value    = false;
      errorMessage.value = _parseError(e.toString());
    }
  }

  // ✅ Manual retry dari user
  Future<void> retry() async {
    retryCount.value++;
    await loadPosts();
  }

  // ==================== LOAD MORE ====================

  Future<void> loadMorePosts() async {
    if (isLoadingMore.value || !hasMore.value) return;

    try {
      isLoadingMore.value = true;
      currentPage.value++;

      final List<PostModel> newPosts = await apiProvider.fetchPostsByCategory(
        categoryId: categoryId,
        page: currentPage.value,
        perPage: 10,
      );

      if (newPosts.isEmpty) {
        hasMore.value = false;
      } else {
        posts.addAll(newPosts);
        hasMore.value = newPosts.length >= 10;
      }

      isLoadingMore.value = false;
    } catch (e) {
      isLoadingMore.value = false;
      currentPage.value--;

      // ✅ Snackbar dengan tombol retry untuk load more
      Get.snackbar(
        'Gagal memuat',
        'Koneksi bermasalah. Coba lagi?',
        snackPosition: SnackPosition.TOP,
        backgroundColor: Colors.red[700],
        colorText: Colors.white,
        duration: const Duration(seconds: 4),
        mainButton: TextButton(
          onPressed: () {
            Get.closeAllSnackbars();
            loadMorePosts();
          },
          child: const Text(
            'Coba Lagi',
            style: TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      );
    }
  }

  Future<void> refreshPosts() async {
    errorMessage.value = '';
    await loadPosts();
  }

  // ==================== ERROR PARSER ====================

  String _parseError(String error) {
    if (error.contains('SocketException') ||
        error.contains('Connection refused') ||
        error.contains('Network')) {
      return 'Tidak ada koneksi internet.\nPeriksa koneksi Anda.';
    }

    if (error.contains('TimeoutException') ||
        error.contains('Timeout')) {
      return 'Koneksi terlalu lambat.\nCoba lagi.';
    }

    if (error.contains('HTTP 5')) {
      return 'Server sedang bermasalah.\nCoba beberapa saat lagi.';
    }

    return 'Gagal memuat berita.\nCoba lagi.';
  }

  String getTimeAgo(String date) => StringHelper.timeAgo(date);
}