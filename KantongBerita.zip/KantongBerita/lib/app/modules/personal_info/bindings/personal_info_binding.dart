import 'package:get/get.dart';
import '../../../data/providers/auth_provider.dart';
import '../controllers/personal_info_controller.dart';

class PersonalInfoBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<AuthProvider>(() => AuthProvider());
    Get.lazyPut<PersonalInfoController>(() => PersonalInfoController());
  }
}