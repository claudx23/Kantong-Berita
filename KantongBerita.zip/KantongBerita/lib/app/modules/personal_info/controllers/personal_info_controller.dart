import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../data/models/user_model.dart';
import '../../../data/providers/auth_provider.dart';

class PersonalInfoController extends GetxController {
  final AuthProvider authProvider = Get.find<AuthProvider>();

  // Form Controllers
  final nameController = TextEditingController();
  final emailController = TextEditingController();
  final oldPasswordController = TextEditingController();
  final newPasswordController = TextEditingController();
  final confirmPasswordController = TextEditingController();

  // Observables
  final currentUser = Rx<UserModel?>(null);
  final isLoading = false.obs;
  final isSaving = false.obs;
  final isSavingPassword = false.obs;
  final isOldPasswordVisible = false.obs;
  final isNewPasswordVisible = false.obs;
  final isConfirmPasswordVisible = false.obs;

  // Tab: 0 = Info, 1 = Password
  final activeTab = 0.obs;

  @override
  void onInit() {
    super.onInit();
    loadProfile();
  }

  @override
  void onClose() {
    nameController.dispose();
    emailController.dispose();
    oldPasswordController.dispose();
    newPasswordController.dispose();
    confirmPasswordController.dispose();
    super.onClose();
  }

  // ==================== LOAD PROFILE ====================

  Future<void> loadProfile() async {
    try {
      isLoading.value = true;

      final response = await authProvider.getProfile();

      if (response.statusCode == 200 && response.body['success'] == true) {
        final user = UserModel.fromJson(response.body['user']);
        currentUser.value = user;

        // Isi form dengan data saat ini
        nameController.text = user.name;
        emailController.text = user.email;
      }

      isLoading.value = false;
    } catch (e) {
      isLoading.value = false;
      Get.snackbar(
        'Error',
        'Gagal memuat profil',
        snackPosition: SnackPosition.TOP,
        backgroundColor: Colors.red,
        colorText: Colors.white,
      );
    }
  }

  // ==================== SAVE PROFILE ====================

  Future<void> saveProfile() async {
    final name = nameController.text.trim();
    final email = emailController.text.trim();

    // Validasi
    if (name.isEmpty) {
      _showError('Nama tidak boleh kosong');
      return;
    }

    if (email.isEmpty) {
      _showError('Email tidak boleh kosong');
      return;
    }

    if (!GetUtils.isEmail(email)) {
      _showError('Format email tidak valid');
      return;
    }

    // Cek apakah ada perubahan
    if (name == currentUser.value?.name && email == currentUser.value?.email) {
      _showError('Tidak ada perubahan yang disimpan');
      return;
    }

    try {
      isSaving.value = true;

      final response = await authProvider.updateProfile(
        name: name,
        email: email,
      );

      if (response.statusCode == 200 && response.body['success'] == true) {
        // Update local user data
        final updatedUser = UserModel(
          id: currentUser.value!.id,
          username: currentUser.value!.username,
          email: email,
          name: name,
        );

        currentUser.value = updatedUser;
        authProvider.saveUser(updatedUser);

        _showSuccess('Profil berhasil diperbarui');
      } else {
        _showError(response.body['message'] ?? 'Gagal memperbarui profil');
      }
    } catch (e) {
      _showError('Terjadi kesalahan: $e');
    } finally {
      isSaving.value = false;
    }
  }

  // ==================== SAVE PASSWORD ====================

  Future<void> savePassword() async {
    final oldPassword = oldPasswordController.text;
    final newPassword = newPasswordController.text;
    final confirmPassword = confirmPasswordController.text;

    // Validasi
    if (oldPassword.isEmpty) {
      _showError('Password lama harus diisi');
      return;
    }

    if (newPassword.isEmpty) {
      _showError('Password baru harus diisi');
      return;
    }

    if (newPassword.length < 6) {
      _showError('Password baru minimal 6 karakter');
      return;
    }

    if (newPassword != confirmPassword) {
      _showError('Konfirmasi password tidak cocok');
      return;
    }

    if (oldPassword == newPassword) {
      _showError('Password baru tidak boleh sama dengan password lama');
      return;
    }

    try {
      isSavingPassword.value = true;

      final response = await authProvider.updatePassword(
        oldPassword: oldPassword,
        newPassword: newPassword,
      );

      if (response.statusCode == 200 && response.body['success'] == true) {
        // Clear password fields
        oldPasswordController.clear();
        newPasswordController.clear();
        confirmPasswordController.clear();
        
        // Update token baru jika ada
        if (response.body['new_token'] != null) {
          authProvider.saveToken(response.body['new_token']);
        }

        _showSuccess('Password berhasil diperbarui');
      } else {
        _showError(response.body['message'] ?? 'Gagal memperbarui password');
      }
    } catch (e) {
      _showError('Terjadi kesalahan: $e');
    } finally {
      isSavingPassword.value = false;
    }
  }

  // ==================== HELPERS ====================

  void toggleOldPasswordVisibility() =>
      isOldPasswordVisible.value = !isOldPasswordVisible.value;

  void toggleNewPasswordVisibility() =>
      isNewPasswordVisible.value = !isNewPasswordVisible.value;

  void toggleConfirmPasswordVisibility() =>
      isConfirmPasswordVisible.value = !isConfirmPasswordVisible.value;

  void _showSuccess(String message) {
    Get.snackbar(
      'Berhasil',
      message,
      snackPosition: SnackPosition.TOP,
      backgroundColor: Colors.green,
      colorText: Colors.white,
      duration: const Duration(seconds: 2),
    );
  }

  void _showError(String message) {
    Get.snackbar(
      'Error',
      message,
      snackPosition: SnackPosition.TOP,
      backgroundColor: Colors.red,
      colorText: Colors.white,
    );
  }
}
