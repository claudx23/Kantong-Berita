import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../widgets/avatar_initial.dart';
import '../controllers/personal_info_controller.dart';
import '../../../utils/app_colors.dart';

class PersonalInfoView extends GetView<PersonalInfoController> {
  const PersonalInfoView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.getBackgroundColor(
        context,
      ).withValues(alpha: 0.8),
      appBar: AppBar(
        backgroundColor: AppColors.getBackgroundColor(context),
        elevation: 0,
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back,
            color: AppColors.getTextPrimaryColor(context),
          ),
          onPressed: () => Get.back(),
        ),
        title: Text(
          'Informasi Personal',
          style: TextStyle(
            color: AppColors.getTextPrimaryColor(context),
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      body: Obx(() {
        if (controller.isLoading.value) {
          return const Center(
            child: CircularProgressIndicator(color: Color(0xFFD32F2F)),
          );
        }

        return SingleChildScrollView(
          child: Column(
            children: [
              // Tab Bar
              _buildTabBar(),

              const SizedBox(height: 16),

              // Content
              Obx(
                () => controller.activeTab.value == 0
                    ? _buildProfileForm()
                    : _buildPasswordForm(),
              ),
            ],
          ),
        );
      }),
    );
  }

  // ==================== TAB BAR ====================

  Widget _buildTabBar() {
    return Container(
      color: AppColors.getBackgroundColor(Get.context!),
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
      child: Obx(
        () => Row(
          children: [
            _buildTab(0, 'Profil Saya'),
            const SizedBox(width: 24),
            _buildTab(1, 'Ubah Password'),
          ],
        ),
      ),
    );
  }

  Widget _buildTab(int index, String label) {
    final isActive = controller.activeTab.value == index;
    return GestureDetector(
      onTap: () => controller.activeTab.value = index,
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 12),
            child: Text(
              label,
              style: TextStyle(
                fontSize: 14,
                fontWeight: isActive ? FontWeight.bold : FontWeight.normal,
                color: isActive
                    ? const Color(0xFFD32F2F)
                    : AppColors.getTextSecondaryColor(Get.context!),
              ),
            ),
          ),
          AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            height: 2,
            width: 80,
            color: isActive ? const Color(0xFFD32F2F) : Colors.transparent,
          ),
        ],
      ),
    );
  }

  // ==================== PROFILE FORM ====================

  Widget _buildProfileForm() {
    return Column(
      children: [
        // Avatar Section
        _buildAvatarSection(),

        const SizedBox(height: 16),

        // Form Section
        Container(
          margin: const EdgeInsets.symmetric(horizontal: 16),
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: AppColors.getBackgroundColor(Get.context!),
            borderRadius: BorderRadius.circular(16),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Data Pribadi',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: AppColors.getTextPrimaryColor(Get.context!),
                ),
              ),
              const SizedBox(height: 20),

              // Username (read only)
              Obx(
                () => _buildReadOnlyField(
                  label: 'Username',
                  value: controller.currentUser.value?.username ?? '',
                  icon: Icons.account_circle_outlined,
                  helperText: 'Username tidak dapat diubah',
                ),
              ),

              const SizedBox(height: 16),

              // Nama Lengkap
              _buildTextField(
                controller: controller.nameController,
                label: 'Nama Lengkap',
                icon: Icons.person_outline,
                hint: 'Masukkan nama lengkap',
              ),

              const SizedBox(height: 16),

              // Email
              _buildTextField(
                controller: controller.emailController,
                label: 'Email',
                icon: Icons.email_outlined,
                hint: 'Masukkan email',
                keyboardType: TextInputType.emailAddress,
              ),

              const SizedBox(height: 24),

              // Save Button
              Obx(
                () => SizedBox(
                  width: double.infinity,
                  height: 50,
                  child: ElevatedButton(
                    onPressed: controller.isSaving.value
                        ? null
                        : controller.saveProfile,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFD32F2F),
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      elevation: 0,
                    ),
                    child: controller.isSaving.value
                        ? const SizedBox(
                            width: 24,
                            height: 24,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color: Colors.white,
                            ),
                          )
                        : const Text(
                            'Simpan Perubahan',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                  ),
                ),
              ),
            ],
          ),
        ),

        const SizedBox(height: 32),
      ],
    );
  }

  // ==================== AVATAR ====================

  Widget _buildAvatarSection() {
    return Container(
      width: double.infinity,
      color: AppColors.getCardColor(Get.context!),
      padding: const EdgeInsets.symmetric(vertical: 24),
      child: Column(
        children: [
          Obx(
            () => AvatarInitial(
              name: controller.currentUser.value?.name.isNotEmpty == true
                  ? controller.currentUser.value!.name
                  : controller.currentUser.value?.username ?? '',
              radius: 50,
              fontSize: 28,
            ),
          ),

          const SizedBox(height: 12),

          // Nama
          Obx(
            () => Text(
              controller.currentUser.value?.name ?? '',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: AppColors.getTextPrimaryColor(Get.context!),
              ),
            ),
          ),

          const SizedBox(height: 4),

          // Username
          Obx(
            () => Text(
              '@${controller.currentUser.value?.username ?? ''}',
              style: TextStyle(
                fontSize: 13,
                color: AppColors.getTextSecondaryColor(Get.context!),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ==================== PASSWORD FORM ====================

  Widget _buildPasswordForm() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppColors.getCardColor(Get.context!),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Ubah Password',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: AppColors.getTextPrimaryColor(Get.context!),
            ),
          ),

          const SizedBox(height: 8),

          Text(
            'Password minimal 6 karakter',
            style: TextStyle(
              fontSize: 12,
              color: AppColors.getTextSecondaryColor(Get.context!),
            ),
          ),

          const SizedBox(height: 20),

          // Old Password
          Obx(
            () => _buildPasswordField(
              controller: controller.oldPasswordController,
              label: 'Password Lama',
              isVisible: controller.isOldPasswordVisible.value,
              onToggle: controller.toggleOldPasswordVisibility,
            ),
          ),

          const SizedBox(height: 16),

          Divider(color: AppColors.getBorderColor(Get.context!)),

          const SizedBox(height: 16),

          // New Password
          Obx(
            () => _buildPasswordField(
              controller: controller.newPasswordController,
              label: 'Password Baru',
              isVisible: controller.isNewPasswordVisible.value,
              onToggle: controller.toggleNewPasswordVisibility,
            ),
          ),

          const SizedBox(height: 16),

          // Confirm Password
          Obx(
            () => _buildPasswordField(
              controller: controller.confirmPasswordController,
              label: 'Konfirmasi Password Baru',
              isVisible: controller.isConfirmPasswordVisible.value,
              onToggle: controller.toggleConfirmPasswordVisibility,
            ),
          ),
          const SizedBox(height: 24),

          // Save Button
          Obx(
            () => SizedBox(
              width: double.infinity,
              height: 50,
              child: ElevatedButton(
                onPressed: controller.isSavingPassword.value
                    ? null
                    : controller.savePassword,
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFD32F2F),
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  elevation: 0,
                ),
                child: controller.isSavingPassword.value
                    ? const SizedBox(
                        width: 24,
                        height: 24,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          color: Colors.white,
                        ),
                      )
                    : const Text(
                        'Perbarui Password',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
              ),
            ),
          ),

          const SizedBox(height: 16),
        ],
      ),
    );
  }

  // ==================== WIDGET HELPERS ====================

  Widget _buildTextField({
    required TextEditingController controller,
    required String label,
    required IconData icon,
    String? hint,
    TextInputType keyboardType = TextInputType.text,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.w500,
            color: AppColors.getTextPrimaryColor(Get.context!),
          ),
        ),
        const SizedBox(height: 8),
        TextField(
          controller: controller,
          keyboardType: keyboardType,
          style: TextStyle(color: AppColors.getTextPrimaryColor(Get.context!)),
          decoration: InputDecoration(
            hintText: hint,
            hintStyle: TextStyle(
              color: AppColors.getTextSecondaryColor(Get.context!),
              fontSize: 14,
            ),
            prefixIcon: Icon(
              icon,
              color: AppColors.getTextSecondaryColor(Get.context!),
              size: 20,
            ),
            filled: true,
            fillColor: AppColors.getGreyColor(Get.context!),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(
                color: AppColors.getBorderColor(Get.context!),
              ),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(
                color: AppColors.getBorderColor(Get.context!),
              ),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: const BorderSide(color: Color(0xFFD32F2F)),
            ),
            contentPadding: const EdgeInsets.symmetric(
              horizontal: 16,
              vertical: 14,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildReadOnlyField({
    required String label,
    required String value,
    required IconData icon,
    String? helperText,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.w500,
            color: AppColors.getTextPrimaryColor(Get.context!),
          ),
        ),
        const SizedBox(height: 8),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          decoration: BoxDecoration(
            color: AppColors.getGreyColor(Get.context!),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: AppColors.getBorderColor(Get.context!)),
          ),
          child: Row(
            children: [
              Icon(
                icon,
                color: AppColors.getTextSecondaryColor(Get.context!),
                size: 20,
              ),
              const SizedBox(width: 12),
              Text(
                value,
                style: TextStyle(
                  fontSize: 14,
                  color: AppColors.getTextSecondaryColor(Get.context!),
                ),
              ),
              const Spacer(),
              Icon(
                Icons.lock_outline,
                size: 16,
                color: AppColors.getTextSecondaryColor(Get.context!),
              ),
            ],
          ),
        ),
        if (helperText != null)
          Padding(
            padding: const EdgeInsets.only(top: 4, left: 4),
            child: Text(
              helperText,
              style: TextStyle(
                fontSize: 11,
                color: AppColors.getTextSecondaryColor(Get.context!),
              ),
            ),
          ),
      ],
    );
  }

  Widget _buildPasswordField({
    required TextEditingController controller,
    required String label,
    required bool isVisible,
    required VoidCallback onToggle,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.w500,
            color: AppColors.getTextPrimaryColor(Get.context!),
          ),
        ),
        const SizedBox(height: 8),
        TextField(
          controller: controller,
          obscureText: !isVisible,
          style: TextStyle(color: AppColors.getTextPrimaryColor(Get.context!)),
          decoration: InputDecoration(
            prefixIcon: Icon(
              Icons.lock_outline,
              color: AppColors.getTextSecondaryColor(Get.context!),
              size: 20,
            ),
            suffixIcon: GestureDetector(
              onTap: onToggle,
              child: Icon(
                isVisible ? Icons.visibility : Icons.visibility_off,
                color: AppColors.getTextSecondaryColor(Get.context!),
                size: 20,
              ),
            ),
            filled: true,
            fillColor: AppColors.getGreyColor(Get.context!),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(
                color: AppColors.getBorderColor(Get.context!),
              ),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(
                color: AppColors.getBorderColor(Get.context!),
              ),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: const BorderSide(color: Color(0xFFD32F2F)),
            ),
            contentPadding: const EdgeInsets.symmetric(
              horizontal: 16,
              vertical: 14,
            ),
          ),
        ),
      ],
    );
  }
}
