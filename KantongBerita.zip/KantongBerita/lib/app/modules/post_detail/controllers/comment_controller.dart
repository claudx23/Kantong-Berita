import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../data/models/comment_model.dart';
import '../../../data/models/post_model.dart';
import '../../../data/providers/auth_provider.dart';
import '../../../routes/app_routes.dart';
import '../../../services/comment_moderation_service.dart';
import '../../../utils/string_helper.dart';

class CommentController extends GetxController {
  final AuthProvider authProvider = Get.find<AuthProvider>();
  final TextEditingController commentController = TextEditingController();
  final FocusNode commentFocusNode = FocusNode();
  final ScrollController scrollController = ScrollController();
  final moderation = Get.find<CommentModerationService>();

  final comments = <CommentModel>[].obs;
  final isLoading = false.obs;
  final isSubmitting = false.obs;
  final isLoadingMore = false.obs;
  final hasMore = true.obs;
  final currentPage = 1.obs;
  final totalComments = 0.obs;

  // Untuk reply
  final replyingTo = Rx<CommentModel?>(null);
  final replyingToName = ''.obs;

  late int postId;

  @override
  void onInit() {
    super.onInit();
    // Handle both PostModel and Map arguments
    if (Get.arguments is PostModel) {
      postId = (Get.arguments as PostModel).id;
    } else if (Get.arguments is Map) {
      postId = Get.arguments['postId'] ?? 0;
    }
    if (postId > 0) loadComments();
  }

  @override
  void onClose() {
    commentController.dispose();
    commentFocusNode.dispose();
    scrollController.dispose();
    super.onClose();
  }

  // ==================== LOAD COMMENTS ====================

  Future<void> loadComments() async {
    try {
      isLoading.value = true;
      currentPage.value = 1;

      final response = await authProvider.getComments(postId, page: 1);

      if (response.statusCode == 200 && response.body['success'] == true) {
        final List<dynamic> data = response.body['comments'];
        comments.value = data.map((c) => CommentModel.fromJson(c)).toList();
        totalComments.value = response.body['total'] ?? 0;
        hasMore.value = (response.body['current_page'] ?? 1)(
          response.body['total_pages'] ?? 1,
        );
      }

      isLoading.value = false;
    } catch (e) {
      isLoading.value = false;
      // print('Error loading comments: $e');
    }
  }

  Future<void> loadMoreComments() async {
    try {
      isLoadingMore.value = true;
      currentPage.value++;

      final response = await authProvider.getComments(
        postId,
        page: currentPage.value,
      );

      if (response.statusCode == 200 && response.body['success'] == true) {
        final List<dynamic> data = response.body['comments'];
        comments.addAll(data.map((c) => CommentModel.fromJson(c)));
        hasMore.value = currentPage.value < (response.body['total_pages'] ?? 1);
      }

      isLoadingMore.value = false;
    } catch (e) {
      isLoadingMore.value = false;
      currentPage.value--;
    }
  }

  Future<void> refreshComments() async => await loadComments();

  // ==================== SUBMIT COMMENT ====================

  Future<void> submitComment() async {
    // Cek login
    if (!authProvider.isLoggedIn()) {
      Get.snackbar(
        'Login Diperlukan',
        'Silakan login untuk berkomentar',
        snackPosition: SnackPosition.TOP,
        backgroundColor: const Color(0xFFD32F2F),
        colorText: Colors.white,
        mainButton: TextButton(
          onPressed: () => Get.toNamed(AppRoutes.login),
          child: const Text('Login', style: TextStyle(color: Colors.white)),
        ),
      );
      return;
    }

    final content = commentController.text.trim();

    if (content.isEmpty) {
      Get.snackbar(
        'Error',
        'Komentar tidak boleh kosong',
        snackPosition: SnackPosition.TOP,
        backgroundColor: Colors.red,
        colorText: Colors.white,
      );
      return;
    }

    if (content.length < 3) {
      Get.snackbar(
        'Error',
        'Komentar terlalu pendek',
        snackPosition: SnackPosition.TOP,
        backgroundColor: Colors.red,
        colorText: Colors.white,
      );
      return;
    }

    // ===================== COOLDOWN =====================

    if (moderation.isCooldownActive()) {
      final remain = moderation.remainingCooldown();

      Get.snackbar(
        "Komentar Dibatasi",
        "Anda dapat berkomentar lagi dalam ${remain.inHours} jam",
        snackPosition: SnackPosition.TOP,
        backgroundColor: Colors.orange,
        colorText: Colors.white,
      );

      return;
    }

    // ===================== RATE LIMIT =====================

    if (moderation.isRateLimited()) {
      Get.snackbar(
        "Tunggu Sebentar",
        "Silakan tunggu ${moderation.remainingRateLimit()} detik",
        snackPosition: SnackPosition.TOP,
        backgroundColor: Colors.orange,
        colorText: Colors.white,
      );

      return;
    }

    // ===================== BANNED WORD =====================

    if (moderation.containsBannedWord(content)) {
      Get.snackbar(
        "Komentar Ditolak",
        "Komentar mengandung kata yang tidak diperbolehkan.",
        snackPosition: SnackPosition.TOP,
        backgroundColor: Colors.red,
        colorText: Colors.white,
      );

      return;
    }

    // ===================== LINK =====================

    if (moderation.containsSpamLink(content)) {
      Get.snackbar(
        "Komentar Ditolak",
        "Tautan tidak diperbolehkan pada komentar.",
        snackPosition: SnackPosition.TOP,
        backgroundColor: Colors.red,
        colorText: Colors.white,
      );

      return;
    }

    // ===================== REPEATED =====================

    if (moderation.containsRepeatedCharacters(content)) {
      Get.snackbar(
        "Komentar Ditolak",
        "Komentar terdeteksi sebagai spam.",
        snackPosition: SnackPosition.TOP,
        backgroundColor: Colors.red,
        colorText: Colors.white,
      );

      return;
    }

    // ===================== DUPLICATE =====================

    if (moderation.checkDuplicateSpam(content)) {
      Get.snackbar(
        "Komentar Dibatasi",
        "Anda mengirim komentar yang sama sebanyak 3 kali.\nKomentar dinonaktifkan selama 24 jam.",
        snackPosition: SnackPosition.TOP,
        backgroundColor: Colors.red,
        colorText: Colors.white,
        duration: const Duration(seconds: 4),
      );

      return;
    }

    try {
      isSubmitting.value = true;

      final response = await authProvider.addComment(
        postId: postId,
        content: content,
        parent: replyingTo.value?.id ?? 0,
      );

      if (response.statusCode == 200 && response.body['success'] == true) {
        moderation.onCommentSuccess();

        final newComment = CommentModel.fromJson(response.body['comment']);

        if (replyingTo.value != null) {
          // Tambahkan reply ke komentar induk
          final parentIndex = comments.indexWhere(
            (c) => c.id == replyingTo.value!.id,
          );

          if (parentIndex != -1) {
            final parent = comments[parentIndex];
            final updatedReplies = [...parent.replies, newComment];
            comments[parentIndex] = CommentModel(
              id: parent.id,
              author: parent.author,
              avatar: parent.avatar,
              content: parent.content,
              date: parent.date,
              userId: parent.userId,
              parent: parent.parent,
              replyCount: parent.replyCount + 1,
              replies: updatedReplies,
            );
          }
          cancelReply();
        } else {
          // Tambahkan komentar baru di atas
          comments.insert(0, newComment);
        }

        totalComments.value++;
        commentController.clear();
        commentFocusNode.unfocus();
      } else {
        Get.snackbar(
          'Error',
          response.body['message'] ?? 'Gagal mengirim komentar',
          snackPosition: SnackPosition.TOP,
          backgroundColor: Colors.red,
          colorText: Colors.white,
        );
      }
    } catch (e) {
      Get.snackbar(
        'Error',
        'Terjadi kesalahan: $e',
        snackPosition: SnackPosition.TOP,
        backgroundColor: Colors.red,
        colorText: Colors.white,
      );
    } finally {
      isSubmitting.value = false;
    }
  }

  // ==================== DELETE COMMENT ====================

  void confirmDelete(int commentId, {int? parentId}) {
    Get.dialog(
      AlertDialog(
        title: const Text('Hapus Komentar'),
        content: const Text('Apakah Anda yakin ingin menghapus komentar ini?'),
        actions: [
          TextButton(onPressed: () => Get.back(), child: const Text('Batal')),
          ElevatedButton(
            onPressed: () {
              Get.back();
              deleteComment(commentId, parentId: parentId);
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFFD32F2F),
            ),
            child: const Text('Hapus', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }

  Future<void> deleteComment(int commentId, {int? parentId}) async {
    try {
      final response = await authProvider.deleteComment(commentId);

      if (response.statusCode == 200 && response.body['success'] == true) {
        if (parentId != null) {
          // Hapus reply dari komentar induk
          final parentIndex = comments.indexWhere((c) => c.id == parentId);
          if (parentIndex != -1) {
            final parent = comments[parentIndex];
            final updatedReplies = parent.replies
                .where((r) => r.id != commentId)
                .toList();
            comments[parentIndex] = CommentModel(
              id: parent.id,
              author: parent.author,
              avatar: parent.avatar,
              content: parent.content,
              date: parent.date,
              userId: parent.userId,
              parent: parent.parent,
              replyCount: parent.replyCount - 1,
              replies: updatedReplies,
            );
          }
        } else {
          // Hapus komentar utama
          comments.removeWhere((c) => c.id == commentId);
        }

        totalComments.value--;

        // Get.snackbar(
        //   'Berhasil',
        //   'Komentar berhasil dihapus',
        //   snackPosition: SnackPosition.TOP,
        //   backgroundColor: Colors.green,
        //   colorText: Colors.white,
        // );
      } else {
        Get.snackbar(
          'Error',
          response.body['message'] ?? 'Gagal menghapus komentar',
          snackPosition: SnackPosition.TOP,
          backgroundColor: Colors.red,
          colorText: Colors.white,
        );
      }
    } catch (e) {
      Get.snackbar(
        'Error',
        'Terjadi kesalahan: $e',
        snackPosition: SnackPosition.TOP,
        backgroundColor: Colors.red,
        colorText: Colors.white,
      );
    }
  }

  // ==================== REPLY ====================

  void setReply(CommentModel comment) {
    replyingTo.value = comment;
    replyingToName.value = comment.author;
    commentFocusNode.requestFocus();
  }

  void cancelReply() {
    replyingTo.value = null;
    replyingToName.value = '';
  }

  // ==================== HELPERS ====================

  bool isMyComment(int commentUserId) {
    final user = authProvider.getUser();
    return user != null && user.id == commentUserId;
  }

  String getTimeAgo(String date) => StringHelper.timeAgo(date);
}
