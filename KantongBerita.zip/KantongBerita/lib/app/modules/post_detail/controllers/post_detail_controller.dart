import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:kantongberita/app/data/models/bookmark_model.dart';
import 'package:kantongberita/app/modules/post_detail/controllers/comment_controller.dart';
import '../../../data/models/post_model.dart';
import '../../../data/providers/api_provider.dart';
import '../../../data/providers/auth_provider.dart';
import '../../../routes/app_routes.dart';
import '../../../services/post_cache_service.dart';
import '../../../utils/string_helper.dart';
import '../../bookmark/controllers/bookmark_controller.dart';
import '../../../services/reading_tracker_service.dart';
import '../../../services/app_refresh_service.dart';
import '../../../services/notification_service.dart';

class PostDetailController extends GetxController {
  final ApiProvider apiProvider = Get.find<ApiProvider>();
  final AuthProvider authProvider = Get.find<AuthProvider>();
  final BookmarkController bookmarkCtrl = Get.find<BookmarkController>();

  // Scroll controller untuk tracking 60%
  final ScrollController scrollController = ScrollController();

  final PostCacheService _postCache = Get.find<PostCacheService>();

  final post = Rx<PostModel?>(null);
  final relatedPosts = <PostModel>[].obs;
  final isBookmarked = false.obs;
  final isBookmarkLoading = false.obs;

  // Tracking flags
  bool _hasTracked = false; // Sudah track artikel ini belum
  bool _hasAutoApplied = false; // Sudah auto-apply suggestion belum (per sesi)

  @override
  void onInit() {
    super.onInit();

    final args = Get.arguments;
    if (args is PostModel) {
      post.value = args;
      _postCache.cachePost(args);
      loadRelatedPosts();
      checkBookmarkStatus();

      Future.microtask(() {
        final commentCtrl = Get.find<CommentController>();
        commentCtrl.postId = args.id;
        commentCtrl.loadComments();
      });
    }

    _setupScrollTracking();
  }

  @override
  void onClose() {
    scrollController.dispose();
    super.onClose();
  }

  // ==================== SCROLL TRACKING ====================

  void _setupScrollTracking() {
    if (!authProvider.isLoggedIn()) return;
    if (post.value == null) return;

    scrollController.addListener(_onScroll);
  }

  void _onScroll() {
    if (_hasTracked) return;
    if (!scrollController.hasClients) return;

    final maxExtent = scrollController.position.maxScrollExtent;
    if (maxExtent <= 0) return;

    final currentOffset = scrollController.offset;
    final scrollPercent = currentOffset / maxExtent;

    // ✅ Track saat scroll mencapai 60%
    if (scrollPercent >= 0.6) {
      _hasTracked = true; // Pastikan hanya sekali
      scrollController.removeListener(_onScroll);

      _trackReading();
    }
  }

  // ==================== TRACK READING ====================

  void _trackReading() {
    final currentPost = post.value;
    if (currentPost == null) return;
    if (!authProvider.isLoggedIn()) return;

    final userId = authProvider.getUserId();
    final tracker = Get.find<ReadingTrackerService>();

    // ✅ Track — return null jika belum threshold, return CategoryReadCount
    // jika sudah mencapai 5 kali baca kategori ini
    final reached = tracker.trackRead(
      categoryId: currentPost.categoryId,
      categoryName: currentPost.categoryName,
      postId: currentPost.id,
      userId: userId,
    );

    // Belum mencapai threshold → tidak perlu update preferensi
    if (reached == null) return;

    // ✅ Cek & update preferensi secara silent
    _autoUpdatePreferences(reached, userId);
  }

  // ==================== AUTO-APPLY PREFERENCES (SILENT) ====================
  Future<void> _autoUpdatePreferences(
    CategoryReadCount reached,
    String userId,
  ) async {
    if (_hasAutoApplied) return;

    try {
      final response = await authProvider.getPreferences();
      if (response.statusCode != 200) return;

      final prefs = response.body['preferences'];
      final currentUmum = List<int>.from(prefs['preferred_categories'] ?? []);
      final currentLokal = List<int>.from(prefs['preferred_locations'] ?? []);

      final tracker = Get.find<ReadingTrackerService>();

      // ✅ Hitung update yang perlu dilakukan
      final result = tracker.computePreferenceUpdate(
        newCategory: reached,
        currentUmum: currentUmum,
        currentLokal: currentLokal,
        userId: userId,
      );

      if (result == null) return;

      _hasAutoApplied = true;

      // Simpan ke server
      final saveResponse = await authProvider.updatePreferences(
        preferredCategories: result.finalUmum,
        preferredLocations: result.finalLokal,
      );

      if (saveResponse.statusCode == 200 &&
          saveResponse.body['success'] == true) {
        // Update FCM subscriptions
        NotificationService.updateSubscriptions([
          ...result.finalUmum,
          ...result.finalLokal,
        ]);

        // Kurangi count kategori yang sudah di-apply
        tracker.onPreferencesApplied(
          addedCategoryIds: result.added,
          userId: userId,
        );

        // Refresh home
        if (Get.isRegistered<AppRefreshService>()) {
          Get.find<AppRefreshService>().triggerPreferencesChanged();
        }
      }
    } catch (e) {
      // print('update failed: $e');
    }
  }

  // ==================== BOOKMARK ====================

  Future<void> checkBookmarkStatus() async {
    if (!authProvider.isLoggedIn()) return;
    if (post.value == null) return;

    try {
      final response = await authProvider.checkBookmark(post.value!.id);
      if (response.statusCode == 200 && response.body['success'] == true) {
        isBookmarked.value = response.body['is_bookmarked'] ?? false;
      }
    } catch (e) {
      // print('Error check bookmark: $e');
    }
  }

  Future<void> toggleBookmark() async {
    if (!authProvider.isLoggedIn()) {
      Get.snackbar(
        'Login Diperlukan',
        'Silakan login untuk menyimpan bookmark',
        snackPosition: SnackPosition.TOP,
        backgroundColor: const Color(0xFFD32F2F),
        colorText: Colors.white,
        mainButton: TextButton(
          onPressed: () => Get.toNamed(AppRoutes.login),
          child: const Text('Login', style: TextStyle(color: Colors.white)),
        ),
      );
      return;
    }

    if (post.value == null) return;

    try {
      isBookmarkLoading.value = true;

      final response = await authProvider.toggleBookmark(post.value!.id);

      if (response.statusCode == 200 && response.body['success'] == true) {
        isBookmarked.value = response.body['is_bookmarked'] ?? false;
        bookmarkCtrl.syncToggle(
          postId: post.value!.id,
          isNowBookmarked: isBookmarked.value,
          bookmark: BookmarkModel(
            id: post.value!.id,
            title: post.value!.title,
            excerpt: post.value!.excerpt,
            featuredImage: post.value!.featuredImage,
            date: post.value!.date,
            categoryName: post.value!.categoryName,
            link: post.value!.link,
          ),
        );

        Get.snackbar(
          'Berhasil',
          response.body['message'] ?? '',
          snackPosition: SnackPosition.TOP,
          backgroundColor: Colors.green,
          colorText: Colors.white,
          duration: const Duration(seconds: 2),
        );

        bookmarkCtrl.refreshBookmarks();
      }
    } catch (e) {
      Get.snackbar(
        'Error',
        'Gagal mengubah bookmark',
        snackPosition: SnackPosition.TOP,
        backgroundColor: Colors.red,
        colorText: Colors.white,
      );
    } finally {
      isBookmarkLoading.value = false;
    }
  }

  // ==================== RELATED POSTS ====================

  Future<void> loadRelatedPosts() async {
    try {
      if (post.value == null || post.value!.categories.isEmpty) return;

      final List<PostModel> posts = await apiProvider.fetchPostsByCategory(
        categoryId: post.value!.categories.first,
        perPage: 5,
      );

      relatedPosts.value = posts
          .where((p) => p.id != post.value!.id)
          .take(4)
          .toList();
    } catch (e) {
      // print('Error loading related posts: $e');
    }
  }

  // ==================== HELPERS ====================

  String getTimeAgo(String date) => StringHelper.timeAgo(date);
  String formatDate(String date) => StringHelper.formatDate(date);
  String stripHtml(String html) => StringHelper.stripHtml(html);
}
