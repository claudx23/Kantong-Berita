import 'package:get/get.dart';
import '../../../data/providers/api_provider.dart';
import '../../../data/providers/auth_provider.dart';
import '../controllers/comment_controller.dart';
import '../controllers/post_detail_controller.dart';

class PostDetailBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<ApiProvider>(() => ApiProvider());
    Get.lazyPut<AuthProvider>(() => AuthProvider());
    Get.lazyPut<PostDetailController>(() => PostDetailController());
    Get.lazyPut<CommentController>(() => CommentController());
  }
}