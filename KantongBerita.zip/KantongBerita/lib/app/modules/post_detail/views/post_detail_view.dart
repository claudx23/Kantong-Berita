import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter_html/flutter_html.dart';
import 'package:get/get.dart';
import 'package:kantongberita/app/modules/post_detail/bindings/post_detail_binding.dart';
import 'package:kantongberita/app/utils/share_helper.dart';
import '../../../data/models/post_model.dart';
import '../controllers/post_detail_controller.dart';
import '../controllers/comment_controller.dart';
import '../../../widgets/comment_card.dart';
import '../../../utils/app_colors.dart';

class PostDetailView extends StatelessWidget {
  const PostDetailView({super.key});

  @override
  Widget build(BuildContext context) {
    final postController = Get.find<PostDetailController>();
    final commentController = Get.find<CommentController>();

    return Obx(() {
      if (postController.post.value == null) {
        return const Scaffold(
          body: Center(
            child: CircularProgressIndicator(color: Color(0xFFD32F2F)),
          ),
        );
      }

      final post = postController.post.value!;

      return Scaffold(
        backgroundColor: AppColors.getBackgroundColor(context),
        body: CustomScrollView(
          controller: postController.scrollController,
          slivers: [
            // App Bar
            _buildSliverAppBar(post, postController),

            SliverToBoxAdapter(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Post Header
                  _buildPostHeader(post, postController),

                  // HTML Content
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 8),
                    child: Html(
                      data: post.content,
                      style: {
                        'body': Style(
                          fontSize: FontSize(15),
                          lineHeight: const LineHeight(1.7),
                          color: AppColors.getTextPrimaryColor(context),
                          margin: Margins.zero,
                          padding: HtmlPaddings.zero,
                        ),
                        'p': Style(margin: Margins.only(bottom: 12)),
                        'img': Style(
                          width: Width.auto(),
                          margin: Margins.only(bottom: 12, top: 4),
                        ),
                        'a': Style(
                          color: const Color(0xFFD32F2F),
                          textDecoration: TextDecoration.none,
                        ),
                        'blockquote': Style(
                          backgroundColor: const Color(
                            0xFFD32F2F,
                          ).withValues(alpha: 0.1),
                          padding: HtmlPaddings.all(12),
                          margin: Margins.only(bottom: 12, left: 0, right: 0),
                          border: const Border(
                            left: BorderSide(
                              color: Color(0xFFD32F2F),
                              width: 4,
                            ),
                          ),
                        ),
                      },
                    ),
                  ),

                  const SizedBox(height: 24),
                  Divider(
                    thickness: 8,
                    color: AppColors.getBorderColor(context),
                  ),

                  // Related Posts
                  _buildRelatedPosts(postController),

                  Divider(
                    thickness: 8,
                    color: AppColors.getBorderColor(context),
                  ),

                  // Comments Section
                  _buildCommentsSection(commentController),

                  const SizedBox(height: 80), // Space for input
                ],
              ),
            ),
          ],
        ),

        // Comment Input
        //jika user belum login, maka input komentar tidak akan tampil
        bottomSheet: postController.authProvider.isLoggedIn()
            ? _buildCommentInput(commentController)
            : null,
      );
    });
  }

  // ==================== SLIVER APPBAR ====================

  Widget _buildSliverAppBar(PostModel post, PostDetailController ctrl) {
    return SliverAppBar(
      expandedHeight: post.featuredImage.isNotEmpty ? 280 : 0,
      pinned: true,
      backgroundColor: AppColors.getCardColor(Get.context!),
      foregroundColor: AppColors.getTextPrimaryColor(Get.context!),
      leading: GestureDetector(
        onTap: () => Get.back(),
        child: Container(
          margin: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: AppColors.getCardColor(Get.context!),
            shape: BoxShape.circle,
            boxShadow: [
              BoxShadow(
                color: AppColors.getTextPrimaryColor(
                  Get.context!,
                ).withValues(alpha: 0.1),
                blurRadius: 8,
              ),
            ],
          ),
          child: Icon(
            Icons.arrow_back,
            color: AppColors.getTextPrimaryColor(Get.context!),
            size: 20,
          ),
        ),
      ),
      actions: [
        // Share
        GestureDetector(
          onTap: () {
            final post = ctrl.post.value;
            if (post != null) {
              ShareHelper.showShareBottomSheet(
                title: post.title,
                link: post.link.isNotEmpty
                    ? post.link
                    : 'https://kantongberita.com/?p=${post.id}',
              );
            }
          },
          child: Container(
            margin: const EdgeInsets.all(8),
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: AppColors.getCardColor(Get.context!),
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
                  color: AppColors.getTextPrimaryColor(
                    Get.context!,
                  ).withValues(alpha: 0.1),
                  blurRadius: 8,
                ),
              ],
            ),
            child: Icon(
              Icons.share_outlined,
              color: AppColors.getTextPrimaryColor(Get.context!),
              size: 20,
            ),
          ),
        ),

        // Bookmark
        Obx(
          () => GestureDetector(
            onTap: ctrl.toggleBookmark,
            child: Container(
              margin: const EdgeInsets.only(right: 8, top: 8, bottom: 8),
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: AppColors.getCardColor(Get.context!),
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: AppColors.getTextPrimaryColor(
                      Get.context!,
                    ).withValues(alpha: 0.1),
                    blurRadius: 8,
                  ),
                ],
              ),
              child: ctrl.isBookmarkLoading.value
                  ? const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        color: Color(0xFFD32F2F),
                      ),
                    )
                  : Icon(
                      ctrl.isBookmarked.value
                          ? Icons.bookmark
                          : Icons.bookmark_outline,
                      color: ctrl.isBookmarked.value
                          ? const Color(0xFFD32F2F)
                          : AppColors.getTextPrimaryColor(Get.context!),
                      size: 20,
                    ),
            ),
          ),
        ),
      ],
      flexibleSpace: post.featuredImage.isNotEmpty
          ? FlexibleSpaceBar(
              background: CachedNetworkImage(
                imageUrl: post.featuredImage,
                fit: BoxFit.cover,
                placeholder: (context, url) =>
                    Container(color: Colors.grey[300]),
                errorWidget: (context, url, error) =>
                    Container(color: Colors.grey[200]),
              ),
            )
          : null,
    );
  }

  // ==================== POST HEADER ====================

  Widget _buildPostHeader(PostModel post, PostDetailController ctrl) {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (post.categoryName.isNotEmpty)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: const Color(0xFFD32F2F),
                borderRadius: BorderRadius.circular(4),
              ),
              child: Text(
                post.categoryName,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 11,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          const SizedBox(height: 12),
          Text(
            post.title,
            style: TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.bold,
              color: AppColors.getTextPrimaryColor(Get.context!),
              height: 1.3,
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              const Icon(
                Icons.calendar_today_outlined,
                size: 14,
                color: Colors.grey,
              ),
              const SizedBox(width: 4),
              Text(
                ctrl.formatDate(post.date),
                style: TextStyle(color: Colors.grey[600], fontSize: 13),
              ),
              const SizedBox(width: 12),
              const Icon(Icons.access_time, size: 14, color: Colors.grey),
              const SizedBox(width: 4),
              Text(
                ctrl.getTimeAgo(post.date),
                style: TextStyle(color: Colors.grey[600], fontSize: 13),
              ),
            ],
          ),
          const SizedBox(height: 16),
          const Divider(),
        ],
      ),
    );
  }

  // ==================== RELATED POSTS ====================

  Widget _buildRelatedPosts(PostDetailController ctrl) {
    return Obx(() {
      if (ctrl.relatedPosts.isEmpty) return const SizedBox.shrink();

      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: EdgeInsets.fromLTRB(16, 16, 16, 12),
            child: Text(
              'Berita Terkait',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: AppColors.getTextPrimaryColor(Get.context!),
              ),
            ),
          ),
          ListView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: ctrl.relatedPosts.length,
            itemBuilder: (context, index) {
              final related = ctrl.relatedPosts[index];
              return GestureDetector(
                onTap: () {
                  Get.off(
                    () => const PostDetailView(),
                    binding: PostDetailBinding(),
                    arguments: related,
                  );
                },
                child: Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 16,
                    vertical: 10,
                  ),
                  child: Row(
                    children: [
                      ClipRRect(
                        borderRadius: BorderRadius.circular(8),
                        child: CachedNetworkImage(
                          imageUrl: related.featuredImage,
                          width: 80,
                          height: 80,
                          fit: BoxFit.cover,
                          placeholder: (context, url) =>
                              Container(color: Colors.grey[300]),
                          errorWidget: (context, url, error) =>
                              Container(color: Colors.grey[200]),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          related.title,
                          style: TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.w600,
                            color: AppColors.getTextPrimaryColor(Get.context!),
                          ),
                          maxLines: 3,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
          const SizedBox(height: 8),
        ],
      );
    });
  }

  // ==================== COMMENTS SECTION ====================

  Widget _buildCommentsSection(CommentController ctrl) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Header
        Obx(
          () => Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 12),
            child: Row(
              children: [
                Text(
                  'Komentar',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: AppColors.getTextPrimaryColor(Get.context!),
                  ),
                ),
                const SizedBox(width: 8),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 8,
                    vertical: 2,
                  ),
                  decoration: BoxDecoration(
                    color: const Color(0xFFD32F2F),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    '${ctrl.totalComments.value}',
                    style: TextStyle(
                      color: AppColors.getTextPrimaryColor(Get.context!),
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),

        // Loading
        Obx(() {
          if (ctrl.isLoading.value) {
            return const Padding(
              padding: EdgeInsets.all(32),
              child: Center(
                child: CircularProgressIndicator(color: Color(0xFFD32F2F)),
              ),
            );
          }

          // Empty
          if (ctrl.comments.isEmpty) {
            return Padding(
              padding: const EdgeInsets.all(32),
              child: Center(
                child: Column(
                  children: [
                    Icon(
                      Icons.chat_bubble_outline,
                      size: 48,
                      color: AppColors.getTextSecondaryColor(Get.context!),
                    ),
                    const SizedBox(height: 12),
                    Text(
                      'Belum ada komentar',
                      style: TextStyle(color: AppColors.getTextSecondaryColor(Get.context!)),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'Jadilah yang pertama berkomentar!',
                      style: TextStyle(color: AppColors.getTextSecondaryColor(Get.context!), fontSize: 12),
                    ),
                  ],
                ),
              ),
            );
          }

          // Comment List
          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Column(
              children: [
                ListView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: ctrl.comments.length,
                  itemBuilder: (context, index) {
                    return CommentCard(comment: ctrl.comments[index]);
                  },
                ),

                // Load More
                if (ctrl.hasMore.value)
                  ctrl.isLoadingMore.value
                      ? const Padding(
                          padding: EdgeInsets.all(16),
                          child: CircularProgressIndicator(
                            color: Color(0xFFD32F2F),
                          ),
                        )
                      : TextButton(
                          onPressed: ctrl.loadMoreComments,
                          child: const Text(
                            'Lihat komentar lainnya',
                            style: TextStyle(color: Color(0xFFD32F2F)),
                          ),
                        ),
              ],
            ),
          );
        }),
      ],
    );
  }

  // ==================== COMMENT INPUT ====================

  Widget _buildCommentInput(CommentController ctrl) {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.getCardColor(Get.context!),
        boxShadow: [
          BoxShadow(
            color: AppColors.getTextPrimaryColor(Get.context!).withValues(alpha: 0.1),
            blurRadius: 10,
            offset: const Offset(0, -5),
          ),
        ],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Reply indicator
          Obx(() {
            if (ctrl.replyingTo.value == null) return const SizedBox.shrink();
            return Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              color: AppColors.getGreyColor(Get.context!),
              child: Row(
                children: [
                  const Icon(Icons.reply, size: 16, color: Color(0xFFD32F2F)),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'Membalas ${ctrl.replyingToName.value}',
                      style: const TextStyle(
                        fontSize: 12,
                        color: Color(0xFFD32F2F),
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                  GestureDetector(
                    onTap: ctrl.cancelReply,
                    child: const Icon(
                      Icons.close,
                      size: 16,
                      color: Colors.grey,
                    ),
                  ),
                ],
              ),
            );
          }),

          // Input Row
          Padding(
            padding: EdgeInsets.only(
              left: 16,
              right: 16,
              top: 8,
              bottom: MediaQuery.of(Get.context!).viewInsets.bottom + 8,
            ),
            child: Row(
              children: [
                // Text Field
                Expanded(
                  child: Container(
                    decoration: BoxDecoration(
                      color: AppColors.getGreyColor(Get.context!),
                      borderRadius: BorderRadius.circular(24),
                    ),
                    child: TextField(
                      controller: ctrl.commentController,
                      focusNode: ctrl.commentFocusNode,
                      maxLines: null,
                      textCapitalization: TextCapitalization.sentences,
                      decoration: const InputDecoration(
                        hintText: 'Tulis komentar...',
                        hintStyle: TextStyle(color: Colors.grey, fontSize: 14),
                        border: InputBorder.none,
                        contentPadding: EdgeInsets.symmetric(
                          horizontal: 16,
                          vertical: 10,
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 8),

                // Send Button
                Obx(
                  () => GestureDetector(
                    onTap: ctrl.isSubmitting.value ? null : ctrl.submitComment,
                    child: Container(
                      width: 44,
                      height: 44,
                      decoration: const BoxDecoration(
                        color: Color(0xFFD32F2F),
                        shape: BoxShape.circle,
                      ),
                      child: ctrl.isSubmitting.value
                          ? const Padding(
                              padding: EdgeInsets.all(10),
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                color: Colors.white,
                              ),
                            )
                          : const Icon(
                              Icons.send,
                              color: Colors.white,
                              size: 20,
                            ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
