import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'dart:async';
import '../../../data/models/post_model.dart';
import '../../../data/providers/api_provider.dart';
import '../../../utils/string_helper.dart';

class SearchNewsController extends GetxController {
  final ApiProvider apiProvider = Get.find<ApiProvider>();
  final TextEditingController searchTextController = TextEditingController();
  final ScrollController scrollController = ScrollController();

  // Observables
  final searchResults = <PostModel>[].obs;
  final isLoading = false.obs;
  final isSearching = false.obs;
  final currentPage = 1.obs;
  final hasMore = false.obs;
  final isLoadingMore = false.obs;
  final noResults = false.obs;
  final currentQuery = ''.obs;
  final hasSearchText = false.obs;

  // Debounce timer
  Timer? _searchDebounce;

  @override
  void onInit() {
    super.onInit();
    // Setup scroll listener untuk infinite scroll
    scrollController.addListener(_onScroll);
  }

  @override
  void onClose() {
    searchTextController.dispose();
    scrollController.dispose();
    _searchDebounce?.cancel();
    super.onClose();
  }

  // ==================== SEARCH FUNCTIONALITY ====================

  void onSearchTextChanged(String query) {
    hasSearchText.value = query.isNotEmpty;
    
    // Cancel previous debounce
    _searchDebounce?.cancel();
    
    if (query.trim().isEmpty) {
      searchResults.clear();
      noResults.value = false;
      currentQuery.value = '';
      isSearching.value = false;
      return;
    }

    // Set debounce untuk 300ms (lebih cepat)
    _searchDebounce = Timer(const Duration(milliseconds: 300), () {
      searchPosts(query);
    });
  }

  Future<void> searchPosts(String query) async {
    if (query.trim().isEmpty) {
      searchResults.clear();
      noResults.value = false;
      currentQuery.value = '';
      return;
    }

    try {
      isLoading.value = true;
      isSearching.value = true;
      noResults.value = false;
      currentPage.value = 1;
      currentQuery.value = query;

      final List<PostModel> posts = await apiProvider.searchPosts(
        query: query,
        page: 1,
        perPage: 10,
      );

      searchResults.value = posts;
      hasMore.value = posts.length >= 10;
      isLoading.value = false;

      if (posts.isEmpty) {
        noResults.value = true;
      }
    } catch (e) {
      isLoading.value = false;
      isSearching.value = false;
      Get.snackbar(
        'Error',
        'Gagal melakukan pencarian: $e',
        snackPosition: SnackPosition.TOP,
        backgroundColor: Colors.red,
        colorText: Colors.white,
      );
    }
  }

  Future<void> loadMoreSearchResults() async {
    if (currentQuery.value.isEmpty || isLoadingMore.value) return;

    try {
      isLoadingMore.value = true;
      currentPage.value++;

      final List<PostModel> newPosts = await apiProvider.searchPosts(
        query: currentQuery.value,
        page: currentPage.value,
        perPage: 10,
      );

      searchResults.addAll(newPosts);
      hasMore.value = newPosts.length >= 10;
      isLoadingMore.value = false;
    } catch (e) {
      isLoadingMore.value = false;
      currentPage.value--;
      Get.snackbar(
        'Error',
        'Gagal memuat hasil pencarian',
        snackPosition: SnackPosition.TOP,
        backgroundColor: Colors.red,
        colorText: Colors.white,
      );
    }
  }

  // ==================== SCROLL LISTENER ====================

  void _onScroll() {
    if (scrollController.position.pixels ==
        scrollController.position.maxScrollExtent) {
      if (hasMore.value && !isLoadingMore.value) {
        loadMoreSearchResults();
      }
    }
  }

  // ==================== HELPER ====================

  String getTimeAgo(String dateString) {
    return StringHelper.timeAgo(dateString);
  }

  void clearSearch() {
    searchTextController.clear();
    searchResults.clear();
    noResults.value = false;
    currentQuery.value = '';
    isSearching.value = false;
  }
}
