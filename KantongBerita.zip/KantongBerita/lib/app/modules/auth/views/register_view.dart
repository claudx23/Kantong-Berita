import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/auth_controller.dart';
import '../../../utils/app_colors.dart';

class RegisterView extends GetView<AuthController> {
  const RegisterView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.getBackgroundColor(context),
      appBar: AppBar(
        backgroundColor: Theme.of(context).appBarTheme.backgroundColor,
        elevation: 0,
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back,
            color: AppColors.getTextPrimaryColor(context),
          ),
          onPressed: () => Get.back(),
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 32),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const SizedBox(height: 4),

              // Logo
              Center(
                child: Column(
                  children: [
                    Image.asset('assets/images/logo.png', height: 80),
                    const SizedBox(height: 8),
                    Image.asset('assets/images/namalogo.png', height: 28),
                  ],
                ),
              ),

              const SizedBox(height: 28),

              // Title
              Text(
                'Buat Akun',
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  color: AppColors.getTextPrimaryColor(context),
                ),
              ),

              const SizedBox(height: 28),

              // ── Username ──
              Obx(
                () => _buildUnderlineField(
                  controller: controller.registerUsernameController,
                  hint: 'Username',
                  hasError:
                      controller.usernameTouched.value &&
                      controller.usernameError.value.isNotEmpty,
                  onChanged: controller.validateUsername,
                ),
              ),
              Obx(() {
                final show =
                    controller.usernameTouched.value &&
                    controller.usernameError.value.isNotEmpty;
                return show
                    ? _buildErrorText(controller.usernameError.value)
                    : const SizedBox(height: 16);
              }),

              // ── Email ──
              Obx(
                () => _buildUnderlineField(
                  controller: controller.registerEmailController,
                  hint: 'Email',
                  keyboardType: TextInputType.emailAddress,
                  hasError:
                      controller.emailTouched.value &&
                      controller.emailError.value.isNotEmpty,
                  onChanged: controller.validateEmail,
                ),
              ),
              Obx(() {
                final show =
                    controller.emailTouched.value &&
                    controller.emailError.value.isNotEmpty;
                return show
                    ? _buildErrorText(controller.emailError.value)
                    : const SizedBox(height: 16);
              }),

              // ── Password ──
              Obx(
                () => _buildUnderlinePasswordField(
                  controller: controller.registerPasswordController,
                  hint: 'Password',
                  isVisible: controller.isPasswordVisible.value,
                  onToggle: controller.togglePasswordVisibility,
                  hasError:
                      controller.passwordTouched.value &&
                      controller.passwordError.value.isNotEmpty,
                  onChanged: controller.onPasswordChanged,
                ),
              ),
              Obx(() {
                final show =
                    controller.passwordTouched.value &&
                    controller.passwordError.value.isNotEmpty;

                return show
                    ? _buildErrorText(controller.passwordError.value)
                    : const SizedBox(height: 4);
              }),

              const SizedBox(height: 16),

              // ── Confirm Password ──
              Obx(
                () => _buildUnderlinePasswordField(
                  controller: controller.registerConfirmPasswordController,
                  hint: 'Konfirmasi Password',
                  isVisible: controller.isConfirmPasswordVisible.value,
                  onToggle: controller.toggleConfirmPasswordVisibility,
                  hasError:
                      controller.confirmPasswordTouched.value &&
                      controller.confirmPasswordError.value.isNotEmpty,
                  onChanged: controller.validateConfirmPassword,
                ),
              ),
              Obx(() {
                final show =
                    controller.confirmPasswordTouched.value &&
                    controller.confirmPasswordError.value.isNotEmpty;

                return show
                    ? _buildErrorText(controller.confirmPasswordError.value)
                    : const SizedBox(height: 4);
              }),

              const SizedBox(height: 36),

              // ── Register Button ──
              Obx(
                () => SizedBox(
                  height: 52,
                  child: ElevatedButton(
                    onPressed: controller.isLoading.value
                        ? null
                        : controller.register,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFD32F2F),
                      foregroundColor: Colors.white,
                      elevation: 2,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                    child: controller.isLoading.value
                        ? const SizedBox(
                            width: 22,
                            height: 22,
                            child: CircularProgressIndicator(
                              color: Colors.white,
                              strokeWidth: 2,
                            ),
                          )
                        : const Text(
                            'Daftar',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 0.5,
                            ),
                          ),
                  ),
                ),
              ),

              const SizedBox(height: 20),

              // ── Sudah punya akun ──
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    'Sudah punya akun? ',
                    style: TextStyle(
                      color: AppColors.getTextSecondaryColor(context),
                      fontSize: 13,
                    ),
                  ),
                  GestureDetector(
                    onTap: () => Get.back(),
                    child: const Text(
                      'Masuk',
                      style: TextStyle(
                        color: Color(0xFFD32F2F),
                        fontSize: 13,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 32),
            ],
          ),
        ),
      ),
    );
  }

  // ──────────────────────────────────────────────
  Widget _buildErrorText(String message) {
    return Padding(
      padding: const EdgeInsets.only(top: 5, left: 2, bottom: 10),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Padding(
            padding: EdgeInsets.only(top: 1),
            child: Icon(Icons.info_outline, size: 13, color: Color(0xFFD32F2F)),
          ),
          const SizedBox(width: 4),
          Expanded(
            child: Text(
              message,
              softWrap: true,
              style: const TextStyle(
                color: Color(0xFFD32F2F),
                fontSize: 12,
                height: 1.3,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildUnderlineField({
    required TextEditingController controller,
    required String hint,
    TextInputType keyboardType = TextInputType.text,
    bool hasError = false,
    ValueChanged<String>? onChanged,
  }) {
    return TextField(
      controller: controller,
      keyboardType: keyboardType,
      style: TextStyle(
        fontSize: 15,
        color: AppColors.getTextPrimaryColor(Get.context!),
      ),
      onChanged: onChanged,
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: TextStyle(
          color: AppColors.getTextSecondaryColor(Get.context!),
          fontSize: 15,
        ),
        enabledBorder: UnderlineInputBorder(
          borderSide: BorderSide(
            color: hasError ? const Color(0xFFD32F2F) : Colors.black26,
            width: 1,
          ),
        ),
        focusedBorder: UnderlineInputBorder(
          borderSide: BorderSide(
            color: hasError ? const Color(0xFFD32F2F) : Colors.black54,
            width: 1.2,
          ),
        ),
        contentPadding: const EdgeInsets.symmetric(vertical: 12, horizontal: 5),
        isDense: true,
      ),
    );
  }

  Widget _buildUnderlinePasswordField({
    required TextEditingController controller,
    required String hint,
    required bool isVisible,
    required VoidCallback onToggle,
    bool hasError = false,
    ValueChanged<String>? onChanged,
  }) {
    return TextField(
      controller: controller,
      obscureText: !isVisible,
      style: TextStyle(
        fontSize: 15,
        color: AppColors.getTextPrimaryColor(Get.context!),
      ),
      onChanged: onChanged,
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: TextStyle(
          color: AppColors.getTextSecondaryColor(Get.context!),
          fontSize: 15,
        ),
        enabledBorder: UnderlineInputBorder(
          borderSide: BorderSide(
            color: hasError ? const Color(0xFFD32F2F) : Colors.black26,
            width: 1,
          ),
        ),
        focusedBorder: UnderlineInputBorder(
          borderSide: BorderSide(
            color: hasError ? const Color(0xFFD32F2F) : Colors.black54,
            width: 1.2,
          ),
        ),
        contentPadding: const EdgeInsets.symmetric(vertical: 12, horizontal: 5),
        isDense: true,
        suffixIcon: IconButton(
          icon: Icon(
            isVisible
                ? Icons.visibility_outlined
                : Icons.visibility_off_outlined,
            color: AppColors.getTextSecondaryColor(Get.context!),
            size: 20,
          ),
          onPressed: onToggle,
          padding: EdgeInsets.zero,
        ),
      ),
    );
  }
}
