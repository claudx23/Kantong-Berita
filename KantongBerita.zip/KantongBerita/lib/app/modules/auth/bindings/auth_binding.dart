import 'package:get/get.dart';
import 'package:kantongberita/app/modules/auth/controllers/auth_controller.dart';
import '../../../data/providers/auth_provider.dart';

class AuthBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<AuthProvider>(() => AuthProvider());
    Get.lazyPut<AuthController>(() => AuthController());
  }
}