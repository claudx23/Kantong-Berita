import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:kantongberita/app/modules/bookmark/controllers/bookmark_controller.dart';
import 'package:kantongberita/app/modules/home/controllers/home_controller.dart';
import 'package:kantongberita/app/services/reading_tracker_service.dart';
import '../../../data/models/user_model.dart';
import '../../../data/providers/auth_provider.dart';
import '../../../routes/app_routes.dart';
import '../../../services/notification_service.dart';
import '../../../services/social_auth_service.dart';

class AuthController extends GetxController {
  final AuthProvider authProvider = Get.put(AuthProvider());

  final SocialAuthService _socialAuth = SocialAuthService();

  // Form Controllers
  final TextEditingController loginUsernameController = TextEditingController();
  final TextEditingController loginPasswordController = TextEditingController();

  final TextEditingController registerUsernameController =
      TextEditingController();
  final TextEditingController registerEmailController = TextEditingController();
  final TextEditingController registerPasswordController =
      TextEditingController();
  final TextEditingController registerConfirmPasswordController =
      TextEditingController();

  // Observables
  final isLoading = false.obs;
  final isPasswordVisible = false.obs;
  final isConfirmPasswordVisible = false.obs;

  // Register field errors (hanya muncul setelah user pernah touch field)
  final passwordError = ''.obs;
  final usernameError = ''.obs;
  final emailError = ''.obs;
  final confirmPasswordError = ''.obs;

  // Track apakah field sudah pernah disentuh
  final usernameTouched = false.obs;
  final passwordTouched = false.obs;
  final emailTouched = false.obs;
  final confirmPasswordTouched = false.obs;

  @override
  void onClose() {
    loginUsernameController.dispose();
    loginPasswordController.dispose();
    registerUsernameController.dispose();
    registerEmailController.dispose();
    registerPasswordController.dispose();
    registerConfirmPasswordController.dispose();
    super.onClose();
  }

  // ==================== VALIDASI INLINE ====================

  void validateUsername(String value) {
    usernameTouched.value = true;
    if (value.isEmpty) {
      usernameError.value = 'Username tidak boleh kosong';
    } else if (value.length < 4) {
      usernameError.value = 'Username minimal 4 karakter';
    } else if (value.length > 16) {
      usernameError.value = 'Username maksimal 16 karakter';
    } else {
      usernameError.value = '';
    }
  }

  void validateEmail(String value) {
    emailTouched.value = true;

    if (value.isEmpty) {
      emailError.value = 'Email tidak boleh kosong';
      return;
    }

    final lower = value.toLowerCase();

    final gmailRegex = RegExp(r'^[a-zA-Z0-9._%+\-]+@gmail\.com$');
    final yahooRegex = RegExp(r'^[a-zA-Z0-9._%+\-]+@yahoo\.com$');
    final hotmailRegex = RegExp(r'^[a-zA-Z0-9._%+\-]+@hotmail\.com$');
    final outlookRegex = RegExp(r'^[a-zA-Z0-9._%+\-]+@outlook\.com$');
    final acIdRegex = RegExp(r'^[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.-]+\.ac\.id$');

    if (!gmailRegex.hasMatch(lower) &&
        !yahooRegex.hasMatch(lower) &&
        !hotmailRegex.hasMatch(lower) &&
        !outlookRegex.hasMatch(lower) &&
        !acIdRegex.hasMatch(lower)) {
      emailError.value = 'Gunakan email yang valid';
    } else {
      emailError.value = '';
    }
  }

  void validatePassword(String value) {
    passwordTouched.value = true;

    if (value.isEmpty) {
      passwordError.value = 'Password tidak boleh kosong';
      return;
    }

    if (value.length < 6) {
      passwordError.value = 'Password minimal 6 karakter';
      return;
    }

    final hasUppercase = RegExp(r'[A-Z]').hasMatch(value);
    final hasNumber = RegExp(r'[0-9]').hasMatch(value);
    final hasSpecial = RegExp(
      r'[!@#\$%^&*(),.?":{}|<>_\-+=/\\[\]~`]',
    ).hasMatch(value);

    if (!hasUppercase) {
      passwordError.value = 'Password harus mengandung minimal 1 huruf besar';
      return;
    }

    if (!(hasNumber || hasSpecial)) {
      passwordError.value =
          'Password harus mengandung minimal 1 angka atau karakter spesial';
      return;
    }

    passwordError.value = '';

    // Validasi ulang konfirmasi password jika sudah diisi
    if (registerConfirmPasswordController.text.isNotEmpty) {
      validateConfirmPassword(registerConfirmPasswordController.text);
    }
  }

  void validateConfirmPassword(String value) {
    confirmPasswordTouched.value = true;

    if (value.isEmpty) {
      confirmPasswordError.value = 'Konfirmasi password tidak boleh kosong';
    } else if (value != registerPasswordController.text) {
      confirmPasswordError.value = 'Password tidak cocok';
    } else {
      confirmPasswordError.value = '';
    }
  }

  // Dipanggil ketika password berubah supaya confirm password ikut divalidasi
  void onPasswordChanged(String value) {
    validatePassword(value);

    if (confirmPasswordTouched.value) {
      validateConfirmPassword(registerConfirmPasswordController.text);
    }
  }

  void _resetRegisterErrors() {
    usernameTouched.value = false;
    emailTouched.value = false;
    confirmPasswordTouched.value = false;
    usernameError.value = '';
    emailError.value = '';
    confirmPasswordError.value = '';
    passwordError.value = '';
  }

  // ==================== LOGIN ====================

  Future<void> login() async {
    if (loginUsernameController.text.isEmpty ||
        loginPasswordController.text.isEmpty) {
      Get.snackbar(
        'Error',
        'Username dan Password harus diisi',
        backgroundColor: Colors.red,
        colorText: Colors.white,
      );
      return;
    }

    try {
      isLoading.value = true;

      final response = await authProvider.login(
        username: loginUsernameController.text.trim(),
        password: loginPasswordController.text,
      );

      if (response.statusCode == 200 && response.body['success'] == true) {
        authProvider.saveToken(response.body['token']);
        UserModel user = UserModel.fromJson(response.body['user']);
        authProvider.saveUser(user);
        authProvider.setAppVisited();

        if (Get.isRegistered<BookmarkController>()) {
          Get.find<BookmarkController>().onUserLoggedIn();
        }

        if (Get.isRegistered<HomeController>()) {
          Get.find<HomeController>().onUserLoggedIn();
        }

        final preferencesSet = response.body['preferences_set'] ?? true;

        _resubscribeAfterLogin();

        Get.snackbar(
          'Success',
          'Login berhasil!',
          backgroundColor: Colors.green,
          colorText: Colors.white,
        );

        if (!preferencesSet) {
          Get.offAllNamed(AppRoutes.preference);
        } else {
          Get.offAllNamed(AppRoutes.main);
        }

        Get.offAllNamed(AppRoutes.main);
      } else {
        Get.snackbar(
          'Error',
          response.body['message'] ?? 'Login gagal',
          backgroundColor: Colors.red,
          colorText: Colors.white,
        );
      }
    } catch (e) {
      Get.snackbar(
        'Error',
        'Terjadi kesalahan: $e',
        backgroundColor: Colors.red,
        colorText: Colors.white,
      );
    } finally {
      isLoading.value = false;
    }
  }

  // ==================== REGISTER ====================

  Future<void> register() async {
    // Paksa validasi semua field sebelum submit
    validateUsername(registerUsernameController.text);
    validateEmail(registerEmailController.text);
    validatePassword(registerPasswordController.text);
    validateConfirmPassword(registerConfirmPasswordController.text);

    if (registerPasswordController.text.isEmpty) {
      Get.snackbar(
        'Error',
        'Password tidak boleh kosong',
        backgroundColor: Colors.red,
        colorText: Colors.white,
      );
      return;
    }

    if (usernameError.value.isNotEmpty ||
        emailError.value.isNotEmpty ||
        confirmPasswordError.value.isNotEmpty ||
        passwordError.value.isNotEmpty) {
      return;
    }

    try {
      isLoading.value = true;

      final response = await authProvider.register(
        username: registerUsernameController.text.trim(),
        email: registerEmailController.text.trim(),
        password: registerPasswordController.text,
        name: registerUsernameController.text.trim(),
      );

      if (response.statusCode == 200 && response.body['success'] == true) {
        authProvider.saveToken(response.body['token']);
        UserModel user = UserModel.fromJson(response.body['user']);
        authProvider.saveUser(user);
        authProvider.setAppVisited();

        _resetRegisterErrors();

        Get.snackbar(
          'Berhasil',
          'Registrasi berhasil! Pilih topik favoritmu',
          backgroundColor: Colors.green,
          colorText: Colors.white,
          snackPosition: SnackPosition.TOP,
        );

        Get.offAllNamed(AppRoutes.preference);
      } else {
        Get.snackbar(
          'Error',
          response.body['message'] ?? 'Registrasi gagal',
          backgroundColor: Colors.red,
          colorText: Colors.white,
        );
      }
    } catch (e) {
      Get.snackbar(
        'Error',
        'Terjadi kesalahan: $e',
        backgroundColor: Colors.red,
        colorText: Colors.white,
      );
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> _resubscribeAfterLogin() async {
    try {
      // Ambil preferensi dari server
      final authProvider = Get.find<AuthProvider>();
      final response = await authProvider.getPreferences();

      if (response.statusCode == 200 && response.body['success'] == true) {
        final prefs = response.body['preferences'];

        final List<int> categoryIds = [
          ...List<int>.from(prefs['preferred_categories'] ?? []),
          ...List<int>.from(prefs['preferred_locations'] ?? []),
        ];

        if (categoryIds.isNotEmpty) {
          // Update subscriptions berdasarkan preferensi tersimpan
          await NotificationService.updateSubscriptions(categoryIds);
          // print('✅ Resubscribed after login: $categoryIds');
        }
      }
    } catch (e) {
      // Silent fail - login tetap berhasil
      // print('⚠️ Resubscribe after login failed: $e');
    }
  }

  void togglePasswordVisibility() {
    isPasswordVisible.value = !isPasswordVisible.value;
  }

  void toggleConfirmPasswordVisibility() {
    isConfirmPasswordVisible.value = !isConfirmPasswordVisible.value;
  }

  Future<void> loginWithGoogle() async {
    try {
      isLoading.value = true;

      // Step 1: Ambil data dari Google
      final socialResult = await _socialAuth.signInWithGoogle();

      if (socialResult == null) {
        isLoading.value = false;
        return; // User cancelled
      }

      // Step 2: Kirim ke server
      await _processSocialLogin(socialResult);
    } catch (e) {
      isLoading.value = false;
      Get.snackbar(
        'Error',
        'Login Google gagal: $e',
        backgroundColor: Colors.red,
        colorText: Colors.white,
        snackPosition: SnackPosition.TOP,
      );
    }
  }

  // ==================== PROCESS SOCIAL LOGIN ====================

  Future<void> _processSocialLogin(SocialAuthResult socialResult) async {
    try {
      final response = await authProvider.socialLogin(
        provider: socialResult.provider,
        email: socialResult.email,
        name: socialResult.name,
        socialId: socialResult.socialId,
        avatarUrl: socialResult.avatarUrl,
      );

      if (response.statusCode == 200 && response.body['success'] == true) {
        // Simpan token & user
        authProvider.saveToken(response.body['token']);
        final user = UserModel.fromJson(response.body['user']);
        authProvider.saveUser(user);

        final preferencesSet = response.body['preferences_set'] ?? true;

        // Resubscribe notifications
        _resubscribeAfterLogin();

        Get.snackbar(
          'Berhasil',
          'Login berhasil!',
          backgroundColor: Colors.green,
          colorText: Colors.white,
          snackPosition: SnackPosition.TOP,
        );

        if (!preferencesSet) {
          Get.offAllNamed(AppRoutes.preference);
        } else {
          Get.offAllNamed(AppRoutes.main);
        }
      } else {
        Get.snackbar(
          'Error',
          response.body['message'] ?? 'Login gagal',
          backgroundColor: Colors.red,
          colorText: Colors.white,
          snackPosition: SnackPosition.TOP,
        );
      }
    } catch (e) {
      Get.snackbar(
        'Error',
        'Terjadi kesalahan: $e',
        backgroundColor: Colors.red,
        colorText: Colors.white,
        snackPosition: SnackPosition.TOP,
      );
    } finally {
      isLoading.value = false;
    }
  }

  // ==================== LOGOUT (Update - tambah social signout) ====================

  Future<void> logout() async {
    // Sign out dari social providers
    final userId = authProvider.getUserId();
    await _socialAuth.signOutGoogle();

    // Clear notifications
    await NotificationService.clearSubscriptions();
    if (Get.isRegistered<ReadingTrackerService>()) {
      Get.find<ReadingTrackerService>().clearForUser(userId);
    }

    authProvider.clearAuth();
    Get.offAllNamed(AppRoutes.login);
  }
}
