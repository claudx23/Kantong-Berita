import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../data/models/category_item_model.dart';
import '../../../widgets/kb_appbar.dart';
import '../../../utils/app_colors.dart';
import '../controllers/category_controller.dart';

class CategoryView extends GetView<CategoryController> {
  const CategoryView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.getBackgroundColor(context),
      appBar: const KbAppBar(),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Title
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 16),
              child: Center(
                child: Text(
                  'KATEGORI',
                  style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1,
                    color: AppColors.getTextPrimaryColor(context),
                  ),
                ),
              ),
            ),

            // Kategori Umum Grid
            _buildUmumSection(),

            const SizedBox(height: 24),

            // Berita Lokal Section
            _buildLokalSection(),

            const SizedBox(height: 32),
          ],
        ),
      ),
    );
  }

  // ==================== UMUM SECTION ====================

  Widget _buildUmumSection() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: GridView.builder(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 4,
          crossAxisSpacing: 12,
          mainAxisSpacing: 12,
          childAspectRatio: 0.85,
        ),
        itemCount: controller.umumCategories.length,
        itemBuilder: (context, index) {
          return _buildUmumCard(controller.umumCategories[index]);
        },
      ),
    );
  }

  Widget _buildUmumCard(CategoryItem category) {
    return GestureDetector(
      onTap: () => controller.goToCategoryPosts(category),
      child: Column(
        children: [
          // Icon Box
          Expanded(
            child: Container(
              width: double.infinity,
              decoration: BoxDecoration(
                color: AppColors.getCardColor(Get.context!),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Center(
                child: Icon(
                  _getIcon(category.slug),
                  size: 32,
                  color: const Color(0xFFD32F2F),
                ),
              ),
            ),
          ),
          const SizedBox(height: 6),
          // Name
          Text(
            category.name,
            textAlign: TextAlign.center,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w500,
              color: AppColors.getTextPrimaryColor(Get.context!),
            ),
          ),
        ],
      ),
    );
  }

  // ==================== LOKAL SECTION ====================

  Widget _buildLokalSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 16),
          child: Text(
            'Berita Lokal',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: AppColors.getTextPrimaryColor(Get.context!),
            ),
          ),
        ),
        const SizedBox(height: 12),

        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 4,
              crossAxisSpacing: 12,
              mainAxisSpacing: 12,
              childAspectRatio: 0.75,
            ),
            itemCount: controller.lokalCategories.length,
            itemBuilder: (context, index) {
              return _buildLokalCard(controller.lokalCategories[index]);
            },
          ),
        ),
      ],
    );
  }

  Widget _buildLokalCard(CategoryItem category) {
    return GestureDetector(
      onTap: () => controller.goToCategoryPosts(category),
      child: Column(
        children: [
          // Image Box
          Expanded(
            child: Container(
              width: double.infinity,
              decoration: BoxDecoration(
                color: AppColors.getCardColor(Get.context!),
                borderRadius: BorderRadius.circular(12),
                image: category.image != null
                    ? DecorationImage(
                        image: AssetImage(category.image!),
                        fit: BoxFit.cover,
                      )
                    : null,
              ),
              child: category.image == null
                  ? Center(
                      child: Text(
                        category.name[0], // Inisial
                        style: const TextStyle(
                          fontSize: 28,
                          fontWeight: FontWeight.bold,
                          color: Color(0xFFD32F2F),
                        ),
                      ),
                    )
                  : null,
            ),
          ),
          const SizedBox(height: 6),
          // Name
          Text(
            category.name,
            textAlign: TextAlign.center,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w500,
              color: AppColors.getTextPrimaryColor(Get.context!),
            ),
          ),
        ],
      ),
    );
  }

  // ==================== ICON MAPPING ====================

  IconData _getIcon(String slug) {
    switch (slug) {
      case 'berita-utama':
        return Icons.newspaper;
      case 'bisnis':
        return Icons.business_center;
      case 'ekonomi':
        return Icons.attach_money;
      case 'gaya-hidup':
        return Icons.spa;
      case 'hukum':
        return Icons.gavel;
      case 'industri':
        return Icons.factory;
      case 'infrastruktur':
        return Icons.construction;
      case 'kesehatan':
        return Icons.local_hospital;
      case 'nasional':
        return Icons.flag;
      case 'olahraga':
        return Icons.sports_soccer;
      case 'headline':
        return Icons.how_to_vote;
      case 'seleb':
        return Icons.star;
      case 'teknologi':
        return Icons.computer;
      case 'viral':
        return Icons.trending_up;
      case 'wisata':
        return Icons.flight;
      default:
        return Icons.category;
    }
  }
}
