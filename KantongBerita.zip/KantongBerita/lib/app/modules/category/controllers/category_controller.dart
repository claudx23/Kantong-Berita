import 'package:get/get.dart';
import '../../../data/models/category_item_model.dart';
import '../../../routes/app_routes.dart';

class CategoryController extends GetxController {

  // ==================== KATEGORI UMUM ====================
  final umumCategories = <CategoryItem>[
    CategoryItem(name: 'Berita Utama',  slug: 'berita-utama',  id: 36,   type: CategoryType.umum),
    CategoryItem(name: 'Bisnis',        slug: 'bisnis',        id: 2,    type: CategoryType.umum),
    CategoryItem(name: 'Ekonomi',       slug: 'ekonomi',       id: 3,    type: CategoryType.umum),
    CategoryItem(name: 'Gaya Hidup',    slug: 'gaya-hidup',    id: 111,  type: CategoryType.umum),
    CategoryItem(name: 'Hukum',         slug: 'hukum',         id: 25,   type: CategoryType.umum),
    CategoryItem(name: 'Industri',      slug: 'industri',      id: 7,    type: CategoryType.umum),
    CategoryItem(name: 'Infrastruktur', slug: 'infrastruktur', id: 9,    type: CategoryType.umum),
    CategoryItem(name: 'Kesehatan',     slug: 'kesehatan',     id: 108,  type: CategoryType.umum),
    CategoryItem(name: 'Nasional',      slug: 'nasional',      id: 107,  type: CategoryType.umum),
    CategoryItem(name: 'Olahraga',      slug: 'olahraga',      id: 109,  type: CategoryType.umum),
    CategoryItem(name: 'Pilkada',       slug: 'headline',      id: 1944, type: CategoryType.umum),
    CategoryItem(name: 'Seleb',         slug: 'seleb',         id: 672,  type: CategoryType.umum),
    CategoryItem(name: 'Teknologi',     slug: 'teknologi',     id: 2880, type: CategoryType.umum),
    CategoryItem(name: 'Viral',         slug: 'viral',         id: 142,  type: CategoryType.umum),
    CategoryItem(name: 'Wisata',        slug: 'wisata',        id: 110,  type: CategoryType.umum),
  ].obs;

  // ==================== BERITA LOKAL ====================
  final lokalCategories = <CategoryItem>[
    CategoryItem(name: 'Aceh',             slug: 'aceh',             id: 3448, type: CategoryType.lokal),
    CategoryItem(name: 'Bandung',          slug: 'bandung',          id: 2025, type: CategoryType.lokal),
    CategoryItem(name: 'Batangtoru',       slug: 'batangtoru',       id: 1745, type: CategoryType.lokal),
    CategoryItem(name: 'Belawan',          slug: 'belawan',          id: 183,  type: CategoryType.lokal),
    CategoryItem(name: 'Bogor',            slug: 'bogor',            id: 3863, type: CategoryType.lokal),
    CategoryItem(name: 'Deli Serdang',     slug: 'deli-serdang',     id: 3631, type: CategoryType.lokal),
    CategoryItem(name: 'Gunungsitoli',     slug: 'gunungsitoli',     id: 2579, type: CategoryType.lokal),
    CategoryItem(name: 'Jakarta',          slug: 'jakarta',          id: 1403, type: CategoryType.lokal),
    CategoryItem(name: 'Jayapura',         slug: 'jayapura',         id: 3851, type: CategoryType.lokal),
    CategoryItem(name: 'Keerom',           slug: 'keerom',           id: 3869, type: CategoryType.lokal),
    CategoryItem(name: 'Labuhan Batu',     slug: 'labuhan-batu',     id: 1810, type: CategoryType.lokal),
    CategoryItem(name: 'Lanny Jaya',       slug: 'lanny-jaya',       id: 3877, type: CategoryType.lokal),
    CategoryItem(name: 'Madina',           slug: 'madina',           id: 1259, type: CategoryType.lokal),
    CategoryItem(name: 'Makassar',         slug: 'makassar',         id: 2275, type: CategoryType.lokal),
    CategoryItem(name: 'Medan',            slug: 'medan',            id: 869,  type: CategoryType.lokal),
    CategoryItem(name: 'Mimika',           slug: 'mimika',           id: 3846, type: CategoryType.lokal),
    CategoryItem(name: 'Nias',             slug: 'nias',             id: 2498, type: CategoryType.lokal),
    CategoryItem(name: 'Padang Lawas',     slug: 'padang-lawas',     id: 1332, type: CategoryType.lokal),
    CategoryItem(name: 'Padang Sidempuan', slug: 'padang-sidempuan', id: 1862, type: CategoryType.lokal),
    CategoryItem(name: 'Paniai',           slug: 'paniai',           id: 3860, type: CategoryType.lokal),
    CategoryItem(name: 'Papua Pegunungan', slug: 'papua-pegunungan', id: 3839, type: CategoryType.lokal),
    CategoryItem(name: 'Papua Tengah',     slug: 'papua-tengah',     id: 3832, type: CategoryType.lokal),
    CategoryItem(name: 'Pilkada Sibolga',  slug: 'pilkada-sibolga',  id: 155,  type: CategoryType.lokal),
    CategoryItem(name: 'Pilkada Tapteng',  slug: 'pilkada-tapteng',  id: 3165, type: CategoryType.lokal),
    CategoryItem(name: 'Samosir',          slug: 'samosir',          id: 3063, type: CategoryType.lokal),
    CategoryItem(name: 'Sibolga',          slug: 'sibolga',          id: 37,   type: CategoryType.lokal),
    CategoryItem(name: 'Surakarta',        slug: 'surakarta',        id: 3600, type: CategoryType.lokal),
    CategoryItem(name: 'Tapanuli Selatan', slug: 'tapsel',           id: 1794, type: CategoryType.lokal),
    CategoryItem(name: 'Tapanuli Tengah',  slug: 'tapteng',          id: 56,   type: CategoryType.lokal),
    CategoryItem(name: 'Tapanuli Utara',   slug: 'taput',            id: 66,   type: CategoryType.lokal),
    CategoryItem(name: 'Tebing Tinggi',    slug: 'tebing-tinggi',    id: 2272, type: CategoryType.lokal),
    CategoryItem(name: 'Toba',             slug: 'toba',             id: 863,  type: CategoryType.lokal),
    CategoryItem(name: 'Yogyakarta',       slug: 'yogyakarta',       id: 2973, type: CategoryType.lokal),
  ].obs;

  void goToCategoryPosts(CategoryItem category) {
    Get.toNamed(
      AppRoutes.categoryPosts,
      arguments: {
        'categoryName': category.name,
        'categoryId': category.id,
        'categorySlug': category.slug,
      },
    );
  }
}