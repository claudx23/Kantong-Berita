import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';
import '../controllers/home_controller.dart';
import '../../../widgets/kb_appbar.dart';
import '../../../widgets/post_skeleton.dart';
import '../../../widgets/back_to_top_button.dart';
import '../../../routes/app_routes.dart';
import '../../../utils/app_colors.dart';

class HomeView extends GetView<HomeController> {
  const HomeView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.getBackgroundColor(context),
      appBar: const KbAppBar(),
      floatingActionButton: Obx(
        () => BackToTopButton(
          scrollController: controller.scrollController,
          isVisible: controller.showBackToTop.value,
        ),
      ),
      body: Obx(() {
        if (controller.isLoading.value &&
            controller.latestPosts.isEmpty &&
            controller.headlinePosts.isEmpty) {
          return const Center(
            child: CircularProgressIndicator(color: Color(0xFFD32F2F)),
          );
        }

        return RefreshIndicator(
          color: const Color(0xFFD32F2F),
          onRefresh: controller.refreshPosts,
          child: SingleChildScrollView(
            controller: controller.scrollController,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 12),
                _buildSearchBar(),
                const SizedBox(height: 20),
                _buildHeadlineSection(),
                const SizedBox(height: 24),
                _buildLatestSection(),
                const SizedBox(height: 24),
              ],
            ),
          ),
        );
      }),
    );
  }

  // ==================== SEARCH BAR ====================

  Widget _buildSearchBar() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: GestureDetector(
        onTap: () => Get.toNamed(AppRoutes.search),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          decoration: BoxDecoration(
            color: Theme.of(Get.context!).brightness == Brightness.dark
                ? Colors.grey[800]
                : Colors.grey[100],
            borderRadius: BorderRadius.circular(25),
            border: Border.all(
              color: Theme.of(Get.context!).brightness == Brightness.dark
                  ? Colors.grey[700]!
                  : Colors.grey[300]!,
            ),
          ),
          child: Row(
            children: [
              Icon(Icons.search, color: Colors.grey[500], size: 20),
              const SizedBox(width: 8),
              Text(
                'Pencarian',
                style: TextStyle(color: Colors.grey[500], fontSize: 14),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ==================== HEADLINE SECTION ====================

  Widget _buildHeadlineSection() {
    return Obx(() {
      if (controller.headlinePosts.isEmpty) return const SizedBox.shrink();

      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              children: [
                Container(
                  width: 4,
                  height: 20,
                  margin: const EdgeInsets.only(right: 8),
                  decoration: BoxDecoration(
                    color: const Color(0xFFD32F2F),
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
                Text(
                  'Berita Utama',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: AppColors.getTextPrimaryColor(Get.context!),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          CarouselSlider.builder(
            itemCount: controller.headlinePosts.length,
            options: CarouselOptions(
              height: 220,
              viewportFraction: 0.92,
              enlargeCenterPage: false,
              autoPlay: true,
              autoPlayInterval: const Duration(seconds: 4),
              autoPlayAnimationDuration: const Duration(milliseconds: 600),
              onPageChanged: (index, reason) {
                controller.currentCarouselIndex.value = index;
              },
            ),
            itemBuilder: (context, index, realIndex) {
              return _buildHeadlineCard(controller.headlinePosts[index]);
            },
          ),
          const SizedBox(height: 12),
          Obx(
            () => Center(
              child: AnimatedSmoothIndicator(
                activeIndex: controller.currentCarouselIndex.value,
                count: controller.headlinePosts.length,
                effect: const ExpandingDotsEffect(
                  dotWidth: 8,
                  dotHeight: 8,
                  expansionFactor: 2,
                  activeDotColor: Color(0xFFD32F2F),
                  dotColor: Colors.grey,
                ),
              ),
            ),
          ),
        ],
      );
    });
  }

  Widget _buildHeadlineCard(dynamic post) {
    return GestureDetector(
      onTap: () => Get.toNamed(AppRoutes.postDetail, arguments: post),
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 4),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          color: AppColors.getCardColor(Get.context!),
        ),
        child: Stack(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: CachedNetworkImage(
                imageUrl: post.featuredImage,
                width: double.infinity,
                height: 220,
                fit: BoxFit.cover,
                placeholder: (context, url) =>
                    Container(color: Colors.grey[300]),
                errorWidget: (context, url, error) => Container(
                  color: Colors.grey[300],
                  child: const Icon(
                    Icons.image_not_supported,
                    size: 50,
                    color: Colors.grey,
                  ),
                ),
              ),
            ),
            ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Colors.transparent,
                      Colors.black.withValues(alpha: 0.8),
                    ],
                    stops: const [0.4, 1.0],
                  ),
                ),
              ),
            ),
            Positioned(
              bottom: 0,
              left: 0,
              right: 0,
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (post.categoryName.isNotEmpty)
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 8,
                          vertical: 3,
                        ),
                        decoration: BoxDecoration(
                          color: const Color(0xFFD32F2F),
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: Text(
                          post.categoryName,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    const SizedBox(height: 8),
                    Text(
                      post.title,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                        height: 1.3,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 6),
                    Text(
                      controller.getTimeAgo(post.date),
                      style: TextStyle(
                        color: Colors.white.withValues(alpha: 0.7),
                        fontSize: 11,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ==================== LATEST SECTION WITH TAB BAR ====================

  Widget _buildLatestSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Tab Bar
        _buildTabBar(),
        const SizedBox(height: 12),

        // Content berdasarkan tab aktif
        _buildTabContent(),
      ],
    );
  }

  // ==================== TAB BAR ====================

  Widget _buildTabBar() {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Obx(
        () => Row(
          children: [
            // ✅ Tab 1: Terbaru (selalu tampil)
            _buildTabItem(index: 0, label: 'Terbaru'),
            const SizedBox(width: 8),

            // ✅ Tab 2: Untuk Anda (hanya jika login)
            if (controller.isLoggedIn)
              _buildTabItem(
                index: 1,
                label: 'Untuk Anda',
                isPersonalized: true,
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildTabItem({
    required int index,
    required String label,
    bool isPersonalized = false,
  }) {
    final isActive = controller.activeTab.value == index;

    return GestureDetector(
      onTap: () => controller.activeTab.value = index,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 8),
        decoration: BoxDecoration(
          border: Border(
            bottom: BorderSide(
              color: isActive ? const Color(0xFFD32F2F) : Colors.transparent,
              width: 2.5,
            ),
          ),
        ),
        child: Row(
          children: [
            Text(
              label,
              style: TextStyle(
                fontSize: 15,
                fontWeight: isActive ? FontWeight.bold : FontWeight.normal,
                color: isActive ? const Color(0xFFD32F2F) : Colors.grey[600],
              ),
            ),
            if (isPersonalized) ...[
              const SizedBox(width: 4),
              Icon(
                Icons.auto_awesome,
                size: 12,
                color: isActive ? const Color(0xFFD32F2F) : Colors.grey[400],
              ),
            ],
          ],
        ),
      ),
    );
  }

  // ==================== TAB CONTENT ====================

  Widget _buildTabContent() {
    return Obx(() {
      final posts = controller.currentPosts;

      // Skeleton loading
      if (controller.isLoading.value && posts.isEmpty) {
        return ListView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: 5,
          itemBuilder: (context, index) => const PostSkeleton(),
        );
      }

      // Empty state untuk tab Untuk Anda
      if (posts.isEmpty && controller.activeTab.value == 1) {
        return _buildPersonalEmptyState();
      }

      if (posts.isEmpty) {
        return const Center(
          child: Padding(
            padding: EdgeInsets.all(32),
            child: Text('Tidak ada berita'),
          ),
        );
      }

      return Column(
        children: [
          ListView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: posts.length,
            itemBuilder: (context, index) {
              return _buildPostCard(posts[index]);
            },
          ),

          // Load More
          Obx(() {
            if (controller.isLoadingMore.value) {
              return const Padding(
                padding: EdgeInsets.all(16),
                child: Center(
                  child: CircularProgressIndicator(color: Color(0xFFD32F2F)),
                ),
              );
            }

            if (controller.hasMore) {
              return Padding(
                padding: const EdgeInsets.all(16),
                child: SizedBox(
                  width: double.infinity,
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(12),
                      gradient: const LinearGradient(
                        colors: [
                          Color(0xFFFF3B3B),
                          Color(0xFFD32F2F),
                          Color(0xFFB71C1C),
                        ],
                      ),
                    ),
                    child: Material(
                      color: Colors.transparent,
                      child: InkWell(
                        borderRadius: BorderRadius.circular(12),
                        onTap: controller.loadMorePosts,
                        child: const Padding(
                          padding: EdgeInsets.symmetric(vertical: 14),
                          child: Center(
                            child: Text(
                              'Selengkapnya',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              );
            }

            return Padding(
              padding: const EdgeInsets.all(16),
              child: Center(
                child: Text(
                  'Semua berita telah ditampilkan',
                  style: TextStyle(color: Colors.grey[500], fontSize: 13),
                ),
              ),
            );
          }),
        ],
      );
    });
  }

  // ==================== POST CARD ====================

  Widget _buildPostCard(dynamic post) {
    return GestureDetector(
      onTap: () => Get.toNamed(AppRoutes.postDetail, arguments: post),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: CachedNetworkImage(
                imageUrl: post.featuredImage,
                width: 90,
                height: 90,
                fit: BoxFit.cover,
                placeholder: (context, url) =>
                    Container(color: Colors.grey[300]),
                errorWidget: (context, url, error) => Container(
                  color: Colors.grey[300],
                  child: const Icon(
                    Icons.image_not_supported,
                    color: Colors.grey,
                  ),
                ),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      if (post.categoryName.isNotEmpty)
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 6,
                            vertical: 2,
                          ),
                          decoration: BoxDecoration(
                            color: const Color(0xFFD32F2F),
                            borderRadius: BorderRadius.circular(3),
                          ),
                          child: Text(
                            post.categoryName,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 9,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      const SizedBox(width: 6),
                      Text(
                        controller.getTimeAgo(post.date),
                        style: TextStyle(color: Colors.grey[500], fontSize: 11),
                      ),
                    ],
                  ),
                  const SizedBox(height: 6),
                  Text(
                    post.title,
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                      color: AppColors.getTextPrimaryColor(Get.context!),
                      height: 1.4,
                    ),
                    maxLines: 3,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ==================== EMPTY STATE (UNTUK ANDA) ====================

  Widget _buildPersonalEmptyState() {
    return SizedBox(
      height: MediaQuery.of(Get.context!).size.height * 0.4,
      child: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.auto_awesome, size: 56, color: Colors.grey[300]),
            const SizedBox(height: 16),

            Text(
              'Belum ada preferensi',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w600,
                color: Colors.grey[500],
              ),
            ),

            const SizedBox(height: 8),

            Text(
              'Pilih kategori favorit kamu\nagar berita tersaji sesuai minat',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 13, color: Colors.grey[400]),
            ),

            const SizedBox(height: 20),

            SizedBox(
              width: MediaQuery.of(Get.context!).size.width * 0.5,
              child: ElevatedButton.icon(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFD32F2F),
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
                onPressed: () => Get.toNamed(
                  AppRoutes.preference,
                  arguments: {'isEditing': true},
                ),
                icon: const Icon(Icons.tune, size: 16),
                label: const Text('Pilih Preferensi'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
