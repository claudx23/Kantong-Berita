import 'package:get/get.dart';
import 'package:kantongberita/app/services/cache_service.dart';
import 'package:kantongberita/app/services/connectivity_service.dart';
import '../../../data/models/post_model.dart';
import '../../../data/providers/api_provider.dart';
import '../../../data/providers/auth_provider.dart';
import '../../../services/app_refresh_service.dart';
import '../../../utils/scroll_to_top_mixin.dart';
import '../../../utils/string_helper.dart';

class HomeController extends GetxController with ScrollToTopMixin {
  final ApiProvider apiProvider = Get.find<ApiProvider>();
  final AuthProvider authProvider = Get.find<AuthProvider>();
  final AppRefreshService refreshService = Get.find<AppRefreshService>();
  final ConnectivityService _conn = Get.find<ConnectivityService>();
  final CacheService _cache = Get.find<CacheService>();

  // Observables
  final headlinePosts = <PostModel>[].obs;
  final latestPosts = <PostModel>[].obs; // Tab Terbaru
  final personalPosts = <PostModel>[].obs; // Tab Untuk Anda
  final isLoading = false.obs;
  final isLoadingMore = false.obs;
  final hasMoreLatest = true.obs;
  final hasMorePersonal = true.obs;
  final currentPageLatest = 1.obs;
  final currentPagePersonal = 1.obs;
  final currentCarouselIndex = 0.obs;
  final activeTab = 0.obs; // 0 = Terbaru, 1 = Untuk Anda

  final exhaustedCategories = <int>{};

  // Apakah user sudah login
  bool get isLoggedIn => authProvider.isLoggedIn();

  static const int _headlineCategoryId = 36;

  @override
  void onInit() {
    super.onInit();
    setupScrollToTop();
    _listenToRefreshTriggers();
    _listenToConnectivity();
    loadInitialData();
  }

  void _listenToConnectivity() {
    ever(_conn.isOnline, (online) {
      if (online == true) {
        _onBackOnline();
      }
    });
  }

  Future<void> _onBackOnline() async {
    // Refresh latest
    await _silentRefreshLatest();

    // Refresh personal jika login
    if (isLoggedIn) {
      await _silentRefreshPersonal();
    }
  }

  void _loadFromCache() {
    try {
      final cachedLatest = _cache.getStalePostsCache('posts_page1_per20');
      if (cachedLatest != null && latestPosts.isEmpty) {
        latestPosts.value = cachedLatest
            .map((item) => PostModel.fromJson(item))
            .toList();
      }
    } catch (e) {
      // print('Failed to load latest cache: $e');
    }

    // Headline posts (format RAW WP API → pakai fromJson)
    try {
      final cachedHeadline = _cache.getStalePostsCache(
        'posts_cat${_headlineCategoryId}_page1_per5',
      );
      if (cachedHeadline != null && headlinePosts.isEmpty) {
        headlinePosts.value = cachedHeadline
            .map((item) => PostModel.fromJson(item))
            .toList();
      }
    } catch (e) {
      // print('Failed to load headline cache: $e');
    }

    _loadPersonalFromCache();
  }

  void _loadPersonalFromCache() {
    try {
      final cached = _cache.getStalePersonalPosts();


      if (cached != null && cached.isNotEmpty) {

        final list = <PostModel>[];
        for (var item in cached) {
          try {
            final post = PostModel.fromCache(Map<String, dynamic>.from(item));
            list.add(post);
          } catch (e) {
            // print('Failed parsing single item: $e | item=$item');
          }
        }

        personalPosts.value = list;
        hasMorePersonal.value = personalPosts.length >= 10;
      } else {
        // print('Cache kosong/null, tidak ada yang di-set');
      }
    } catch (e) {
      // print('STACK: $stack');
    }
  }
  // ==================== LOAD ====================

  Future<void> loadInitialData() async {
    try {
      isLoading.value = true;
      _loadFromCache();


      if (!_conn.isOnline.value) {
        isLoading.value = false;
        return;
      }

      final futures = <Future>[_loadHeadlinePosts(), _loadLatestPosts()];

      if (isLoggedIn) {
        futures.add(_loadPersonalPosts());
      }

      await Future.wait(futures);
      isLoading.value = false;
    } catch (e) {
      isLoading.value = false;
    }
  }

  // ==================== HEADLINE ====================

  Future<void> _loadHeadlinePosts() async {
    try {
      final posts = await apiProvider.fetchPostsByCategory(
        categoryId: _headlineCategoryId,
        page: 1,
        perPage: 5,
      );
      headlinePosts.value = posts;
    } catch (e) {
      // Sudah di-load dari cache di _loadFromCache()
      // print('Headline fetch failed, using cache');
    }
  }

  // ==================== TAB TERBARU ====================

  Future<void> _loadLatestPosts() async {
    try {
      currentPageLatest.value = 1;
      final posts = await apiProvider.fetchPosts(page: 1, perPage: 20);
      latestPosts.value = posts;
      hasMoreLatest.value = posts.length >= 20;
    } catch (e) {
      // print('Error loading latest: $e');
    }
  }

  Future<void> loadMoreLatest() async {
    if (!hasMoreLatest.value || isLoadingMore.value) return;
    try {
      isLoadingMore.value = true;
      currentPageLatest.value++;
      final newPosts = await apiProvider.fetchPosts(
        page: currentPageLatest.value,
        perPage: 20,
      );
      latestPosts.addAll(newPosts);
      hasMoreLatest.value = newPosts.length >= 20;
      isLoadingMore.value = false;
    } catch (e) {
      isLoadingMore.value = false;
      currentPageLatest.value--;
    }
  }

  // ==================== TAB UNTUK ANDA ====================

  Future<void> _loadPersonalPosts() async {
    try {
      currentPagePersonal.value = 1;

      // Ambil preferensi (dengan fallback ke cache)
      final preferredIds = await _getPreferredCategoryIds();

      if (preferredIds.isEmpty) {
        // Cek cache preferensi sebelum tampilkan empty
        final cachedPrefs = _cache.getCachedPreferences();
        if (cachedPrefs != null && cachedPrefs.isNotEmpty) {
          // Ada cache preferensi → fetch dari category cache
          final posts = await _fetchPersonalizedPosts(
            categoryIds: cachedPrefs,
            page: 1,
          );
          if (posts.isNotEmpty) {
            personalPosts.value = posts;
            hasMorePersonal.value = posts.length >= 10;
            _cache.savePersonalPosts(posts.map((p) => p.toJson()).toList());
          }
        }
        return;
      }

      final posts = await _fetchPersonalizedPosts(
        categoryIds: preferredIds,
        page: 1,
      );

      personalPosts.value = posts;
      hasMorePersonal.value = posts.length >= 10;

      // Simpan ke cache untuk offline
      _cache.savePersonalPosts(posts.map((p) => p.toJson()).toList());
    } catch (e) {
      // Fallback ke cache
      _loadPersonalFromCache();
    }
  }

  Future<void> loadMorePersonal() async {
    if (!hasMorePersonal.value || isLoadingMore.value) return;
    try {
      isLoadingMore.value = true;
      currentPagePersonal.value++;
      final preferredIds = await _getPreferredCategoryIds();
      final newPosts = await _fetchPersonalizedPosts(
        categoryIds: preferredIds,
        page: currentPagePersonal.value,
      );
      personalPosts.addAll(newPosts);
      hasMorePersonal.value =
          newPosts.isNotEmpty &&
          exhaustedCategories.length < preferredIds.take(4).length;
      isLoadingMore.value = false;
    } catch (e) {
      isLoadingMore.value = false;
      currentPagePersonal.value--;
    }
  }

  // ==================== LOAD MORE (dispatch) ====================

  Future<void> loadMorePosts() async {
    if (activeTab.value == 0) {
      await loadMoreLatest();
    } else {
      await loadMorePersonal();
    }
  }

  bool get hasMore =>
      activeTab.value == 0 ? hasMoreLatest.value : hasMorePersonal.value;

  List<PostModel> get currentPosts =>
      activeTab.value == 0 ? latestPosts : personalPosts;

  // ==================== REFRESH ====================

  Future<void> refreshPosts() async {
    currentCarouselIndex.value = 0;
    exhaustedCategories.clear();
    currentPageLatest.value = 1;
    currentPagePersonal.value = 1;

    await loadInitialData();
  }

  // ==================== PERSONALIZED FETCH ====================

  Future<List<PostModel>> _fetchPersonalizedPosts({
    required List<int> categoryIds,
    int page = 1,
  }) async {
    List<PostModel> allPosts = [];

    for (final id in categoryIds.take(4)) {
      if (exhaustedCategories.contains(id)) {
        continue;
      }

      try {
        final posts = await apiProvider.fetchPostsByCategory(
          categoryId: id,
          page: page,
          perPage: 5,
        );

        allPosts.addAll(posts);
      } catch (e) {
        // print('Category $id failed: $e');
      }
    }

    final seen = <int>{};

    final unique = allPosts.where((p) => seen.add(p.id)).toList();

    unique.sort((a, b) => b.date.compareTo(a.date));

    return unique;
  }

  Future<List<int>> _getPreferredCategoryIds() async {
    if (!isLoggedIn) return [];

    try {
      final response = await authProvider.getPreferences();
      if (response.statusCode == 200 && response.body['success'] == true) {
        final prefs = response.body['preferences'];
        final ids = [
          ...List<int>.from(prefs['preferred_categories'] ?? []),
          ...List<int>.from(prefs['preferred_locations'] ?? []),
        ];

        // ✅ Simpan ke cache setiap kali berhasil fetch
        if (ids.isNotEmpty) {
          _cache.savePreferences(ids);
        }

        return ids;
      }
    } catch (e) {
      // print('Preferences fetch failed, using cache: $e');
    }

    // ✅ Fallback ke cache preferensi saat offline/gagal
    return _cache.getCachedPreferences() ?? [];
  }

  void _listenToRefreshTriggers() {
    // ✅ Listen ke new post trigger (dari FCM)
    ever(refreshService.newPostTrigger, (_) {
      // Skip trigger pertama saat init (value = 0)
      if (refreshService.newPostTrigger.value == 0) return;

      // print('🔄 Home: refresh karena ada berita baru');
      _silentRefreshLatest();
    });

    // ✅ Listen ke preferences trigger
    ever(refreshService.preferencesTrigger, (_) {
      if (refreshService.preferencesTrigger.value == 0) return;
      _cache.clearPreferences();
      // print('🔄 Home: refresh karena preferensi berubah');
      _silentRefreshPersonal();
    });
  }

  // ==================== SILENT REFRESH ====================

  // Refresh tanpa loading indicator (tidak ganggu user)
  Future<void> _silentRefreshLatest() async {
    try {
      final posts = await apiProvider.fetchPosts(
        page: 1,
        perPage: 20,
        forceRefresh: true,
      );

      if (posts.isNotEmpty) {
        latestPosts.value = posts;
        hasMoreLatest.value = posts.length >= 20;
        currentPageLatest.value = 1;

        // Juga refresh headline
        _loadHeadlinePosts();
      }
    } catch (e) {
      // print('Silent refresh latest failed: $e');
    }
  }

  Future<void> _silentRefreshPersonal() async {
    if (!isLoggedIn) return;

    try {
      exhaustedCategories.clear();
      currentPagePersonal.value = 1;

      final preferredIds = await _getPreferredCategoryIds();

      if (preferredIds.isEmpty) {
        personalPosts.value = [];
        hasMorePersonal.value = false;
        return;
      }

      final posts = await _fetchPersonalizedPosts(
        categoryIds: preferredIds,
        page: 1,
      );

      personalPosts.value = posts;
      hasMorePersonal.value = posts.length >= 10;
      _cache.savePersonalPosts(posts.map((p) => p.toJson()).toList());

      // print('✅ Personal posts refreshed: ${posts.length} posts');
    } catch (e) {
      // print('Silent refresh personal failed: $e');
    }
  }

  Future<void> onUserLoggedIn() async {
    // Clear cache preferensi akun lama
    _cache.clearUserSpecificData();

    // Reset personal state
    personalPosts.clear();
    activeTab.value = 0;
    hasMorePersonal.value = true;
    currentPagePersonal.value = 1;
    exhaustedCategories.clear();

    // Load ulang dengan data akun baru
    if (isLoggedIn) {
      await _loadPersonalPosts();
    }

  }

  // ==================== HELPERS ====================

  String getTimeAgo(String date) => StringHelper.timeAgo(date);
  String stripHtml(String html) => StringHelper.stripHtml(html);
}
