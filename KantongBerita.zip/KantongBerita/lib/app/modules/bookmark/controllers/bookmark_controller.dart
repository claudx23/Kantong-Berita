import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../data/models/bookmark_model.dart';
import '../../../data/providers/api_provider.dart';
import '../../../data/providers/auth_provider.dart';
import '../../../routes/app_routes.dart';
import '../../../services/bookmark_cache_service.dart';
import '../../../services/connectivity_service.dart';
import '../../../services/post_cache_service.dart';
import '../../../utils/string_helper.dart';

class BookmarkController extends GetxController {
  final AuthProvider authProvider = Get.find<AuthProvider>();
  final ApiProvider apiProvider = Get.find<ApiProvider>();
  final BookmarkCacheService _cache = Get.find<BookmarkCacheService>();
  final ConnectivityService _conn = Get.find<ConnectivityService>();
  final PostCacheService _postCache = Get.find<PostCacheService>();

  final bookmarks = <BookmarkModel>[].obs;
  final isLoading = false.obs;
  final loadingPostId = 0.obs;
  final isLoggedIn = false.obs;

  final searchQuery = ''.obs;
  final selectedCategory = ''.obs; // '' = semua kategori
  final searchController = TextEditingController();
  final isSearchActive = false.obs;

  @override
  void onInit() {
    super.onInit();
    updateAuthStatus();

    if (isLoggedIn.value) {
      // ✅ Langsung tampilkan cache dulu (instant)
      _loadFromCache();

      // Lalu fetch dari server jika online
      if (_conn.isOnline.value) {
        loadBookmarks();
      }
    }

    // ✅ Auto-refresh saat kembali online
    ever(_conn.isOnline, (online) {
      if (online == true && isLoggedIn.value) {
        loadBookmarks();
      }
    });

    searchController.addListener(() {
      searchQuery.value = searchController.text;
    });
  }

  @override
  void onClose() {
    searchController.dispose();
    super.onClose();
  }

  List<BookmarkModel> get filteredBookmarks {
    var result = bookmarks.toList();

    // Filter kategori
    if (selectedCategory.value.isNotEmpty) {
      result = result
          .where((b) => b.categoryName == selectedCategory.value)
          .toList();
    }

    // Filter pencarian (judul)
    final query = searchQuery.value.trim().toLowerCase();
    if (query.isNotEmpty) {
      result = result
          .where((b) => b.title.toLowerCase().contains(query))
          .toList();
    }

    return result;
  }

  // Daftar kategori unik dari bookmark yang ada (untuk filter chips)
  List<String> get availableCategories {
    final categories = bookmarks
        .map((b) => b.categoryName)
        .where((c) => c.isNotEmpty)
        .toSet()
        .toList();
    categories.sort();
    return categories;
  }

  // Jumlah bookmark per kategori (untuk badge)
  int countByCategory(String category) {
    return bookmarks.where((b) => b.categoryName == category).length;
  }

  // ==================== SEARCH ACTIONS ====================

  void toggleSearch() {
    isSearchActive.value = !isSearchActive.value;
    if (!isSearchActive.value) {
      clearSearch();
    }
  }

  void clearSearch() {
    searchController.clear();
    searchQuery.value = '';
  }

  void selectCategory(String category) {
    // Tap kategori yang sama → unselect (toggle)
    if (selectedCategory.value == category) {
      selectedCategory.value = '';
    } else {
      selectedCategory.value = category;
    }
  }

  void clearFilters() {
    selectedCategory.value = '';
    clearSearch();
    isSearchActive.value = false;
  }

  bool get hasActiveFilter =>
      selectedCategory.value.isNotEmpty || searchQuery.value.isNotEmpty;

  // ==================== AUTH ====================

  void updateAuthStatus() {
    isLoggedIn.value = authProvider.isLoggedIn();
  }

  void clearBookmarks() {
    bookmarks.clear();
    isLoggedIn.value = false;
  }

  // ==================== LOAD FROM CACHE (INSTANT) ====================

  void _loadFromCache() {
    final cached = _cache.getLocalBookmarks();
    if (cached.isNotEmpty) {
      bookmarks.value = cached;
    }
  }

  // ==================== LOAD FROM SERVER ====================

  Future<void> loadBookmarks() async {
    if (!authProvider.isLoggedIn()) return;

    // Offline → gunakan cache yang sudah ada
    if (!_conn.isOnline.value) {
      _loadFromCache();
      return;
    }

    try {
      isLoading.value = true;

      final response = await authProvider.getBookmarks();

      if (response.statusCode == 200 && response.body['success'] == true) {
        final List<dynamic> data = response.body['bookmarks'];
        final loaded = data
            .map((item) => BookmarkModel.fromJson(item))
            .toList();

        bookmarks.value = loaded;

        // Selalu update cache setelah fetch sukses
        _cache.saveBookmarks(loaded);
      }

      isLoading.value = false;
    } catch (e) {
      isLoading.value = false;
      _loadFromCache();
    }
  }

  // ==================== OPEN POST ====================

  Future<void> openPost(int postId) async {
    // ✅ Offline → coba dari PostCacheService
    if (!_conn.isOnline.value) {
      final cached = _postCache.getCachedPost(postId);
      if (cached != null) {
        Get.toNamed(AppRoutes.postDetail, arguments: cached);
        return;
      }

      Get.snackbar(
        'Konten Tidak Tersedia Offline',
        'Buka artikel ini saat online agar bisa dibaca offline',
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.orange,
        colorText: Colors.white,
        duration: const Duration(seconds: 3),
        icon: const Icon(Icons.wifi_off, color: Colors.white, size: 18),
      );
      return;
    }

    // ✅ Online → fetch dari server
    try {
      loadingPostId.value = postId;
      final post = await apiProvider.fetchPostById(postId);
      loadingPostId.value = 0;

      // Cache post saat berhasil fetch
      _postCache.cachePost(post);

      Get.toNamed(AppRoutes.postDetail, arguments: post);
    } catch (e) {
      loadingPostId.value = 0;

      // Fallback ke cache jika fetch gagal
      final cached = _postCache.getCachedPost(postId);
      if (cached != null) {
        Get.toNamed(AppRoutes.postDetail, arguments: cached);
        return;
      }

      Get.snackbar(
        'Error',
        'Gagal membuka berita',
        snackPosition: SnackPosition.TOP,
        backgroundColor: Colors.red,
        colorText: Colors.white,
      );
    }
  }

  void syncToggle({
    required int postId,
    required bool isNowBookmarked,
    required BookmarkModel? bookmark,
  }) {
    if (isNowBookmarked && bookmark != null) {
      // Tambah ke cache & list
      _cache.addBookmark(bookmark);
      if (!bookmarks.any((b) => b.id == postId)) {
        bookmarks.insert(0, bookmark);
      }
    } else {
      // Hapus dari cache & list
      _cache.removeBookmark(postId);
      bookmarks.removeWhere((b) => b.id == postId);
    }
  }

  // ==================== REMOVE ====================

  Future<void> removeBookmark(int postId) async {
    // Optimistic update
    bookmarks.removeWhere((b) => b.id == postId);
    _cache.removeBookmark(postId);

    if (!_conn.isOnline.value) {
      Get.snackbar(
        'Offline',
        'Perubahan akan disinkronkan saat online',
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.orange,
        colorText: Colors.white,
      );
      return;
    }

    try {
      final response = await authProvider.toggleBookmark(postId);

      if (response.statusCode == 200 && response.body['success'] == true) {
        Get.snackbar(
          'Berhasil',
          'Bookmark dihapus',
          snackPosition: SnackPosition.TOP,
          backgroundColor: Colors.green,
          colorText: Colors.white,
          duration: const Duration(seconds: 2),
        );
      } else {
        // Rollback
        await loadBookmarks();
      }
    } catch (e) {
      await loadBookmarks();
    }
  }

  // ==================== LOGIN / LOGOUT ====================

  Future<void> onUserLoggedIn() async {
    updateAuthStatus();
    _cache.clearAll();
    await loadBookmarks(); // Sync dari server
  }

  void onUserLoggedOut() {
    _cache.clearAll();
    clearBookmarks();
  }

  // ==================== HELPERS ====================

  Future<void> refreshBookmarks() async {
    updateAuthStatus();
    if (isLoggedIn.value) await loadBookmarks();
  }

  bool isOffline() => !_conn.isOnline.value;

  String getTimeAgo(String date) => StringHelper.timeAgo(date);

  void goToLogin() => Get.toNamed(AppRoutes.login);
}
