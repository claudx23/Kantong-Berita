import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

class ThemeProvider extends GetxController {
  final storage = GetStorage();
  final isDarkMode = false.obs;
  
  static const String _themeKey = 'isDarkMode';

  @override
  void onInit() {
    super.onInit();
    loadTheme();
  }

  void loadTheme() {
    final savedTheme = storage.read(_themeKey);
    isDarkMode.value = savedTheme ?? false;
    _applyTheme();
  }

  void toggleTheme() {
    isDarkMode.value = !isDarkMode.value;
    storage.write(_themeKey, isDarkMode.value);
    _applyTheme();
  }

  void setTheme(bool dark) {
    isDarkMode.value = dark;
    storage.write(_themeKey, dark);
    _applyTheme();
  }

  void _applyTheme() {
    Get.changeThemeMode(isDarkMode.value ? ThemeMode.dark : ThemeMode.light);
  }

  bool get isLight => !isDarkMode.value;
}
