import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import '../models/user_model.dart';

class AuthProvider extends GetConnect {
  final storage = GetStorage();

  @override
  void onInit() {
    httpClient.baseUrl = 'https://kantongberita.com/wp-json/flutter/v1';
    httpClient.timeout = const Duration(seconds: 30);

    httpClient.addRequestModifier<dynamic>((request) {
      String? token = storage.read('auth_token');
      if (token != null) {
        request.headers['Authorization'] = 'Bearer $token';
      }
      return request;
    });

    super.onInit();
  }

  // ==================== AUTH ====================

  Future<Response> register({
    required String username,
    required String email,
    required String password,
    required String name,
  }) async {
    return await post('/register', {
      'username': username,
      'email': email,
      'password': password,
      'name': name,
    });
  }

  Future<Response> login({
    required String username,
    required String password,
  }) async {
    return await post('/login', {'username': username, 'password': password});
  }

  // ==================== BOOKMARK ====================

  Future<Response> getBookmarks() async {
    return await get('/bookmarks');
  }

  Future<Response> toggleBookmark(int postId) async {
    return await post('/bookmark/$postId', {});
  }

  Future<Response> checkBookmark(int postId) async {
    return await get('/bookmark/$postId/status');
  }

  // ==================== LOCAL STORAGE ====================

  void saveToken(String token) => storage.write('auth_token', token);
  void saveUser(UserModel user) => storage.write('user', user.toJson());
  String? getToken() => storage.read('auth_token');

  UserModel? getUser() {
    var userData = storage.read('user');
    if (userData != null) {
      return UserModel.fromJson(Map<String, dynamic>.from(userData));
    }
    return null;
  }

  void clearAuth() {
    storage.remove('auth_token');
    storage.remove('user');
  } 

  bool isLoggedIn() => getToken() != null;

  String getUserId() {
    final user = getUser();
    return user?.id.toString() ?? 'guest';
  }

  // ==================== KOMENTAR ====================

  Future<Response> getComments(int postId, {int page = 1}) async {
    return await get('/comments/$postId?page=$page');
  }

  Future<Response> addComment({
    required int postId,
    required String content,
    int parent = 0,
  }) async {
    return await post('/comments/$postId/add', {
      'content': content,
      'parent': parent,
    });
  }

  Future<Response> deleteComment(int commentId) async {
    return await delete('/comments/$commentId/delete');
  }

  // ==================== PREFERENSI ====================

  Future<Response> getPreferences() async {
    return await get('/preferences');
  }

  Future<Response> updatePreferences({
    required List<int> preferredCategories,
    required List<int> preferredLocations,
  }) async {
    return await post('/preferences/update', {
      'preferred_categories': preferredCategories,
      'preferred_locations': preferredLocations,
    });
  }

  Future<Response> checkPreferences() async {
    return await get('/preferences/check');
  }

  Future<Response> updatePassword({
    required String oldPassword,
    required String newPassword,
  }) async {
    return await post('/profile/update-password', {
      'old_password': oldPassword,
      'new_password': newPassword,
    });
  }

  Future<Response> updateProfile({String? name, String? email}) async {
    return await post('/profile/update', {'name': ?name, 'email': ?email});
  }

  Future<Response> getProfile() async {
    return await get('/profile');
  }

  // Simpan FCM Token ke server
  Future<Response> saveFcmToken(String token) async {
    return await post('/notification/token', {'fcm_token': token});
  }

  // Update notification settings
  Future<Response> updateNotificationSettings({
    required bool enabled,
    required bool breakingNews,
    required bool categoryUpdates,
  }) async {
    return await post('/notification/settings/update', {
      'enabled': enabled,
      'breaking_news': breakingNews,
      'category_updates': categoryUpdates,
    });
  }

  // Get notification settings
  Future<Response> getNotificationSettings() async {
    return await get('/notification/settings');
  }

  // ==================== FORGOT PASSWORD ====================

  Future<Response> sendOtp({required String email}) async {
    return await post('/forgot-password', {'email': email});
  }

  Future<Response> verifyOtp({
    required String email,
    required String otp,
  }) async {
    return await post('/verify-otp', {'email': email, 'otp': otp});
  }

  Future<Response> resetPassword({
    required String email,
    required String resetToken,
    required String newPassword,
    required String confirmPassword,
  }) async {
    return await post('/reset-password', {
      'email': email,
      'reset_token': resetToken,
      'new_password': newPassword,
      'confirm_password': confirmPassword,
    });
  }

  // ==================== NOTIFICATIONS ====================

  Future<Response> getNotifications({int page = 1}) async {
    return await get('/notifications?page=$page');
  }

  Future<Response> getUnreadCount() async {
    return await get('/notifications/unread-count');
  }

  Future<Response> markAllNotificationsRead() async {
    return await post('/notifications/read-all', {});
  }

  Future<Response> markNotificationRead(String notifId) async {
    return await post('/notifications/$notifId/read', {});
  }

  // Tambahkan method ini:
  Future<Response> socialLogin({
    required String provider,
    required String email,
    required String name,
    required String socialId,
    String? avatarUrl,
  }) async {
    return await post('/social-login', {
      'provider': provider,
      'email': email,
      'name': name,
      'social_id': socialId,
      'avatar_url': avatarUrl ?? '',
    });
  }

  // ==================== GUEST FLAG ====================

  void setAppVisited() {
    storage.write('app_visited', true);
  }

  bool hasVisitedBefore() {
    return storage.read('app_visited') ?? false;
  }
}
