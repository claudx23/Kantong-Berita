import 'package:get/get.dart';
import '../models/post_model.dart';
import '../../services/cache_service.dart';

class ApiProvider extends GetConnect {
  CacheService get _cache => Get.find<CacheService>();
  List<PostModel>? prefetchedPosts;
  Map<String, int>? prefetchedCategories;

  @override
  void onInit() {
    httpClient.baseUrl = 'https://kantongberita.com/wp-json/wp/v2';
    httpClient.timeout = const Duration(seconds: 60);

    // HTTP Response Caching Header
    httpClient.addResponseModifier((request, response) {
      return response;
    });

    super.onInit();
  }

  // ==================== POSTS ====================

  Future<List<PostModel>> fetchPosts({
    int page = 1,
    int perPage = 10,
    bool forceRefresh = false,
    Function(List<PostModel>)? onRefresh,
  }) async {
    // print('FETCH POSTS');
    final cacheKey = 'posts_page${page}_per$perPage';

    // Jika ada cache (meski expired), tampilkan dulu
    if (!forceRefresh) {
      final staleCache = _cache.getStalePostsCache(cacheKey);
      if (staleCache != null && _cache.isCacheExpired(cacheKey)) {
        _fetchAndCachePosts(cacheKey, page, perPage)
            .then((freshPosts) {
              onRefresh?.call(freshPosts);
            })
            .catchError((e) {});

        return staleCache.map((item) => PostModel.fromJson(item)).toList();
      }

      // Cache masih fresh → return langsung
      final freshCache = _cache.getPosts(cacheKey);
      if (freshCache != null) {
        return freshCache.map((item) => PostModel.fromJson(item)).toList();
      }
    }

    // Tidak ada cache → fetch dari API
    return await _fetchAndCachePosts(cacheKey, page, perPage);
  }

  Future<List<PostModel>> _fetchAndCachePosts(
    String cacheKey,
    int page,
    int perPage,
  ) async {
    int retry = 0;

    while (retry < 3) {
      try {
        final response = await get(
          '/posts?_embed&page=$page&per_page=$perPage',
        );

        if (response.statusCode == 200) {
          final List<dynamic> body = response.body;

          _cache.savePosts(cacheKey, body);

          return body.map((e) => PostModel.fromJson(e)).toList();
        }

        throw Exception(response.statusText);
      } catch (e) {
        retry++;

        if (retry >= 3) {
          throw Exception('Gagal memuat posts: $e');
        }

        await Future.delayed(Duration(seconds: retry));
      }
    }

    return [];
  }

  Future<List<PostModel>> fetchPostsByCategory({
    required int categoryId,
    int page = 1,
    int perPage = 10,
    bool forceRefresh = false,
  }) async {
    final cacheKey = 'posts_cat${categoryId}_page${page}_per$perPage';

    if (!forceRefresh) {
      final staleCache = _cache.getStalePostsCache(cacheKey);
      if (staleCache != null && _cache.isCacheExpired(cacheKey)) {
        _fetchAndCacheCategoryPosts(cacheKey, categoryId, page, perPage);
        return staleCache.map((item) => PostModel.fromJson(item)).toList();
      }

      final freshCache = _cache.getPosts(cacheKey);
      if (freshCache != null) {
        return freshCache.map((item) => PostModel.fromJson(item)).toList();
      }
    }

    return await _fetchAndCacheCategoryPosts(
      cacheKey,
      categoryId,
      page,
      perPage,
    );
  }

  Future<List<PostModel>> _fetchAndCacheCategoryPosts(
    String cacheKey,
    int categoryId,
    int page,
    int perPage,
  ) async {
    return await _withRetry(
      action: () async {
        final response = await get(
          '/posts?_embed&categories=$categoryId&page=$page&per_page=$perPage',
        );

        // No more pages
        if (response.statusCode == 400 &&
            response.body is Map &&
            response.body['code'] == 'rest_post_invalid_page_number') {
          return [];
        }

        // Success
        if (response.statusCode == 200) {
          final List<dynamic> body = response.body;
          _cache.savePosts(cacheKey, body);
          return body.map((item) => PostModel.fromJson(item)).toList();
        }

        throw Exception('HTTP ${response.statusCode}: ${response.statusText}');
      },
      label: 'category_$categoryId',
    );
  }

  Future<T> _withRetry<T>({
    required Future<T> Function() action,
    int maxRetries = 3,
    String label = '',
  }) async {
    int attempt = 0;

    while (true) {
      try {
        return await action();
      } catch (e) {
        attempt++;

        final isNetworkError =
            e.toString().contains('SocketException') ||
            e.toString().contains('TimeoutException') ||
            e.toString().contains('Connection') ||
            e.toString().contains('Network');

        // Jangan retry untuk 4xx errors
        final is4xx = e.toString().contains('HTTP 4');

        if (attempt >= maxRetries || is4xx) {
          // print('❌ [$label] Gagal setelah $attempt percobaan: $e');
          rethrow;
        }

        // Hanya retry untuk network errors dan 5xx
        if (!isNetworkError && !e.toString().contains('HTTP 5')) {
          rethrow;
        }

        // Exponential backoff: 1s, 2s, 4s
        final delay = Duration(seconds: 1 << (attempt - 1));
        // print(
        //   '🔄 [$label] Retry $attempt/$maxRetries dalam ${delay.inSeconds}s...',
        // );
        await Future.delayed(delay);
      }
    }
  }

  Future<PostModel> fetchPostById(int id) async {
    try {
      final response = await get('/posts/$id?_embed');
      if (response.statusCode == 200) {
        return PostModel.fromJson(response.body);
      } else {
        throw Exception('Gagal memuat post: ${response.statusText}');
      }
    } catch (e) {
      throw Exception('Error: $e');
    }
  }

  Future<List<PostModel>> searchPosts({
    required String query,
    int page = 1,
    int perPage = 10,
  }) async {
    try {
      final response = await get(
        '/posts?_embed&search=${Uri.encodeComponent(query)}&page=$page&per_page=$perPage',
      );

      if (response.statusCode == 200) {
        final List<dynamic> body = response.body;
        return body.map((item) => PostModel.fromJson(item)).toList();
      } else {
        throw Exception('Gagal melakukan pencarian: ${response.statusText}');
      }
    } catch (e) {
      throw Exception('Error: $e');
    }
  }

  Future<Map<String, int>> fetchCategories() async {
    // Cek cache categories
    final cachedCategories = _cache.getCategories();
    if (cachedCategories != null) return cachedCategories;

    try {
      final response = await get('/categories?per_page=100');

      if (response.statusCode == 200) {
        final List<dynamic> body = response.body;
        Map<String, int> categoryMap = {};

        for (var category in body) {
          final String slug = category['slug'] ?? '';
          final int id = category['id'] ?? 0;
          if (slug.isNotEmpty && id > 0) {
            categoryMap[slug] = id;
          }
        }

        _cache.saveCategories(categoryMap);
        return categoryMap;
      }
      return {};
    } catch (e) {
      // print('Error fetching categories: $e');
      return {};
    }
  }
}
