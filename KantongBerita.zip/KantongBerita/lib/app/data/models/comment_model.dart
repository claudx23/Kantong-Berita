import '../../utils/string_helper.dart';

class CommentModel {
  final int id;
  final String author;
  final String avatar;
  final String content;
  final String date;
  final int userId;
  final int parent;
  final List<CommentModel> replies;
  final int replyCount;

  CommentModel({
    required this.id,
    required this.author,
    required this.avatar,
    required this.content,
    required this.date,
    required this.userId,
    this.parent = 0,
    this.replies = const [],
    this.replyCount = 0,
  });

  factory CommentModel.fromJson(Map<String, dynamic> json) {
    return CommentModel(
      id: json['id'] ?? 0,
      author: json['author'] ?? 'Anonim',
      avatar: json['avatar'] ?? '',
      content: StringHelper.decodeHtml(json['content'] ?? ''),
      date: json['date'] ?? '',
      userId: json['user_id'] ?? 0,
      parent: json['parent'] ?? 0,
      replyCount: json['reply_count'] ?? 0,
      replies: json['replies'] != null
          ? (json['replies'] as List)
              .map((r) => CommentModel.fromJson(r))
              .toList()
          : [],
    );
  }
}