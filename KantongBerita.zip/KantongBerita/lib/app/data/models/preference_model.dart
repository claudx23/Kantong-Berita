class PreferenceModel {
  final List<int> preferredCategories;
  final List<int> preferredLocations;

  PreferenceModel({
    this.preferredCategories = const [],
    this.preferredLocations = const [],
  });

  factory PreferenceModel.fromJson(Map<String, dynamic> json) {
    return PreferenceModel(
      preferredCategories: List<int>.from(
        json['preferred_categories'] ?? [],
      ),
      preferredLocations: List<int>.from(
        json['preferred_locations'] ?? [],
      ),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'preferred_categories': preferredCategories,
      'preferred_locations': preferredLocations,
    };
  }
}