enum CategoryType { umum, lokal }

class CategoryItem {
  final String name;
  final String slug;
  final int id;
  final CategoryType type;
  final String? image;

  CategoryItem({
    required this.name,
    required this.slug,
    required this.id,
    required this.type,
    this.image,
  });
}