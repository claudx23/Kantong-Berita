class NotificationModel {
  final String id;
  final String type; // 'post' atau 'comment_reply'
  final String title;
  final String message;
  final int postId;
  final int commentId;
  final bool isRead;
  final String createdAt;

  NotificationModel({
    required this.id,
    required this.type,
    required this.title,
    required this.message,
    required this.postId,
    required this.commentId,
    required this.isRead,
    required this.createdAt,
  });

  factory NotificationModel.fromJson(Map<String, dynamic> json) {
    return NotificationModel(
      id:        json['id'] ?? '',
      type:      json['type'] ?? 'post',
      title:     json['title'] ?? '',
      message:   json['message'] ?? '',
      postId:    json['post_id'] ?? 0,
      commentId: json['comment_id'] ?? 0,
      isRead:    json['is_read'] ?? false,
      createdAt: json['created_at'] ?? '',
    );
  }

  // Copy with isRead true
  NotificationModel copyWithRead() {
    return NotificationModel(
      id:        id,
      type:      type,
      title:     title,
      message:   message,
      postId:    postId,
      commentId: commentId,
      isRead:    true,
      createdAt: createdAt,
    );
  }
}