import '../../utils/string_helper.dart';

class BookmarkModel {
  final int id;
  final String title;
  final String excerpt;
  final String featuredImage;
  final String date;
  final String categoryName;
  final String link;

  BookmarkModel({
    required this.id,
    required this.title,
    required this.excerpt,
    required this.featuredImage,
    required this.date,
    required this.categoryName,
    required this.link,
  });

  factory BookmarkModel.fromJson(Map<String, dynamic> json) {
    return BookmarkModel(
      id: json['id'] ?? 0,
      title: StringHelper.decodeHtml(json['title'] ?? ''),
      excerpt: StringHelper.decodeHtml(json['excerpt'] ?? ''),
      featuredImage: json['featured_image'] ?? '',
      date: json['date'] ?? '',
      categoryName: StringHelper.decodeHtml(json['category_name'] ?? ''),
      link: json['link'] ?? '',
    );
  }
}