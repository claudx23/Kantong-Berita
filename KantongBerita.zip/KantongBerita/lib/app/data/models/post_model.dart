import '../../utils/string_helper.dart';

class PostModel {
  final int id;
  final String title;
  final String content;
  final String excerpt;
  final String date;
  final String featuredImage;
  final String categoryName;
  final int categoryId;
  final List<int> categories;
  final String link;

  PostModel({
    required this.id,
    required this.title,
    required this.content,
    required this.excerpt,
    required this.date,
    this.featuredImage = '',
    this.categoryName = '',
    this.categoryId = 0,
    this.categories = const [],
    this.link = '',
  });

  // ==================== FROM API ====================

  factory PostModel.fromJson(Map<String, dynamic> json) {
    // Featured Image
    String imageUrl = '';

    if (json['jetpack_featured_media_url'] != null &&
        json['jetpack_featured_media_url'] != '') {
      imageUrl = json['jetpack_featured_media_url'];
    } else if (json['_embedded'] != null &&
        json['_embedded']['wp:featuredmedia'] != null &&
        (json['_embedded']['wp:featuredmedia'] as List).isNotEmpty) {
      imageUrl =
          json['_embedded']['wp:featuredmedia'][0]['source_url'] ?? '';
    }

    String catName = '';
    int catId = 0;

    if (json['_embedded'] != null &&
        json['_embedded']['wp:term'] != null &&
        (json['_embedded']['wp:term'] as List).isNotEmpty &&
        (json['_embedded']['wp:term'][0] as List).isNotEmpty) {
      final firstCat = json['_embedded']['wp:term'][0][0];
      catName = firstCat['name'] ?? '';
      catId = firstCat['id'] ?? 0;
    }

    final categoryList = List<int>.from(json['categories'] ?? []);

    if (catId == 0 && categoryList.isNotEmpty) {
      catId = categoryList.first;
    }

    return PostModel(
      id: json['id'] ?? 0,
      title: StringHelper.decodeHtml(
        json['title']['rendered'] ?? '',
      ),
      content: json['content']['rendered'] ?? '',
      excerpt: StringHelper.decodeHtml(
        StringHelper.stripHtml(
          json['excerpt']['rendered'] ?? '',
        ),
      ),
      date: json['date'] ?? '',
      featuredImage: imageUrl,
      categoryName: StringHelper.decodeHtml(catName),
      categoryId: catId,
      categories: categoryList,
      link: json['link'] ?? '',
    );
  }

  // ==================== TO CACHE ====================

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'content': content,
      'excerpt': excerpt,
      'date': date,
      'featured_image': featuredImage,
      'category_name': categoryName,
      'category_id': categoryId,
      'categories': categories,
      'link': link,
    };
  }

  // ==================== FROM CACHE ====================

  factory PostModel.fromCache(Map<String, dynamic> json) {
    return PostModel(
      id: json['id'] ?? 0,
      title: json['title'] ?? '',
      content: json['content'] ?? '',
      excerpt: json['excerpt'] ?? '',
      date: json['date'] ?? '',
      featuredImage: json['featured_image'] ?? '',
      categoryName: json['category_name'] ?? '',
      categoryId: json['category_id'] ?? 0,
      categories: List<int>.from(json['categories'] ?? []),
      link: json['link'] ?? '',
    );
  }
}