import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../data/models/comment_model.dart';
import '../modules/post_detail/controllers/comment_controller.dart';
import '../utils/app_colors.dart';
import 'avatar_initial.dart';

class CommentCard extends GetView<CommentController> {
  final CommentModel comment;
  final bool isReply;

  const CommentCard({super.key, required this.comment, this.isReply = false});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(left: isReply ? 40 : 0, bottom: 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // ==================== AVATAR INITIAL ====================
          AvatarInitial(
            name: comment.author,
            radius: isReply ? 14 : 18,
            fontSize: isReply ? 10 : 12,
          ),

          const SizedBox(width: 10),

          // ==================== CONTENT ====================
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Bubble
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 12,
                    vertical: 8,
                  ),
                  decoration: BoxDecoration(
                    color: AppColors.getCardColor(Get.context!),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Nama Author
                      Text(
                        comment.author,
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 13,
                          color: AppColors.getTextPrimaryColor(Get.context!),
                        ),
                      ),

                      const SizedBox(height: 4),

                      // Isi Komentar
                      Text(
                        comment.content,
                        style: TextStyle(
                          fontSize: 13,
                          height: 1.4,
                          color: AppColors.getTextPrimaryColor(Get.context!),
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 4),

                // ==================== ACTIONS ====================
                Row(
                  children: [
                    Text(
                      controller.getTimeAgo(comment.date),
                      style: TextStyle(
                        fontSize: 11,
                        color: AppColors.getTextSecondaryColor(Get.context!),
                      ),
                    ),

                    const SizedBox(width: 12),

                    // Reply
                    if (!isReply && controller.authProvider.isLoggedIn())
                      GestureDetector(
                        onTap: () => controller.setReply(comment),
                        child: const Text(
                          'Balas',
                          style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.bold,
                            color: Color(0xFFD32F2F),
                          ),
                        ),
                      ),

                    const Spacer(),

                    // Delete
                    if (controller.isMyComment(comment.userId) &&
                        controller.authProvider.isLoggedIn())
                      GestureDetector(
                        onTap: () => controller.confirmDelete(
                          comment.id,
                          parentId: comment.parent > 0 ? comment.parent : null,
                        ),
                        child: Icon(
                          Icons.delete_outline,
                          size: 16,
                          color: AppColors.getTextSecondaryColor(Get.context!),
                        ),
                      ),
                  ],
                ),

                // ==================== REPLIES ====================
                if (!isReply && comment.replies.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(top: 8),
                    child: Column(
                      children: comment.replies.map((reply) {
                        return CommentCard(comment: reply, isReply: true);
                      }).toList(),
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
