import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../services/connectivity_service.dart';

class OfflineBanner extends StatelessWidget {
  final Widget child;

  const OfflineBanner({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    // ✅ Pastikan service sudah terdaftar
    if (!Get.isRegistered<ConnectivityService>()) {
      return child;
    }

    final conn = Get.find<ConnectivityService>();

    return Column(
      children: [
        // ✅ Obx wajib ada agar reactive
        Obx(() {
          final online = conn.isOnline.value;

          return AnimatedContainer(
            duration: const Duration(milliseconds: 400),
            curve: Curves.easeInOut,
            height: online ? 0 : 36,
            color: const Color(0xFF323232),
            child: online
                ? const SizedBox.shrink()
                : SafeArea(
                    bottom: false,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Icon(
                          Icons.wifi_off_rounded,
                          color: Colors.white70,
                          size: 14,
                        ),
                        const SizedBox(width: 8),
                        const Text(
                          'Tidak ada koneksi · Kamu sedang offline',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 12,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                  ),
          );
        }),

        Expanded(child: child),
      ],
    );
  }
}
