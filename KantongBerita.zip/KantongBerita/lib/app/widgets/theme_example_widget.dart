import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:kantongberita/app/utils/app_colors.dart';
import 'package:kantongberita/app/data/providers/theme_provider.dart';

/// Example Widget demonstrating Dark Mode best practices
class ThemeExampleWidget extends StatelessWidget {
  const ThemeExampleWidget({super.key});

  @override
  Widget build(BuildContext context) {
    final themeProvider = Get.find<ThemeProvider>();

    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Example 1: Using AppColors helper
          Text(
            'Method 1: Using AppColors',
            style: TextStyle(
              color: AppColors.getTextPrimaryColor(context),
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: AppColors.getCardColor(context),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Text(
              'This widget uses AppColors for responsive colors',
              style: TextStyle(
                color: AppColors.getTextSecondaryColor(context),
              ),
            ),
          ),
          const SizedBox(height: 24),

          // Example 2: Using Theme.of(context)
          Text(
            'Method 2: Using Theme.of()',
            style: TextStyle(
              color: AppColors.getTextPrimaryColor(context),
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Theme.of(context).cardColor,
              borderRadius: BorderRadius.circular(8),
            ),
            child: Text(
              'This widget uses Theme.of() for colors',
              style: Theme.of(context).textTheme.bodyMedium,
            ),
          ),
          const SizedBox(height: 24),

          // Example 3: Using Obx for reactive updates
          Text(
            'Method 3: Reactive with Obx',
            style: TextStyle(
              color: AppColors.getTextPrimaryColor(context),
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          Obx(
            () => Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: themeProvider.isDarkMode.value
                    ? Colors.grey[900]
                    : Colors.grey[100],
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                'Current theme: ${themeProvider.isDarkMode.value ? 'DARK' : 'LIGHT'}',
                style: TextStyle(
                  color: AppColors.getTextPrimaryColor(context),
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
          const SizedBox(height: 24),

          // Example 4: Custom theme-aware styling
          Text(
            'Method 4: Custom Styling',
            style: TextStyle(
              color: AppColors.getTextPrimaryColor(context),
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          _buildCustomStyledWidget(context),
        ],
      ),
    );
  }

  Widget _buildCustomStyledWidget(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: isDark
              ? [Colors.grey[800]!, Colors.grey[900]!]
              : [Colors.blue[50]!, Colors.blue[100]!],
        ),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
          color: isDark ? Colors.grey[700]! : Colors.grey[300]!,
        ),
      ),
      child: Text(
        'Custom gradient colors adapt to theme',
        style: TextStyle(
          color: AppColors.getTextPrimaryColor(context),
        ),
      ),
    );
  }
}
