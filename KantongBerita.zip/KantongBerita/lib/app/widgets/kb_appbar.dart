import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:kantongberita/app/data/providers/theme_provider.dart';

import '../modules/notifications/controllers/notifications_controller.dart';
import '../routes/app_routes.dart';
import '../utils/app_colors.dart';

class KbAppBar extends StatelessWidget implements PreferredSizeWidget {
  final VoidCallback? onRefresh;

  const KbAppBar({super.key, this.onRefresh});

  @override
  Widget build(BuildContext context) {
    final themeProvider = Get.find<ThemeProvider>();

    return AppBar(
      backgroundColor: Theme.of(context).appBarTheme.backgroundColor,
      elevation: 0,
      titleSpacing: 16,
      title: Image.asset(
        'assets/images/logogabung.png',
        height: 40,
        fit: BoxFit.contain,
      ),
      actions: [
        if (onRefresh != null)
          IconButton(
            icon: Icon(
              Icons.refresh_outlined,
              color: AppColors.getTextSecondaryColor(Get.context!),
            ),
            onPressed: onRefresh,
          ),
        Obx(
          () => IconButton(
            icon: Icon(
              themeProvider.isDarkMode.value
                  ? Icons.light_mode_outlined
                  : Icons.dark_mode_outlined,
              color: AppColors.getTextSecondaryColor(Get.context!),
            ),
            onPressed: () => themeProvider.toggleTheme(),
          ),
        ),

        _buildNotificationBell(),
        const SizedBox(width: 4),
      ],
    );
  }

  Widget _buildNotificationBell() {
    // Cek apakah NotificationsController sudah di-register
    final bool hasController = Get.isRegistered<NotificationsController>();
    // final int unread = hasController
    //     ? Get.find<NotificationsController>().unreadCount.value
    //     : 0;

    return GestureDetector(
      onTap: () => Get.toNamed(AppRoutes.notifications),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 8),
        child: Stack(
          alignment: Alignment.center,
          children: [
            Icon(
              Icons.notifications_outlined,
              color: AppColors.getTextSecondaryColor(Get.context!),
              size: 26,
            ),

            // Badge
            if (hasController)
              Obx(() {
                final count =
                    Get.find<NotificationsController>().unreadCount.value;
                if (count <= 0) return const SizedBox.shrink();

                return Positioned(
                  top: 8,
                  right: 6,
                  child: Container(
                    padding: const EdgeInsets.all(2),
                    decoration: const BoxDecoration(
                      color: Color(0xFFD32F2F),
                      shape: BoxShape.circle,
                    ),
                    constraints: const BoxConstraints(
                      minWidth: 16,
                      minHeight: 16,
                    ),
                    child: Text(
                      count > 99 ? '99+' : '$count',
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 9,
                        fontWeight: FontWeight.bold,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),
                );
              }),
          ],
        ),
      ),
    );
  }

  @override
  Size get preferredSize => const Size.fromHeight(kToolbarHeight);
}
