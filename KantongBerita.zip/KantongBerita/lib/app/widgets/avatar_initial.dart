import 'package:flutter/material.dart';

class AvatarInitial extends StatelessWidget {
  final String name;
  final double radius;
  final double fontSize;

  const AvatarInitial({
    super.key,
    required this.name,
    this.radius = 50,
    this.fontSize = 24,
  });

  // ==================== GET INITIALS ====================

  String get initials {
    final trimmed = name.trim();
    if (trimmed.isEmpty) return '?';

    final words = trimmed.split(RegExp(r'\s+')).where((w) => w.isNotEmpty).toList();

    if (words.length == 1) {
      // Satu kata → ambil 1 huruf pertama
      return words[0][0].toUpperCase();
    }

    // Lebih dari 1 kata → ambil huruf pertama dari 2 kata pertama
    return (words[0][0] + words[1][0]).toUpperCase();
  }

  // ==================== GET COLOR ====================

  // Generate warna konsisten berdasarkan nama
  Color get avatarColor {
    final colors = [
      const Color(0xFFE53935), // Red
      const Color(0xFFD81B60), // Pink
      const Color(0xFF8E24AA), // Purple
      const Color(0xFF5E35B1), // Deep Purple
      const Color(0xFF3949AB), // Indigo
      const Color(0xFF1E88E5), // Blue
      const Color(0xFF039BE5), // Light Blue
      const Color(0xFF00ACC1), // Cyan
      const Color(0xFF00897B), // Teal
      const Color(0xFF43A047), // Green
      const Color(0xFFc0ca33), // Lime
      const Color(0xFFFFB300), // Amber
      const Color(0xFFFB8C00), // Orange
      const Color(0xFFf4511e), // Deep Orange
      const Color(0xFF6D4C41), // Brown
      const Color(0xFF546E7A), // Blue Grey
    ];

    if (name.trim().isEmpty) return colors[0];

    // Hash nama untuk dapat warna yang konsisten
    int hash = 0;
    for (final char in name.codeUnits) {
      hash = char + ((hash << 5) - hash);
    }

    return colors[hash.abs() % colors.length];
  }

  @override
  Widget build(BuildContext context) {
    return CircleAvatar(
      radius: radius,
      backgroundColor: avatarColor,
      child: Text(
        initials,
        style: TextStyle(
          color: Colors.white,
          fontSize: fontSize,
          fontWeight: FontWeight.w600,
          letterSpacing: 1,
        ),
      ),
    );
  }
} 