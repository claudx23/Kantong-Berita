import 'package:get/get.dart';
import 'package:kantongberita/app/modules/forgot_password/bindings/forgot_password_binding.dart';
import 'package:kantongberita/app/modules/forgot_password/views/forgot_password_view.dart';
import 'package:kantongberita/app/modules/personal_info/bindings/personal_info_binding.dart';
import 'package:kantongberita/app/modules/personal_info/views/personal_info_view.dart';
import 'package:kantongberita/app/modules/preference/views/preference_view.dart';
import 'package:kantongberita/app/modules/preference/bindings/preference_binding.dart';
import 'package:kantongberita/app/modules/profile/guidelines/views/disclaimer.dart';
import 'package:kantongberita/app/modules/profile/guidelines/views/kode_etik.dart';
import 'package:kantongberita/app/modules/profile/guidelines/views/kontak.dart';
import 'package:kantongberita/app/modules/profile/guidelines/views/pedoman_media.dart';
import 'package:kantongberita/app/modules/profile/guidelines/views/privacy_view.dart';
import 'package:kantongberita/app/modules/profile/guidelines/views/tentang_kami.dart';
import '../modules/auth/bindings/auth_binding.dart';
import '../modules/auth/views/start_view.dart';
import '../modules/auth/views/login_view.dart';
import '../modules/auth/views/register_view.dart';
import '../modules/category_posts/bindings/category_posts_binding.dart';
import '../modules/category_posts/views/category_posts_view.dart';
import '../modules/main/bindings/main_binding.dart';
import '../modules/main/views/main_view.dart';
import '../modules/notifications/bindings/notifications_binding.dart';
import '../modules/notifications/views/notifications_view.dart';
import '../modules/post_detail/bindings/post_detail_binding.dart';
import '../modules/post_detail/views/post_detail_view.dart';
import '../modules/profile/guidelines/views/redaksi.dart';
import '../modules/search/bindings/search_binding.dart';
import '../modules/search/views/search_view.dart';
import '../modules/splash/bindings/splash_binding.dart';
import '../modules/splash/views/splash_view.dart';
import 'app_routes.dart';

class AppPages {
  static const initial = AppRoutes.splash;

  static final routes = [
    GetPage(
      name: AppRoutes.splash,
      page: () => const SplashView(),
      binding: SplashBinding(),
    ),

    // Start / Landing Route
    GetPage(
      name: AppRoutes.start,
      page: () => const StartView(),
      binding: AuthBinding(),
    ),

    // Auth Routes
    GetPage(
      name: AppRoutes.login,
      page: () => const LoginView(),
      binding: AuthBinding(),
    ),
    GetPage(
      name: AppRoutes.register,
      page: () => const RegisterView(),
      binding: AuthBinding(),
    ),

    // Main Route (Bottom Navigation)
    GetPage(
      name: AppRoutes.main,
      page: () => const MainView(),
      binding: MainBinding(),
    ),

    GetPage(
      name: AppRoutes.postDetail,
      page: () => const PostDetailView(),
      binding: PostDetailBinding(),
    ),

    GetPage(
      name: AppRoutes.categoryPosts,
      page: () => const CategoryPostsView(),
      binding: CategoryPostsBinding(),
    ),

    GetPage(
      name: AppRoutes.search,
      page: () => const SearchView(),
      binding: SearchBinding(),
    ),

    GetPage(
      name: AppRoutes.preference,
      page: () => const PreferenceView(),
      binding: PreferenceBinding(),
    ),

    GetPage(
      name: AppRoutes.personalInfo,
      page: () => const PersonalInfoView(),
      binding: PersonalInfoBinding(),
    ),

    GetPage(
      name: AppRoutes.forgotPassword,
      page: () => const ForgotPasswordView(),
      binding: ForgotPasswordBinding(),
    ),

    GetPage(
      name: AppRoutes.notifications,
      page: () => const NotificationsView(),
      binding: NotificationsBinding(),
    ),

    GetPage(
      name: AppRoutes.pedomanMediaSiber,
      page: () => const PedomanMediaView(),
    ),

    GetPage(name: AppRoutes.kodeEtik, page: () => const KodeEtikView()),

    GetPage(name: AppRoutes.disclaimer, page: () => const DisclaimerView()),

    GetPage(
      name: AppRoutes.privacyPolicy,
      page: () => const PrivacyPolicyView(),
    ),

    GetPage(name: AppRoutes.tentangKami, page: () => const TentangKamiView()),

    GetPage(name: AppRoutes.kontakKami, page: () => const KontakKamiView()),

    GetPage(name: AppRoutes.redaksi, page: () => const RedaksiView()),
  ];
}
