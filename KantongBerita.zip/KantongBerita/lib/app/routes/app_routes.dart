abstract class AppRoutes {
  static const splash = '/splash';
  static const start = '/start';
  static const login = '/login';
  static const register = '/register';
  static const main = '/main';
  static const home = '/home';
  static const bookmark = '/bookmark';
  static const category = '/category';
  static const profile = '/profile';
  static const postDetail = '/post-detail';
  static const categoryPosts = '/category-posts';
  static const search = '/search';
  static const preference = '/preference';
  static const personalInfo = '/personal-info';
  static const forgotPassword = '/forgot-password';
  static const pedomanMediaSiber = '/pedoman-media-siber';
  static const kodeEtik = '/kode-etik';
  static const informasiPersonal = '/informasi-personal';
  static const disclaimer = '/disclaimer';
  static const redaksi = '/redaksi';
  static const privacyPolicy = '/privacy-policy';
  static const notifications = '/notifications';
  static const tentangKami = '/tentang-kami';
  static const kontakKami = '/kontak-kami';
}
