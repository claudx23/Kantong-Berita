import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:kantongberita/app/services/bookmark_cache_service.dart';
import 'package:kantongberita/app/services/connectivity_service.dart';
import 'package:kantongberita/app/services/notification_service.dart';
import 'package:kantongberita/app/services/post_cache_service.dart';
import 'package:kantongberita/app/services/reading_tracker_service.dart';
import 'package:kantongberita/app/utils/app_theme.dart';
import 'package:kantongberita/firebase_options.dart';
import 'app/data/providers/api_provider.dart';
import 'app/routes/app_pages.dart';
import 'app/data/providers/theme_provider.dart';
import 'app/data/providers/auth_provider.dart';
import 'app/services/app_refresh_service.dart';
import 'app/services/cache_service.dart';
import 'app/services/comment_moderation_service.dart';
import 'app/services/social_auth_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  FirebaseMessaging.onBackgroundMessage(firebaseMessagingBackgroundHandler);

  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);

  await GetStorage.init();
  Get.put(AuthProvider());
  Get.put(ApiProvider(), permanent: true);
  Get.put(SocialAuthService(), permanent: true);
  Get.put(ThemeProvider());
  Get.put(CacheService(), permanent: true);
  Get.put(PostCacheService(), permanent: true);
  Get.put(BookmarkCacheService(), permanent: true);
  Get.put(AppRefreshService(), permanent: true);
  Get.put(ReadingTrackerService(), permanent: true);
  Get.put(CommentModerationService(), permanent: true);

  await Get.putAsync<NotificationService>(
    () => NotificationService().init(),
    permanent: true,
  );

  await Get.putAsync<ConnectivityService>(
    () => ConnectivityService().init(),
    permanent: true,
  );

  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.dark,
    ),
  );

  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return Obx(() {
      final themeProvider = Get.find<ThemeProvider>();
      return GetMaterialApp(
        title: 'Kantong Berita',
        debugShowCheckedModeBanner: false,
        theme: AppTheme.lightTheme,
        darkTheme: AppTheme.darkTheme,
        themeMode: themeProvider.isDarkMode.value
            ? ThemeMode.dark
            : ThemeMode.light,
        initialRoute: AppPages.initial,
        getPages: AppPages.routes,
      );
    });
  }
}
