package com.example.kantongberita

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
